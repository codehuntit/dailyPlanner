import React, { useEffect, useState } from 'react';
import moment from 'moment';
import { Text, TouchableOpacity, View } from "react-native"
import { Calendar } from "react-native-calendars"
import { COLORS } from "../config/colors"



export const CalendarPicker = (props) => {
    const [markedDate, setMarkedDate] = useState(moment(new Date()).format('DD MMMM YYYY'))

    return <View style={{
        position: 'absolute',
        width: '100%',
        height: '100%',
    }}>
        <TouchableOpacity style={{
            flex: 1,
            backgroundColor: '#00000088'
        }}
            activeOpacity={1.0}
            onPress={() => {
                // setCalendar(false)
            }} />
        <View style={{
            width: '100%',
            backgroundColor: COLORS.appWhite,
            position: 'absolute',
            bottom: 0,
            // top: 5,
            // borderRadius: 10,

        }}>
            <View style={{
                height: 40,
                flexDirection: 'row',
                justifyContent: 'flex-end'
            }}>
                {/* <TouchableOpacity style={{
                    width: 100,
                    height: 40,
                    justifyContent: 'center',
                    alignItems: 'center'
                }} onPress={() => props.setCalendar(false)} >
                    <Text>Cancel</Text>
                </TouchableOpacity> */}
                <TouchableOpacity style={{
                    width: 100,
                    height: 40,
                    justifyContent: 'center',
                    alignItems: 'center'
                }} onPress={() => props.setCalendar(false)} >
                    <Text>Done</Text>
                </TouchableOpacity>
            </View>
            <Calendar
                enableSwipeMonths={true}
                markedDates={{
                    [markedDate]: { selected: true, marked: true, selectedColor: COLORS.appDarkBlue }
                }}
                onDayPress={(date) => {
                    setMarkedDate(date.dateString)
                    // props.setDate((props.dateFormat != null && props.dateFormat != '') ? moment(date.dateFormat, 'YYYY-MM-DD').format(props.dateFormat) : date.dateString)
                    props.setDate(date.dateString)
                }}
            />
        </View>
    </View>
}
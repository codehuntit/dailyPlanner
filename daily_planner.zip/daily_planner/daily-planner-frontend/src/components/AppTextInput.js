import React from 'react';
import {
    Image,
    Text,
    TextInput,
    View,
} from 'react-native';
import { COLORS } from '../config/colors';

export const AppTextInput = (props) => {
    return (
        <View style={[{
            // backgroundColor: '#eee',
            // borderRadius: 10
        }, props.style]}>
            {/* <Text style = {{
                fontSize: 16,
                fontWeight: '500',
                color: props.labelColor != null ? props.labelColor : COLORS.appGray,
                marginVertical: 5,
                paddingLeft: 15
            }}>{props.label}</Text> */}
            <View style = {{
                flexDirection: 'row',
                alignItems: 'center'
            }}>
                <Image style = {{
                    height: 22,
                    width: 22,
                    marginLeft: 10,
                    tintColor: COLORS.appGray
                }}
                source = {props.icon} />
                <TextInput style={[props.inputStyle, {
                    // flex: 1,
                    width: '100%',
                    padding: 0,
                    color: COLORS.appDarkBlue,
                    fontSize: 17,
                    padding: 0,
                    height: 50,
                    // borderRadius: 7,
                    // borderColor: COLORS.appDarkBlue,
                    // borderWidth: 1.5,
                    paddingHorizontal: 10
                }]}
                    placeholder={props.placeholder}
                    placeholderTextColor={COLORS.appGray}
                    secureTextEntry={props.secureTextEntry}
                    selectionColor={COLORS.appDarkBlue}
                    keyboardType={props.keyboardType}
                    value={props.value}
                    onChangeText={props.onChangeText} />
            </View>
            <View style={{
                height: 1,
                backgroundColor: COLORS.appGray
            }} />
            {props.errorMessage != null && props.errorMessage != '' &&
                <Text style={{
                    color: 'red',
                    marginTop: 5
                }}>* {props.errorMessage}</Text>}
        </View>
    );
};
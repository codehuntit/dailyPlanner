import React from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { COLORS } from '../config/colors';

export const AppButton = (props) => {
    return (
        <TouchableOpacity style = {[{
            backgroundColor: COLORS.appBlue,
            height: 50,
            borderRadius: 7,
            justifyContent: 'center',
            alignItems: 'center'
        }, props.style]}
        onPress = {props.onPress} >
            <Text style = {{
                color: props.textColor != null ? props.textColor : 'white',
                fontSize: 17,
                fontWeight: '500'
            }}>{props.title}</Text>
        </TouchableOpacity>
    );
};
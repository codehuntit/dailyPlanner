export const ApiClient = {
    fetchPost (method, params, isLoader, setLoader, completion, completionWithError) {
        if(isLoader) {
            setLoader(true)
        }
        fetch('http://3.121.4.157/public/api/' + method, {
            body: JSON.stringify(params),
            method: 'POST'
        })
            .then(response => response.json())
            .then((responseJson) => {
                if(isLoader) {
                    setLoader(false)
                }
                if(responseJson.status + '' == 'true') {
                    completion(responseJson)
                }
                else {
                    alert(responseJson.message + '')
                }
            })
            .catch(error => {
                if(isLoader) {
                    setLoader(false)
                }
                completionWithError(error)
                console.log(error)
            }) 
    },

    fetchGet (method, isLoader, setLoader, completion, completionWithError) {
        if(isLoader) {
            setLoader(true)
        }
        fetch('http://3.121.4.157/public/api/' + method)
            .then(response => response.json())
            .then((responseJson) => {
                if(isLoader) {
                    setLoader(false)
                }
                if(responseJson.status + '' == 'true') {
                    completion(responseJson)
                }
                else {
                    alert(responseJson.message + '')
                }
            })
            .catch(error => {
                if(isLoader) {
                    setLoader(false)
                }
                completionWithError(error)
                console.log(error)
            }) 
    }
}


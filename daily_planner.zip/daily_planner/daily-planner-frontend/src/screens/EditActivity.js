/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { COLORS } from '../config/colors';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from 'moment';
import { ActivityRepeatMode } from '../config/enums'
import { Calendar } from 'react-native-calendars';
import { global } from '../config/global';

const CELL_WIDTH = Dimensions.get('screen').width * 0.8

export const EditActivity = (props) => {

  const [activityData, setActivityData] = useState(props.activityData)
  const [activityValue, setActivityValue] = useState('')
  const [selectedActivity, setActivity] = useState(null)
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);
  const [selectedDate, setDate] = useState(new Date())
  const [selectedTime, setTime] = useState(new Date())
  const [selectedCalendarDates, setCalendarDates] = useState([new Date()])
  const [markedDates, setMarkedDates] = useState({ [moment(new Date()).format('YYYY-MM-DD')]: { selected: true, marked: true, selectedColor: COLORS.appDarkBlue } })
  const [selectedRepeat, setRepeat] = useState(ActivityRepeatMode.selectedDate)

  const [defaultActivities, setActivities] = useState(activityData != null ? activityData.title : [])

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleDateConfirm = (date) => {
    setDate(date);
    hideDatePicker();
  };

  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };

  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };

  const handleTimeConfirm = (date) => {
    setTime(date);
    hideTimePicker();
  };


  const defaultActivityCell = ({ item, index }) => {
    return <View style={{
      height: 40,
      marginHorizontal: 5,
      width: (CELL_WIDTH / 2),
    }}>
      <TouchableOpacity style={{
        flex: 1,
        alignItems: 'center',
        flexDirection: 'row',
        // justifyContent: 'space-between'
      }}
        activeOpacity={1.0}
        onPress={() => {
          // setActivity(item)
        }} >
        {/* <Image style={{
          height: 20,
          width: 20,
        }}
          // source={(selectedActivity != null && item.id == selectedActivity.id) ? require('../assets/icons/checked.png') : require('../assets/icons/uncheck.png')}
          source={require('../assets/icons/checked.png')} /> */}
        <Text style={{
          marginLeft: 5,
          flex: 1
        }}>{item}</Text>


        <TouchableOpacity style={{
          height: 40,
          width: 30,
          alignItems: 'center',
          justifyContent: 'center'
        }}
          onPress={() => {
            var _defaultActivities = [...defaultActivities]
            _defaultActivities.splice(index, 1)
            setActivities(_defaultActivities)
          }} >
          <Image style={{
            height: 12,
            width: 12,
          }}
            // source={(selectedActivity != null && item.id == selectedActivity.id) ? require('../assets/icons/checked.png') : require('../assets/icons/uncheck.png')}
            source={require('../assets/icons/journal_menu/close.png')} />

        </TouchableOpacity>

      </TouchableOpacity>
    </View>
  }

  const ActivityCalendarView = () => {
    let _selDates = {}
    selectedCalendarDates.map((item, index) => {
      _selDates[moment(item).format('YYYY-MM-DD')] = { selected: true, marked: true, selectedColor: COLORS.appDarkBlue }
    })
    return <Calendar
      enableSwipeMonths={true}
      markedDates={_selDates}
      onDayPress={(date) => {
        var _dates = [...selectedCalendarDates]
        _dates.push(moment(date.dateString, 'YYYY-MM-DD'))
        setCalendarDates(_dates)
      }}
    />
  }

  const addActivity = () => {

  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <View style={{
          height: 44,
          alignItems: 'flex-end',
          justifyContent: 'center',
        }}>
          <Text style={{
            fontSize: 18,
            fontWeight: '500',
            position: 'absolute',
            alignSelf: 'center'
          }}>Log In Activity</Text>
          <TouchableOpacity style={{
            height: 40,
            width: 40,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 15
          }}
            onPress={() => {
              Navigation.dismissModal(props.componentId)
            }} >
            <Image style={{
              height: 22,
              width: 22
            }}
              source={require('../assets/icons/journal_menu/close.png')} />
          </TouchableOpacity>
        </View>

        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS == 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            contentContainerStyle={{
              marginTop: 20
            }} >
            <View style={{
              alignItems: 'center'
            }}>
              <View style={{
                height: 40,
                width: '90%',
                marginBottom: 30
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500'
                }}>Repeat Activity</Text>
                <View style={{
                  height: 40,
                  flexDirection: 'row',
                  justifyContent: 'space-between'
                }}>
                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      setRepeat(ActivityRepeatMode.selectedDate)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                    }}
                      source={(selectedRepeat == ActivityRepeatMode.selectedDate) ? require('../assets/icons/radio-on.png') : require('../assets/icons/radio-off.png')} />
                    <Text style={{
                      marginLeft: 5
                    }}>Date</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      setRepeat(ActivityRepeatMode.calendar)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                    }}
                      source={(selectedRepeat == ActivityRepeatMode.calendar) ? require('../assets/icons/radio-on.png') : require('../assets/icons/radio-off.png')} />
                    <Text style={{
                      marginLeft: 5
                    }}>Calendar</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      setRepeat(ActivityRepeatMode.allDays)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                    }}
                      source={(selectedRepeat == ActivityRepeatMode.allDays) ? require('../assets/icons/radio-on.png') : require('../assets/icons/radio-off.png')} />
                    <Text style={{
                      marginLeft: 5
                    }}>All Days</Text>
                  </TouchableOpacity>
                </View>
              </View>
              {selectedRepeat == ActivityRepeatMode.selectedDate ? <View style={{
                minHeight: 40,
                width: '90%',
                // marginTop: 30
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Date</Text>
                <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: 'center'
                  }}
                  onPress={showDatePicker}>
                  <Text style={{
                    fontSize: 17,
                    // fontWeight: '500',
                    minWidth: 100
                  }}>{selectedDate != null ? moment(selectedDate).format('DD/MM/YYYY') : '__/__/____'}</Text>
                </TouchableOpacity>
              </View> : selectedRepeat == ActivityRepeatMode.calendar ? <View style={{
                minHeight: 40,
                width: '90%',
                // marginTop: 30
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15
              }}>
                {/* <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Calendar</Text> */}
                {/* <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: 'center'
                  }}
                  onPress={showDatePicker}>
                  <Text style={{
                    fontSize: 17,
                    fontWeight: '500',
                    minWidth: 100
                  }}>{selectedDate != null ? moment(selectedDate).format('DD/MM/YYYY') : '__/__/____'}</Text>
                </TouchableOpacity> */}

                <ActivityCalendarView />

              </View> : <View />}
              <View style={{
                height: 40,
                width: '90%',
                // marginTop: 10
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Time </Text>
                <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: 'center'
                  }}
                  onPress={showTimePicker}>
                  <Text style={{
                    fontSize: 17,
                    // fontWeight: '500',
                    minWidth: 100
                  }}>{selectedTime != null ? moment(selectedTime).format('hh:mm A') : '__/__/____'}</Text>
                </TouchableOpacity>
              </View>
              <View style={{
                marginTop: 30,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Activity</Text>
                <View style={{
                  flexDirection: 'row',
                  marginTop: 10,
                  marginBottom: 20
                }}>
                  <TextInput style={{
                    borderColor: COLORS.appGray,
                    borderWidth: 2,
                    height: 40,
                    borderRadius: 5,
                    padding: 5,
                    flex: 1
                  }}
                    value={activityValue}
                    onChangeText={setActivityValue} />
                  <TouchableOpacity style={{
                    height: 40,
                    width: 40,
                    justifyContent: 'center',
                    alignItems: 'center'
                  }} onPress={() => {
                    if (activityValue.length > 0) {
                      var _defaultActivities = [...defaultActivities]
                      // _defaultActivities.push({
                      //   id: defaultActivities.length + 1,
                      //   title: activityValue
                      // })
                      _defaultActivities.push(activityValue)
                      setActivityValue('')
                      setActivities(_defaultActivities)
                    }
                    else {
                      // alert('Alert', 'Please enter value first.')
                    }
                  }} >
                    <Image style={{
                      height: 22,
                      width: 22
                    }}
                      source={require('../assets/icons/plus.png')} />
                  </TouchableOpacity>
                </View>
              </View>
              {/* <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginTop: 10,
                  marginBottom: 10
                }}>Choose Default</Text> */}
              <FlatList
                style={{
                  width: '90%'
                }}
                numColumns={2}
                data={defaultActivities}
                keyExtractor={(item, index) => index}
                renderItem={defaultActivityCell} />

              <AppButton
                style={{
                  width: '90%',
                  marginTop: 30,
                  marginBottom: 50,
                  backgroundColor: COLORS.appDarkBlue
                }}
                title='Continue'
                onPress={addActivity}
              />
            </View>
          </ScrollView>
        </KeyboardAvoidingView>

      </View>

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleDateConfirm}
        onCancel={hideDatePicker}
      />

      <DateTimePickerModal
        isVisible={isTimePickerVisible}
        mode="time"
        onConfirm={handleTimeConfirm}
        onCancel={hideTimePicker}
      />

    </SafeAreaView>
  );
};

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
import moment from 'moment';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { AppButton } from '../components/AppButton';

export const AddGoal = (props) => {

  const [isStartDateVisible, setStartDateVisibility] = useState(false);
  const [isEndDateVisible, setEndDateVisibility] = useState(false);
  const [goalText, setGoalText] = useState((props.goalData != null && props.goalData.title != null) ? props.goalData.title : '')
  const [startDate, setStartDate] = useState((props.goalData != null && props.goalData.fromDate != null) ? moment(props.goalData.fromDate, 'DD/MM/YYYY').toDate() : new Date())
  const [endDate, setEndDate] = useState((props.goalData != null && props.goalData.toDate != null) ? moment(props.goalData.toDate, 'DD/MM/YYYY').toDate() : null)

  const showStartDatePicker = () => {
    setStartDateVisibility(true);
  };

  const hideStartDatePicker = () => {
    setStartDateVisibility(false);
  };

  const handleStartConfirm = (date) => {
    setStartDate(date);
    hideStartDatePicker();
  };

  const showEndDatePicker = () => {
    setEndDateVisibility(true);
  };

  const hideEndDatePicker = () => {
    setEndDateVisibility(false);
  };

  const handleEndConfirm = (date) => {
    setEndDate(date);
    hideEndDatePicker();
  };

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View style={{
        height: 44,
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginTop: 10
      }}>
        <Text style={{
          fontSize: 18,
          fontWeight: '500',
          position: 'absolute',
          alignSelf: 'center'
        }}>Add Goal</Text>
        <TouchableOpacity style={{
          height: 40,
          width: 40,
          justifyContent: 'center',
          alignItems: 'center',
          marginRight: 15
        }}
          onPress={() => {
            Navigation.dismissModal(props.componentId)
          }} >
          <Image style={{
            height: 22,
            width: 22
          }}
            source={require('../assets/icons/journal_menu/close.png')} />
        </TouchableOpacity>
      </View>

      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <View style={{
          marginTop: 20,
          marginHorizontal: 15
        }}>
          <Text style={{
            fontSize: 16,
            fontWeight: '500',
          }}>Goal</Text>
          <TextInput style={{
            borderColor: COLORS.appGray,
            borderWidth: 2,
            height: 90,
            marginVertical: 12,
            borderRadius: 5,
            padding: 5
          }}
            value={goalText}
            onChangeText={setGoalText}
            placeholder='Write your goal'
            textAlignVertical='top'
            multiline={true}
            numberOfLines={0} />
        </View>
        <View style={{
          paddingHorizontal: 15,
          marginTop: 10
        }}>
          <Text style={{
            fontSize: 16,
            fontWeight: '500',
            marginRight: 20,
          }}>Start Date</Text>
          <TouchableOpacity
            style={{
              height: 44,
              width: '100%',
              paddingHorizontal: 15,
              marginTop: 10,
              backgroundColor: '#eee',
              borderRadius: 7,
              justifyContent: 'center'
            }}
            onPress={showStartDatePicker}>
            <Text style={{
              fontSize: 17,
              fontWeight: '500',
              minWidth: 100,
              marginVertical: 10
            }}>{startDate != null ? moment(startDate).format('DD/MM/YYYY') : '__/__/____'}</Text>
          </TouchableOpacity>
        </View>
        <View style={{
          paddingHorizontal: 15,
          marginTop: 20
        }}>
          <Text style={{
            fontSize: 16,
            fontWeight: '500',
            marginRight: 20,
          }}>Finish Date</Text>
          <TouchableOpacity
            style={{
              height: 44,
              width: '100%',
              paddingHorizontal: 15,
              marginTop: 10,
              backgroundColor: '#eee',
              borderRadius: 7,
              justifyContent: 'center'
            }}
            onPress={showEndDatePicker}>
            <Text style={{
              fontSize: 17,
              fontWeight: '500',
              minWidth: 100,
              marginVertical: 10
            }}>{endDate != null ? moment(endDate).format('DD/MM/YYYY') : ''}</Text>
          </TouchableOpacity>
        </View>
        <AppButton
          style={{
            marginTop: 30,
            marginHorizontal: 15,
            backgroundColor: COLORS.appDarkBlue
          }}
          title='Save'
        // onPress={gotoHome}
        />
        {props.goalData && <AppButton
          style={{
            // width: '90%',
            marginBottom: 20,
            marginHorizontal: 15,
            marginTop: 20,
            backgroundColor: COLORS.appWhite,
            borderWidth: 2,
            borderColor: COLORS.appDarkBlue
          }}
          textColor={COLORS.appDarkBlue}
          title={'Delete'}
        // onPress={addActivity}
        />}
      </View>

      <DateTimePickerModal
        isVisible={isStartDateVisible}
        mode="date"
        onConfirm={handleStartConfirm}
        onCancel={hideStartDatePicker}
      />

      <DateTimePickerModal
        isVisible={isEndDateVisible}
        mode="date"
        onConfirm={handleEndConfirm}
        onCancel={hideEndDatePicker}
      />

    </SafeAreaView>
  );
};

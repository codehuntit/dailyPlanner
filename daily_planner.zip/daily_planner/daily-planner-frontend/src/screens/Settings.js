/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Alert,
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const Settings = (props) => {

  const [menu, setMenu] = useState([{
    id: '1',
    title: 'Profile',
    icon: require('../assets/icons/user.png')
  }, {
    id: '2',
    title: 'Terms & Conditions',
    icon: require('../assets/icons/information-sign.png')
  }, {
    id: '3',
    title: 'Privacy Policy',
    icon: require('../assets/icons/insurance.png')
  }, {
    id: '4',
    title: 'Logout',
    icon: require('../assets/icons/logout.png')
  }])

  const settingCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      // width: CELL_WIDTH,
      // height: CELL_WIDTH,
      alignItems: 'center',
      flexDirection: 'row'
      // backgroundColor: index % 2 == 0 ? COLORS.appWhite : COLORS.appGray
    }}
      onPress={() => {
        if (item.id == '1') {
          gotoProfile()
        }
        else if (item.id == '4') {
          Alert.alert(
            ('Logout'),
            ('Are you sure you want to logout?'),
            [
              {
                text: ('Logout'),
                onPress: async () => {
                  // AsyncStorage.setItem(USER_ID_KEY, '')
                  logoutUser()
                },
              },
              { text: ('Cancel'), style: 'cancel' },
            ],
            {
              cancelable: false,
            },
          );
        }
      }} >

      <Image style={{
        height: 30,
        width: 30,
        marginLeft: 15,
        resizeMode: 'contain',
        tintColor: COLORS.appDarkBlue
      }}
        source={item.icon}
      />
      <Text style={{
        width: '100%',
        height: 40,
        // textAlign: 'center',
        marginTop: 12,
        marginLeft: 15,
        color: COLORS.appDarkBlue,
        fontSize: 16,
        fontWeight: '500'
      }}>{item.title}</Text>
      <View style={{
        height: 1,
        backgroundColor: COLORS.appGray,
        width: '100%',
        position: 'absolute',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  const gotoProfile = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.Profile',
        options: {
          topBar: {
            title: {
              text: 'Profile',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            }
          }
        }
      }
    })
  }

  const logoutUser = () => {
    Navigation.setRoot({
      root: {
        stack: {
          children: [
            {
              component: {
                name: 'com.planner.SignUp',
                options: {
                  topBar: {
                    visible: false
                  }
                }
              },
            }
          ]
        }
      }
    })
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        <FlatList
          // contentContainerStyle = {{
          //   marginTop: 30
          // }}
          // numColumns={3}
          data={menu}
          renderItem={settingCell} />
      </View>
    </SafeAreaView>
  );
};

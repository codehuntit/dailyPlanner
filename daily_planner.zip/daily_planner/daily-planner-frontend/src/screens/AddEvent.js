/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { COLORS } from '../config/colors';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from 'moment';
import { ActivityRepeatMode } from '../config/enums'
import { Calendar } from 'react-native-calendars';

const CELL_WIDTH = Dimensions.get('screen').width * 0.8

export const AddEvent = (props) => {

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedDate, setDate] = useState(props.date != null ? moment(props.date, 'YYYY-MM-DD') : new Date())
  const [description, setDescription] = useState(props.description != null ? props.description : '')

  

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleDateConfirm = (date) => {
    setDate(date);
    hideDatePicker();
  };

  const addEvent = () => {

  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite,
          alignItems: 'center'
        }}>
        <View style={{
          height: 44,
          width: '100%',
          alignItems: 'flex-end',
          justifyContent: 'center',
          marginTop: 10
        }}>
          <Text style={{
            fontSize: 18,
            fontWeight: '500',
            position: 'absolute',
            alignSelf: 'center'
          }}>Add Event</Text>
          <TouchableOpacity style={{
            height: 40,
            width: 40,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 15
          }}
            onPress={() => {
              Navigation.dismissModal(props.componentId)
            }} >
            <Image style={{
              height: 22,
              width: 22
            }}
              source={require('../assets/icons/journal_menu/close.png')} />
          </TouchableOpacity>
        </View>

        <KeyboardAvoidingView style={{
          flex: 1,
          width: '100%',
        }}
          behavior={'padding'}
          enabled={Platform.OS == 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            contentContainerStyle={{
              marginTop: 20,
              paddingBottom: 50
            }} >
            <View style={{
              alignItems: 'center'
            }}>
              <View style={{
                minHeight: 40,
                width: '90%',
                // marginTop: 30
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Date</Text>
                <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: 'center'
                  }}
                  onPress={showDatePicker}>
                  <Text style={{
                    fontSize: 17,
                    // fontWeight: '500',
                    minWidth: 100
                  }}>{selectedDate != null ? moment(selectedDate).format('DD/MM/YYYY') : '__/__/____'}</Text>
                </TouchableOpacity>
              </View>

              <View style={{
                marginTop: 30,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Description</Text>
                <View style={{
                  marginTop: 10,
                  marginBottom: 20
                }}>
                  <TextInput style={{
                    borderColor: COLORS.appGray,
                    borderWidth: 2,
                    height: 120,
                    marginVertical: 12,
                    borderRadius: 5,
                    padding: 5
                  }}
                    placeholder='Write your subject'
                    textAlignVertical='top'
                    value = {description}
                    onChangeText = {setDescription}
                    multiline={true}
                    numberOfLines={0} />
                </View>
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
        <AppButton
          style={{
            width: '90%',
            marginTop: 30,
            marginBottom: 40,
            backgroundColor: COLORS.appDarkBlue
          }}
          title='Continue'
          onPress={addEvent}
        />
      </View>

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleDateConfirm}
        onCancel={hideDatePicker}
      />

    </SafeAreaView>
  );
};

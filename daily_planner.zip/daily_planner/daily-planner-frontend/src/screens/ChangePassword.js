import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";

import { Navigation } from "react-native-navigation";
import { AppButton } from "../components/AppButton";
import { AppTextInput } from "../components/AppTextInput";
import { COLORS } from "../config/colors";

export const ChangePassword = (props) => {

  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  const [oldPasswordError, setOldError] = useState('')
  const [newPasswordError, setNewError] = useState('')
  const [confirmPasswordError, setConfirmError] = useState('')

  const clearAllMessages = () => {
    setOldError('')
    setNewError('')
    setConfirmError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (oldPassword == '') {
      setOldError('Please enter old password.')
    }
    if (newPassword == '') {
      setNewError('Please enter new password.')
    }
    if (confirmPassword == '') {
      setConfirmError('Please enter confirm password.')
    }

    if (newPassword != '' && confirmPassword != '' && newPassword != confirmPassword) {
      setConfirmError('New password and confirm password mismatch.')
    }

    if (oldPassword != '' && newPassword != '' && confirmPassword != '' && newPassword == confirmPassword) {
      changePasswordRequest()
    }
  }

  const changePasswordRequest = () => {

  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        // backgroundColor: COLORS.appGray,
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}>
        <ScrollView
          style={{
            flex: 1
          }}
        // contentContainerStyle = {{
        //   flex: 1
        // }}
        >
          <View
            style={{
              height: Dimensions.get('screen').height / 1.3,
              alignItems: "center",
              justifyContent: 'center'
            }}
          >
            <AppTextInput style={{
              marginTop: 20,
              width: '90%',
            }}
              icon={require('../assets/icons/padlock.png')}
              errorMessage={oldPasswordError}
              onChangeText={setOldPassword}
              value={oldPassword}
              placeholder='Old Password'
              secureTextEntry />
            <AppTextInput style={{
              marginTop: 20,
              width: '90%',
            }}
              icon={require('../assets/icons/padlock.png')}
              errorMessage={newPasswordError}
              onChangeText={setNewPassword}
              value={newPassword}
              placeholder='Password'
              secureTextEntry />
            <AppTextInput style={{
              marginTop: 20,
              width: '90%',
            }}
              icon={require('../assets/icons/padlock.png')}
              errorMessage={confirmPasswordError}
              onChangeText={setConfirmPassword}
              value={confirmPassword}
              placeholder='Confirm password'
              secureTextEntry />

            <AppButton style={{
              marginTop: 30,
              width: '90%'
            }}
              title='Save'
              onPress={validateData}
            />

          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

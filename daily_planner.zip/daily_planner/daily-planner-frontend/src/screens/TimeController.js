/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import moment from 'moment';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  SafeAreaView,
  View,
  ScrollView,
  Image,
  Text,
  TouchableOpacity,
  RefreshControl,
  Dimensions,
  FlatList
} from 'react-native';
import PageControl from 'react-native-page-control';
import { COLORS } from '../config/colors';
import Svg, { Circle, G } from 'react-native-svg';
import ClockTicks from '../config/ClockTicks';
import Hand from '../config/Hand';
import { Navigation } from 'react-native-navigation';
import ActionSheet from 'react-native-actionsheet';
import { global } from '../config/global';
import { ViewType } from '../config/enums';
import { Agenda } from 'react-native-calendars';
import { CalendarPicker } from '../components/CalendarPicker';

const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const weekDates = [{
  title: '14',
  isSelected: false
}, {
  title: '15',
  isSelected: false
}, {
  title: '16',
  isSelected: false
}, {
  title: '17',
  isSelected: false
}, {
  title: '18',
  isSelected: true,
}, {
  title: '19',
  isSelected: false
}, {
  title: '20',
  isSelected: false
}];

const width = Dimensions.get('screen').width / 1.1

// const hourTickCount = 12;
// const minuteTickCount = 12 * 6;

// const diameter = width - 40;
// const center = width / 2;
// const radius = diameter / 2;

const hourTickCount = 24;
const minuteTickCount = 24 * 6;

const diameter = width - 25;
const center = width / 2;
const radius = diameter / 2;

const activityMenu = ['Edit', 'Delete', 'Cancel']

export const TimeController = (props) => {
  const scrollRef = useRef<ScrollView>()
  const [currentPage, setCurrentPage] = useState(0)
  const [viewTypes, setViewTypes] = useState([ViewType.calendar, ViewType.fullWeek, ViewType.today, 'Cancel'])
  const [selectedView, setSelectedView] = useState(ViewType.today)
  const [isCalendar, setCalendar] = useState(false)
  const [isWeekVisible, setWeekVisible] = useState(false)
  const [selectedDate, setSelectedDate] = useState(moment(new Date()).format('YYYY-MM-DD'))
  const [timings, setTimings] = useState([{
    id: '12',
    title: ['Wake up'],
    time: '04:00 AM',
    isEvent: true,
    isComplete: true, isReminder: true
  }, {
    id: '13',
    title: ['Fajr', 'Breakfast'],
    time: '04:32 AM',
    isEvent: true,
    isComplete: false, isReminder: false
  }, {
    //   id: '1',
    //   title: [],
    //   time: '',
    //   isEvent: false,
    // }, {
    id: '14',
    title: ['Dhuhr'],
    time: '05:56 AM',
    isEvent: true,
    isComplete: false, isReminder: true
  }, {
    id: '15',
    title: ['Asr'],
    time: '12:23 PM',
    isEvent: true,
    isComplete: false, isReminder: false
  }, {
    id: '16',
    title: ['Maghrib'],
    time: '03:59 PM',
    isEvent: true,
    isComplete: false, isReminder: false
  }, {
    id: '17',
    title: ['Isha\'a'],
    time: '06:51 PM',
    isEvent: true,
    isComplete: false, isReminder: false
    // }, {
    //   id: '0',
    //   title: [],
    //   time: '',
    //   isEvent: false,
    //   isComplete: false, isReminder: false
  }, {
    id: '4',
    title: ['Sleep'],
    time: '10:00 PM',
    isEvent: true,
    isComplete: false, isReminder: false
  }])


  const ClockView = () => {

    return <View style={{
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      shadowRadius: 10,
      shadowOffset: {
        width: 0,
        height: 0,
      },
      shadowColor: 'black',
      elevation: 5,
      shadowOpacity: 0.8
    }}>

      <View style={{
        width: width,
        height: width,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: (width) / 2
      }}>
        <Svg height={width} width={width}>
          <ClockTicks
            minutes={minuteTickCount}
            hours={hourTickCount}
            radius={radius}
            center={center}
          />

          {timings.map((item, index) => {
            if (item.isEvent) {
              // 360 -> circle points, 1440 -> minutes of full date (24 * 60)
              return <Hand
                angle={Math.round(parseFloat(360 / 1440) * ((moment(item.time, 'hh:mm A').toDate().getHours() * 60) + moment(item.time, 'hh:mm A').toDate().getMinutes()))}
                // angle={120}
                center={center}
                radius={radius}
                stroke={COLORS.appWhite}
                strokeWidth="3"
                onPress={() => {
                  alert(item.title.join(', '))
                }}
              />
            }
          })}

          <Circle cx={center} cy={center} r={radius - 70} fill={COLORS.appWhite}>

          </Circle>
        </Svg>
      </View>
      {/* <View style={{
        width: width / 1.5,
        height: width / 1.5,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: (width / 1.5) / 2,
        position: 'absolute'
      }}>
        <Circle cx="50" cy="50" r="30" fill="yellow" />
      </View> */}
    </View>
  }

  const ListView = () => {
    return <View style={{
      flex: 1
    }}>
      <FlatList style={{
        flex: 1
      }}
        contentContainerStyle={{
          paddingBottom: 75
        }}
        data={timings}
        keyExtractor={(item, index) => index}
        renderItem={ListCell} />
    </View>
  }
  const ListCell = ({ item, index }) => {
    // let fColor = (moment(item.time, 'hh:mm A').toDate().getTime() < new Date().getTime() || item.isComplete) ? COLORS.appDarkBlue : COLORS.appGray
    let fColor = item.isComplete ? COLORS.appDarkBlue : COLORS.appGray

    return <TouchableOpacity style={{
      height: 60,
      flexDirection: 'row',
      paddingHorizontal: 15,
      alignItems: 'center'
    }}
      activeOpacity={1.0}
      onPress={() =>
        gotoAddActivity(item)
        // () => {
        //   Navigation.showModal({
        //     component: {
        //       name: 'com.planner.EditActivity',
        //       passProps: {
        //         activityData: item
        //       }
        //     }
        //   })
        // }
      } >
      <Text style={{
        fontSize: 15,
        fontWeight: '500',
        width: 75
      }}>{item.time}
      </Text>
      <View style={{
        alignItems: 'center',
        width: 50,
        height: '100%'
      }}>
        {index == 0 ?
          <View style={{
            alignItems: 'center',
            justifyContent: 'flex-end',
            // width: 50,
            height: '100%'
          }}>
            {/* <View style={{
              width: 20,
              height: 1.2,
              backgroundColor: COLORS.appGray
            }} /> */}
            {ActivityIcon(fColor, require('../assets/icons/menu/alarm.png'))}
            <View style={{
              width: 1.2,
              height: '20%',
              backgroundColor: COLORS.appGray
            }} />
          </View>
          : index == (timings.length - 1) ? <View style={{
            alignItems: 'center',
            justifyContent: 'flex-start',
            // width: 20,
            height: '100%'
          }}>
            <View style={{
              width: 1.2,
              height: '20%',
              backgroundColor: COLORS.appGray
            }} />
            {/* <View style={{
              width: 20,
              height: 1.2,
              backgroundColor: COLORS.appDarkBlue
            }} /> */}
            {ActivityIcon(fColor, require('../assets/icons/menu/sleep.png'))}
          </View> : <View style={{
            alignItems: 'center',
            justifyContent: 'center',
            // width: 20,
            height: '100%'
          }}>
              {/* <View style={{
                width: 20,
                height: 1.2,
                backgroundColor: COLORS.appDarkBlue,
                position: 'absolute'
              }} /> */}

              <View style={{
                width: 1.2,
                height: '100%',
                backgroundColor: COLORS.appGray,
                position: 'absolute'
              }} />
              {item.isEvent && ActivityIcon(fColor, require('../assets/icons/mosque.png'))}
            </View>}

      </View>
      {
        // item.isEvent ?
        <View style={{
          flex: 1,
          flexDirection: 'row',
          alignItems: 'center'
        }}><Text style={{
          flex: 1,
          fontSize: 15,
          fontWeight: '500',
          marginLeft: 7,
          color: fColor
        }}>{item.title.join(', ')}
          </Text>

          {!item.isComplete && <TouchableOpacity style={{
            alignItems: 'center',
            justifyContent: 'center',
            height: 40,
            width: 40,
            marginRight: 10
          }}
            onPress={() => {
              var _timings = [...timings]
              _timings[index].isReminder = !_timings[index].isReminder
              setTimings(_timings)
            }} >
            <View style={{
              height: 22,
              width: 22,
              borderRadius: 3,
              overflow: 'hidden'
            }}>
              <Image style={{
                height: 22,
                width: 22,
                // backgroundColor: item.isComplete ? COLORS.appDarkBlue : 'white',
                tintColor: item.isReminder ? COLORS.appDarkBlue : COLORS.appDarkGray
              }}
                source={require('../assets/icons/menu/alarm.png')} />
            </View>
          </TouchableOpacity>}

          <TouchableOpacity style={{
            alignItems: 'center',
            justifyContent: 'center',
            height: 40,
            width: 40,
            marginRight: 10
          }}
            onPress={() => {
              var _timings = [...timings]
              _timings[index].isComplete = !_timings[index].isComplete
              setTimings(_timings)
            }} >
            <View style={{
              height: 22,
              width: 22,
              borderRadius: 3,
              overflow: 'hidden'
            }}>
              <Image style={{
                height: 22,
                width: 22,
                backgroundColor: item.isComplete ? COLORS.appDarkBlue : 'white',
                tintColor: item.isComplete ? 'white' : COLORS.appDarkBlue
              }}
                source={item.isComplete ? require('../assets/icons/check.png') : require('../assets/icons/uncheck.png')} />
            </View>
          </TouchableOpacity>

        </View>
        //  : 
        // <TouchableOpacity style={{
        //   height: 32,
        //   width: 70,
        //   borderRadius: 16,
        //   backgroundColor: COLORS.appDarkBlue,
        //   justifyContent: 'center',
        //   alignItems: 'center',
        //   marginLeft: 10
        // }} onPress={gotoAddActivity}>
        //   <Text style={{
        //     fontSize: 14,
        //     color: COLORS.appWhite
        //   }}>+ ADD
        //   </Text>
        // </TouchableOpacity>
      }


    </TouchableOpacity>
  }

  const ActivityIcon = (bgColor, image) => {
    return <View style={{
      height: 40,
      width: 40,
      borderRadius: 20,
      backgroundColor: bgColor,
      overflow: 'hidden',
      justifyContent: 'center',
      alignItems: 'center'
    }}>
      <Image style={{
        height: 20,
        width: 20,
        resizeMode: 'contain',
        tintColor: 'white'
      }}
        source={image} />
    </View>
  }

  const gotoAddActivity = (data) => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddActivity',
        passProps: {
          activityData: data
        },
        options: {
          topBar: {
            title: {
              text: 'Add Activity',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            }
          }
        }
      }
    })
  }

  const gotoGraph = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.EventGraph',
        options: {
          topBar: {
            title: {
              text: '',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            }
          }
        }
      }
    })
  }

  const showActionSheet = () => {
    this.ActionSheet.show()
  }

  // const showActionSheetActivity = () => {
  //   this.ActionSheetActivity.show()
  // }

  return (
    <SafeAreaView style={{
      flex: 1
    }}>
      <View style={{
        flex: 1
      }}>
        <View style={{
          width: Dimensions.get('screen').width,
          height: 44,
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 15,
          justifyContent: 'space-between'
        }}>
          <Text style={{
            fontSize: 20,
            fontWeight: '500'
          }}>
            {/* {moment().format('DD MMMM YYYY')} */}
            {selectedDate}
          </Text>
          <View style={{
            flexDirection: 'row'
          }}>
            <TouchableOpacity
              onPress={showActionSheet} >
              <Image style={{
                height: 28,
                width: 28,
                margin: 5
              }}
                source={require('../assets/icons/more-hor.png')} />
            </TouchableOpacity>
            {/* <TouchableOpacity style={{
              marginLeft: 10
            }}
              onPress={showActionSheet} >
              <Image style={{
                height: 28,
                width: 28,
                margin: 5
              }}
                source={require('../assets/icons/list.png')} />
            </TouchableOpacity> */}
            <TouchableOpacity style={{
              marginLeft: 10
            }} onPress={() => {
              Navigation.showModal({
                component: {
                  name: 'com.planner.EventAlerts'
                }
              })
            }}>
              <Image style={{
                height: 28,
                width: 28,
                margin: 5
              }}
                source={require('../assets/icons/menu/alarm.png')} />
              <View style={{
                height: 18,
                minWidth: 18,
                borderRadius: 9,
                backgroundColor: 'red',
                position: 'absolute',
                right: 0,
                justifyContent: 'center',
                alignItems: 'center',
                borderWidth: 1,
                borderColor: 'white'
              }}>
                <Text style={{
                  fontSize: 10,
                  fontWeight: '500',
                  color: 'white'
                }}>12</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* <View>
          <View style={{
            height: 40,
            flexDirection: 'row',
            justifyContent: 'space-between'
          }}>
            {weekDays.map((item, index) => {
              return <Text style={{
                flex: 1,
                color: '#aaaaaa',
                textAlign: 'center',
                fontSize: 13
              }}>{item}</Text>
            })}
          </View>
          <View style={{
            // height: 30,
            // justifyContent: 'space-between',
          }}>
            <View style={{
              // flex: 1,
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: 0
            }}>
              {weekDates.map((item, index) => {
                return index < 7 &&
                  <View style={{
                    flex: 1,
                    height: 36,
                    // width: 20,
                    // borderRadius: 18,
                    borderTopLeftRadius: item.isStart ? 18 : 0,
                    borderBottomLeftRadius: item.isStart ? 18 : 0,
                    borderTopEndRadius: item.isEnd ? 18 : 0,
                    borderBottomEndRadius: item.isEnd ? 18 : 0,
                    backgroundColor: item.isP ? COLORS.appBlue : 'white',
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}>
                    <Text style={{
                      color: item.isP ? 'white' : '#777777',
                      textAlign: 'center',
                      fontSize: 15,
                    }}>{item.title}</Text>
                  </View>
              })}
            </View>
          </View>
        </View> */}

        {/* <View style={{
          height: 80
        }}> */}
        {/* <Agenda
            style={{
              // flex: 1
            }}
          // hideKnob={true}
          // refreshing={false}
          // refreshControl={null}
          /> */}
        {/* </View> */}

        <ScrollView
          ref={scrollRef}
          style={{
            flex: 1
          }}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onMomentumScrollEnd={(event) => {
            setCurrentPage(Math.round(parseFloat(event.nativeEvent.contentOffset.x / Dimensions.get('window').width)))
          }} >

          <View style={{
            width: Dimensions.get('screen').width,
          }}>
            <ClockView />
          </View>
          <View style={{
            width: Dimensions.get('screen').width,
          }}>
            <ListView />
          </View>
        </ScrollView>
        <PageControl
          style={{ position: 'absolute', left: 0, right: 0, bottom: 20 }}
          numberOfPages={2}
          currentPage={currentPage}
          hidesForSinglePage
          pageIndicatorTintColor={COLORS.appGray}
          currentPageIndicatorTintColor={COLORS.appDarkBlue}
          indicatorStyle={{ borderRadius: 5 }}
          currentIndicatorStyle={{ borderRadius: 5 }}
          indicatorSize={{ width: 8, height: 8 }}
          onPageIndicatorPress={this.onItemTap}
        />
      </View>

      <TouchableOpacity style={{
        height: 60,
        width: 60,
        borderRadius: 30,
        backgroundColor: COLORS.appDarkBlue,
        position: 'absolute',
        left: 20,
        bottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
      }}
        onPress={gotoGraph} >
        <Image style={{
          height: 30,
          width: 30,
          tintColor: 'white'
        }}
          source={require('../assets/icons/graph-icon.png')} />
      </TouchableOpacity>

      <TouchableOpacity style={{
        height: 60,
        width: 60,
        borderRadius: 30,
        backgroundColor: COLORS.appDarkBlue,
        position: 'absolute',
        right: 20,
        bottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
      }}
        onPress={() => gotoAddActivity(null)} >
        <Image style={{
          height: 20,
          width: 20,
          tintColor: 'white'
        }}
          source={require('../assets/icons/plus.png')} />
      </TouchableOpacity>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        // title={''}
        // options={['Creat your default activity', 'Weekend activities', 'cancel']}
        options={viewTypes}
        cancelButtonIndex={3}
        // destructiveButtonIndex={1}
        onPress={(index) => {
          if (index == 0) {
            setCalendar(true)
          }
          else if (index == 1) {
            // alert('In progress')
          }
          else if (index == 2) {
            setSelectedDate(moment(new Date()).format('YYYY-MM-DD'))
          }
        }}
      />

      {/* <ActionSheet
        ref={o => this.ActionSheetActivity = o}
        // title={''}
        // options={['Creat your default activity', 'Weekend activities', 'cancel']}
        options={activityMenu}
        cancelButtonIndex={2}
        destructiveButtonIndex={1}
        onPress={(index) => {
          if (index == 0) {
            
          }
          else if (index == 1) {
            gotoAddActivity(item)
          }
        }}
      /> */}

      {isCalendar && <CalendarPicker selectedDate={selectedDate} dateFormat='DD MMMM YYYY' setDate={setSelectedDate} setCalendar={setCalendar} />}

    </SafeAreaView>
  );
};

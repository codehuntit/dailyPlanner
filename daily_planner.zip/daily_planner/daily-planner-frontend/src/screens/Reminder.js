/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';

export const Reminder = (props) => {
  
  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View style={{
        height: 44,
        marginTop: 10,
        alignItems: 'flex-end',
        justifyContent: 'center',
      }}>
        {/* <Text style={{
          fontSize: 18,
          fontWeight: '500',
          position: 'absolute',
          alignSelf: 'center'
        }}>Reminder</Text> */}
        <TouchableOpacity style={{
          height: 40,
          width: 40,
          justifyContent: 'center',
          alignItems: 'center',
          marginRight: 15
        }}
          onPress={() => {
            Navigation.dismissModal(props.componentId)
          }} >
          <Image style={{
            height: 22,
            width: 22
          }}
            source={require('../assets/icons/journal_menu/close.png')} />
        </TouchableOpacity>
      </View>

      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <View style={{
          height: 44,
          marginTop: 10,
          alignItems: 'center',
          justifyContent: 'space-between',
          flexDirection: 'row',
          paddingHorizontal: 20
        }}>
          <Text style={{
            fontSize: 18,
            fontWeight: '500',
          }}>Reminder</Text>
          <Switch />
        </View>
      </View>

    </SafeAreaView>
  );
};

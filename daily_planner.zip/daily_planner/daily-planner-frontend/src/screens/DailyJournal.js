/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import { Navigation, OptionsModalPresentationStyle } from 'react-native-navigation';
import { COLORS } from '../config/colors';
import moment from 'moment';

const CELL_WIDTH = Dimensions.get('screen').width / 3

export const DailyJournal = (props) => {

  const [isMore, setMore] = useState(false)
  const [isCalendar, setCalendar] = useState(false)
  const [selectedDate, setDate] = useState(moment(new Date()).format('YYYY-MM-DD'))

  const [journals, setJournals] = useState([{
    id: '1',
    title: 'Journal 1',
    icon: require('../assets/icons/menu/edit.png'),
  }, {
    id: '2',
    title: 'Journal 2',
    icon: require('../assets/icons/question-mark.png')
  }, {
    id: '3',
    title: 'Journal 3',
    icon: require('../assets/icons/light.png')
  }, {
    id: '4',
    title: 'Journal 4',
    icon: require('../assets/icons/light.png')
  }, {
    id: '5',
    title: 'Journal 5',
    icon: require('../assets/icons/light.png')
  }, {
    id: '6',
    title: 'Journal 6',
    icon: require('../assets/icons/light.png')
  }, {
    id: '7',
    title: 'Journal 7',
    icon: require('../assets/icons/light.png')
  }, {
    id: '8',
    title: 'Journal 8',
    icon: require('../assets/icons/light.png')
  }, {
    id: '9',
    title: 'Journal 9',
    icon: require('../assets/icons/light.png')
  }, {
    id: '10',
    title: 'Journal 10',
    icon: require('../assets/icons/light.png')
  }])

  useEffect(() => {
    const event = Navigation.events().registerNavigationButtonPressedListener(({ buttonId }) => {
      if (buttonId == 'moremenu') {
        setMore(!isMore)
      }
    })

    return () => {
      event.remove()
    }
  })

  gotoJournalDetail = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.DailyJournalDetail',
        options: {
          topBar: {
            title: {
              text: 'Journal',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            // rightButtons: item.id == '1' ? [{
            //   id: 'addevent',
            //   color: COLORS.appDarkBlue,
            //   icon: Platform.OS == 'ios' ? {
            //     uri: 'more',
            //     scale: 5
            //   } : require('../assets/icons/more.png'),
            // }] : []
          }
        }
      }
    })
  }

  gotoAddJournal = () => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddDailyJournal',
        options: {
          modalPresentationStyle: OptionsModalPresentationStyle.fullScreen
        }
      }
    })
  }

  const JournalCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      flexDirection: 'row'
    }}
      onPress={gotoJournalDetail} >
      <View style={{
        height: 60,
        width: 60,
        marginLeft: 10,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: 30,
        // borderWidth: 2,
        // borderColor: COLORS.appDarkBlue,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <Image style={{
          height: 30,
          width: 30,
          resizeMode: 'contain',
          tintColor: 'white'
        }}
        source={require('../assets/icons/menu/edit.png')}
        />
      </View>
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title + '\n'}<Text style = {{
        color: COLORS.appGray
      }}>{'27-04-2021'}</Text></Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-end',
          alignItems: 'flex-end'
        }}>
        <FlatList
          style={{
            width: '100%'
          }}
          contentContainerStyle={{
            paddingBottom: 85
          }}
          keyExtractor={(item, index) => index}
          data={journals}
          renderItem={JournalCell} />

        <TouchableOpacity style={{
          height: 60,
          width: 60,
          borderRadius: 30,
          backgroundColor: COLORS.appDarkBlue,
          position: 'absolute',
          right: 20,
          bottom: 20,
          justifyContent: 'center',
          alignItems: 'center'
        }}
          onPress={gotoAddJournal} >
          <Image style={{
            height: 20,
            width: 20,
            tintColor: 'white'
          }}
            source={require('../assets/icons/plus.png')} />
        </TouchableOpacity>
      </View>

      {isMore && <View style={{
        position: 'absolute',
        width: '100%',
        height: '100%',
      }}>
        <TouchableOpacity style={{
          flex: 1,
          backgroundColor: '#00000088'
        }}
          onPress={() => {
            setMore(false)
          }} />
        <View style={{
          width: 150,
          backgroundColor: COLORS.appWhite,
          position: 'absolute',
          right: 10,
          top: 5,
          borderRadius: 10,

        }}>
          <FlatList
            data={['All Journal', 'Calendar', 'Today']}
            keyExtractor={(item, index) => index}
            renderItem={({ item, index }) => {
              return <TouchableOpacity style={{
                height: 40,
                justifyContent: 'center',
                alignItems: 'center'
              }}
                onPress={() => {
                  setMore(false)
                  if (index == 1) {
                    setCalendar(true)
                  }
                }} >
                <Text>{item}</Text>
                {index < 2 && <View style={{
                  height: 1,
                  backgroundColor: '#ddd',
                  position: 'absolute',
                  width: '100%',
                  bottom: 0
                }} />}
              </TouchableOpacity>
            }} />
        </View>
      </View>}

      {isCalendar && <View style={{
        position: 'absolute',
        width: '100%',
        height: '100%',
      }}>
        <TouchableOpacity style={{
          flex: 1,
          backgroundColor: '#00000088'
        }}
        activeOpacity = {1.0}
          onPress={() => {
            // setCalendar(false)
          }} />
        <View style={{
          width: '100%',
          backgroundColor: COLORS.appWhite,
          position: 'absolute',
          bottom: 0,
          // top: 5,
          // borderRadius: 10,

        }}>
          <View style={{
            height: 40,
            flexDirection: 'row',
            justifyContent: 'space-between'
          }}>
            <TouchableOpacity style={{
              width: 100,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center'
            }} onPress={() => setCalendar(false)} >
              <Text>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={{
              width: 100,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center'
            }} onPress={() => setCalendar(false)} >
              <Text>Done</Text>
            </TouchableOpacity>
          </View>
          <Calendar
            enableSwipeMonths={true}
          markedDates={{
            [selectedDate]: {selected: true, marked: true, selectedColor: COLORS.appDarkBlue}
          }}
          onDayPress={(date) => {
            setDate(date.dateString)
          }}
          />
        </View>
      </View>}

    </SafeAreaView>
  );
};

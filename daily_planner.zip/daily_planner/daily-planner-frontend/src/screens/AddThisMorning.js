/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
import { WeatherType, MoodType } from '../config/enums'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from 'moment';
import { AppButton } from '../components/AppButton';

export const AddThisMorning = (props) => {

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedDate, setDate] = useState(new Date());
  const [weathers, setWeathers] = useState([])
  const [mood, setMood] = useState(MoodType.none)

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    setDate(date);
    hideDatePicker();
  };

  const addWeather = (weatherType) => {
    // var _weathers = [...weathers]
    if (weathers.includes(weatherType)) {
      // _weathers.splice(_weathers.indexOf(weatherType), 1)
      setWeathers([])
    }
    else {
      // _weathers.push(weatherType)
      setWeathers([weatherType])
    }
    // setWeathers([weatherType])
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        <View style={{
          height: 44,
          alignItems: 'flex-end',
          marginTop: 10
        }}>
          <TouchableOpacity style={{
            height: 40,
            width: 40,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 15
            // borderRadius: 20,
            // borderColor: COLORS.appBlack,
            // borderWidth: 2
          }}
          onPress = {() => {
            Navigation.dismissModal(props.componentId)
          }} >
            <Image style={{
              height: 22,
              width: 22
            }}
              source={require('../assets/icons/journal_menu/close.png')} />
          </TouchableOpacity>
        </View>
        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS == 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            contentContainerStyle={{
              marginTop: 20
            }} >
            <View style={{
              alignItems: 'center'
            }}>
              <View style={{
                height: 40,
                width: '90%',
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Date </Text>
                <TouchableOpacity onPress={showDatePicker}>
                  <Text style={{
                    fontSize: 17,
                    fontWeight: '500',
                    minWidth: 100,
                    marginVertical: 10
                  }}>{selectedDate != null ? moment(selectedDate).format('DD/MM/YYYY hh:mm A') : '__/__/____'}</Text>
                </TouchableOpacity>
              </View>

              <View style={{
                marginTop: 40,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Subject</Text>
                <TextInput style={{
                  borderColor: COLORS.appGray,
                  borderWidth: 2,
                  height: 120,
                  marginVertical: 12,
                  borderRadius: 5,
                  padding: 5
                }}
                placeholder = 'Write your subject'
                  textAlignVertical='top'
                  multiline={true}
                  numberOfLines={0} />
              </View>

              <View style={{
                height: 50,
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '90%',
              }}>
                {/* <View style = {{
                  flex: 1
                }}>
                  <TouchableOpacity style={{
                    height: 40,
                    width: 40,
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: 20,
                    borderColor: COLORS.appBlack,
                    borderWidth: 2
                  }}>
                    <Image style={{
                      height: 22,
                      width: 22
                    }}
                      source={require('../assets/icons/journal_menu/close.png')} />
                  </TouchableOpacity>
                </View> */}
                {/* <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/camera.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/bullet-list.png')} />
                </TouchableOpacity> */}
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 10
                }}>
                  <Image style={{
                    height: 25,
                    width: 25,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/mic.png')} />
                </TouchableOpacity>
              </View>
              <AppButton
                style={{
                  width: '90%',
                  marginTop: 30,
                  backgroundColor: COLORS.appDarkBlue
                }}
                title='Save'
                onPress={() => {
                  Navigation.dismissModal(props.componentId)
                }}
              />
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mood: {
    fontSize: 35,
    marginVertical: 10,
    width: 46,
    height: 46,
    borderRadius: 23,
    textAlign: 'center',
    textAlignVertical: 'center',
    borderColor: COLORS.appBlue,
  }
})
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { COLORS } from '../config/colors';

const dtext = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."

export const InspirationDetail = (props) => {

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        {/* <View style={{
          height: 44,
          alignItems: 'flex-end'
        }}>
          <TouchableOpacity style={{
            height: 40,
            width: 40,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 15
          }}
            onPress={() => {
              Navigation.dismissModal(props.componentId)
            }} >
            <Image style={{
              height: 22,
              width: 22
            }}
              source={require('../assets/icons/journal_menu/close.png')} />
          </TouchableOpacity>
        </View> */}

        {/* <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS == 'ios'} > */}
        <ScrollView style={{
          flex: 1
        }}
          contentContainerStyle={{
            marginTop: 20
          }} >
          <View style={{
            alignItems: 'center'
          }}>



            <View style={{
              marginTop: 10,
              width: '90%',
            }}>
              <Text style={{
                fontSize: 16,
                fontWeight: '500',
              }}>Subject</Text>
              <TextInput style={{
                // borderColor: COLORS.appGray,
                // borderWidth: 2,
                // height: 70,
                marginVertical: 12,
                borderRadius: 5,
                padding: 5
              }}
                scrollEnabled={false}
                value={dtext}
                editable={false}
                textAlignVertical='top'
                multiline={true}
                numberOfLines={0} />
            </View>

            <View style={{
              marginTop: 10,
              width: '90%',
            }}>
              <Text style={{
                fontSize: 16,
                fontWeight: '500',
              }}>Quote</Text>
              <TextInput style={{
                // borderColor: COLORS.appGray,
                // borderWidth: 2,
                // height: 70,
                marginVertical: 12,
                borderRadius: 5,
                padding: 5,

              }}
                scrollEnabled={false}
                value={dtext}
                editable={false}
                textAlignVertical='top'
                multiline={true}
                numberOfLines={0} />
            </View>

            <View style={{
              marginTop: 10,
              width: '90%',
              marginBottom: 10
            }}>
              <Text style={{
                fontSize: 16,
                fontWeight: '500',
              }}>Description</Text>
              <TextInput style={{
                // borderColor: COLORS.appGray,
                // borderWidth: 2,
                // height: 70,
                marginVertical: 12,
                borderRadius: 5,
                padding: 5
              }}
                scrollEnabled={false}
                value={dtext}
                editable={false}
                textAlignVertical='top'
                multiline={true}
                numberOfLines={0} />
            </View>

            <AppButton
              style={{
                width: '90%',
                marginTop: 30,
                // marginHorizontal: 15,
                backgroundColor: COLORS.appDarkBlue
              }}
              title='Edit'
            // onPress={gotoHome}
            />
            <AppButton
              style={{
                width: '90%',
                marginBottom: 20,
                // marginHorizontal: 15,
                marginTop: 20,
                backgroundColor: COLORS.appWhite,
                borderWidth: 2,
                borderColor: COLORS.appDarkBlue,
                marginBottom: 50
              }}
              textColor={COLORS.appDarkBlue}
              title={'Delete'}
            />

            {/* <View style={{
                height: 50,
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '90%',
              }}>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/camera.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/bullet-list.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 10
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/mic.png')} />
                </TouchableOpacity>
              </View> */}
            {/* <AppButton
                style={{
                  width: '90%',
                  marginTop: 30,
                  marginBottom: 50,
                  backgroundColor: COLORS.appDarkBlue
                }}
                title='Save'
              // onPress={gotoHome}
              /> */}
          </View>
        </ScrollView>
        {/* </KeyboardAvoidingView> */}

      </View>
    </SafeAreaView>
  );
};

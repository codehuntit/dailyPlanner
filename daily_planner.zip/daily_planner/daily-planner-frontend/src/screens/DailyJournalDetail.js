/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
import { WeatherType, MoodType } from '../config/enums'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from 'moment';
import { AppButton } from '../components/AppButton';

export const DailyJournalDetail = (props) => {

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedDate, setDate] = useState(null);
  const [weathers, setWeathers] = useState([])
  const [mood, setMood] = useState(MoodType.none)

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    setDate(date);
    hideDatePicker();
  };

  const addWeather = (weatherType) => {
    var _weathers = [...weathers]
    if (_weathers.includes(weatherType)) {
      _weathers.splice(_weathers.indexOf(weatherType), 1)
    }
    else {
      _weathers.push(weatherType)
    }
    setWeathers(_weathers)
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS == 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            contentContainerStyle={{
              marginTop: 20
            }} >
            <View style={{
              alignItems: 'center'
            }}>
              <View style={{
                height: 40,
                width: '90%',
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Date </Text>
                <TouchableOpacity
                // onPress={showDatePicker}
                >
                  <Text style={{
                    fontSize: 17,
                    fontWeight: '500',
                    minWidth: 100,
                    marginVertical: 10
                  }}>{moment(new Date()).format('DD/MM/YYYY')}</Text>
                </TouchableOpacity>
              </View>

              <View style={{
                height: 50,
                width: '90%',
                // flexDirection: 'row',
                // alignItems: 'center',
                // paddingHorizontal: 15,
                marginTop: 40
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 20,
                }}>Weather </Text>

                <View
                  style={{
                    height: 50,
                    width: "80%",
                    flexDirection: 'row',
                    // marginTop: 20,
                    justifyContent: 'center'
                  }}
                >
                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      // addWeather(WeatherType.sunny)
                    }} >
                    {/* <Image style={{
                      height: 20,
                      width: 20,
                    }}
                      source={weathers.includes(WeatherType.sunny) ? require('../assets/icons/checked.png') : require('../assets/icons/uncheck.png')} /> */}
                    <Image style={{
                      height: 35,
                      width: 35,
                      marginLeft: 10,
                    }}
                      source={require('../assets/icons/weathers/sun.png')} />
                  </TouchableOpacity>
                  {/* <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      addWeather(WeatherType.cloudy)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                    }}
                      source={weathers.includes(WeatherType.cloudy) ? require('../assets/icons/checked.png') : require('../assets/icons/uncheck.png')} />
                    <Image style={{
                      height: 35,
                      width: 35,
                      marginLeft: 10
                    }}
                      source={require('../assets/icons/weathers/cloud.png')} />
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      addWeather(WeatherType.rainy)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                    }}
                      source={weathers.includes(WeatherType.rainy) ? require('../assets/icons/checked.png') : require('../assets/icons/uncheck.png')} />
                    <Image style={{
                      height: 35,
                      width: 35,
                      marginLeft: 10
                    }}
                      source={require('../assets/icons/weathers/rain.png')} />
                  </TouchableOpacity> */}
                </View>
              </View>

              <View style={{
                // height: 40,
                // flexDirection: 'row',
                // alignItems: 'center',
                width: '90%',
                // paddingHorizontal: 15,
                marginTop: 35
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                  marginRight: 15,
                }}>Mood </Text>
                <View style={{
                  height: 70,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}>
                  <TouchableOpacity onPress={() => {
                    // setMood(mood == MoodType.fullHappy ? MoodType.none : MoodType.fullHappy)
                  }}>
                    <Text style={[styles.mood, {
                      borderWidth: mood == MoodType.fullHappy ? 2 : 0
                    }]}>😀</Text>
                  </TouchableOpacity>
                  {/* <TouchableOpacity onPress={() => {
                    setMood(mood == MoodType.happy ? MoodType.none : MoodType.happy)
                  }}>
                    <Text style={[styles.mood,
                    {
                      borderWidth: mood == MoodType.happy ? 2 : 0
                    }]}>🙂</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => {
                    setMood(mood == MoodType.normal ? MoodType.none : MoodType.normal)
                  }}>
                    <Text style={[styles.mood,
                    {
                      borderWidth: mood == MoodType.normal ? 2 : 0
                    }]}>😐</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => {
                    setMood(mood == MoodType.sad ? MoodType.none : MoodType.sad)
                  }}>
                    <Text style={[styles.mood,
                    {
                      borderWidth: mood == MoodType.sad ? 2 : 0
                    }]}>🙁</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => {
                    setMood(mood == MoodType.upset ? MoodType.none : MoodType.upset)
                  }}>
                    <Text style={[styles.mood,
                    {
                      borderWidth: mood == MoodType.upset ? 2 : 0
                    }]}>☹️</Text>
                  </TouchableOpacity> */}
                </View>
              </View>

              <View style={{
                marginTop: 10,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Subject</Text>
                <Text style={{
                  padding: 5,
                  fontSize: 15,
                  color: '#333'
                }}>
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </Text>
              </View>

              <AppButton
                style={{
                  width: '90%',
                  marginTop: 30,
                  // marginHorizontal: 15,
                  backgroundColor: COLORS.appDarkBlue
                }}
                title='Edit'
              // onPress={gotoHome}
              />
              <AppButton
                style={{
                  width: '90%',
                  marginBottom: 20,
                  // marginHorizontal: 15,
                  marginTop: 20,
                  backgroundColor: COLORS.appWhite,
                  borderWidth: 2,
                  borderColor: COLORS.appDarkBlue
                }}
                textColor={COLORS.appDarkBlue}
                title={'Delete'}
              />

              {/* <View style={{
                height: 50,
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '90%',
              }}>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/camera.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/bullet-list.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 10
                }}>
                  <Image style={{
                    height: 30,
                    width: 30,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/mic.png')} />
                </TouchableOpacity>
              </View> */}
              {/* <AppButton
                style={{
                  width: '90%',
                  marginTop: 30,
                  backgroundColor: COLORS.appDarkBlue
                }}
                title='Save'
                onPress={gotoHome}
              /> */}
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mood: {
    fontSize: 35,
    marginVertical: 10,
    width: 46,
    height: 46,
    borderRadius: 23,
    textAlign: 'center',
    textAlignVertical: 'center',
    borderColor: COLORS.appBlue,
  }
})
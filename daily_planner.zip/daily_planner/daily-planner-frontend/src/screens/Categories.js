/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const Categories = (props) => {

  // const [menu, setMenu] = useState([{
  //   id: '1',
  //   title: 'Journal',
  //   icon: require('../assets/icons/menu/edit.png')
  // }, {
  //   id: '2',
  //   title: 'Sleep Diary',
  //   icon: require('../assets/icons/menu/sleep.png')
  // }, {
  //   id: '3',
  //   title: 'Calendar',
  //   icon: require('../assets/icons/menu/calendar.png')
  // }, {
  //   id: '4',
  //   title: 'Goals',
  //   icon: require('../assets/icons/menu/goal.png')
  // }, {
  //   id: '5',
  //   title: 'Time Controller',
  //   icon: require('../assets/icons/menu/clock.png')
  // }, {
  //   id: '6',
  //   title: 'Period Tracker',
  //   icon: require('../assets/icons/menu/woman.png')
  // }, {
  //   id: '7',
  //   title: 'Tips',
  //   icon: require('../assets/icons/menu/tips.png')
  // }, {
  //   id: '8',
  //   title: 'Settings',
  //   icon: require('../assets/icons/menu/gears.png')
  // }, {
  //   id: '9',
  //   title: 'Clock',
  //   icon: require('../assets/icons/menu/alarm.png')
  // }])

  // const homeCell = ({ item, index }) => {
  //   return <TouchableOpacity style={{
  //     width: CELL_WIDTH,
  //     height: CELL_WIDTH,
  //     alignItems: 'center'
  //     // backgroundColor: index % 2 == 0 ? COLORS.appWhite : COLORS.appGray
  //   }}>
  //     <View style={{
  //       height: CELL_WIDTH / 1.5,
  //       width: CELL_WIDTH / 1.5,
  //       justifyContent: 'center',
  //       alignItems: 'center',
  //       borderRadius: 15,//(CELL_WIDTH / 1.5) / 2,
  //       backgroundColor: COLORS.appWhite,
  //       shadowRadius: 5,
  //       shadowOffset: {
  //         width: 2,
  //         height: 3,
  //       },
  //       shadowColor: 'black',
  //       elevation: 5,
  //       shadowOpacity: 0.3
  //     }}>
  //       <Image style={{
  //         height: CELL_WIDTH / 3.5,
  //         width: CELL_WIDTH / 3.5,
  //         resizeMode: 'contain',
  //         tintColor: COLORS.appDarkBlue
  //       }}
  //         source={item.icon}
  //       />
  //     </View>
  //     <Text style={{
  //       width: '100%',
  //       height: 40,
  //       textAlign: 'center',
  //       marginTop: 12,
  //       color: COLORS.appDarkBlue,
  //       fontSize: 16,
  //       fontWeight: '500'
  //     }}>{item.title}</Text>
  //   </TouchableOpacity>
  // }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appGray
        }}>
        {/* <FlatList
          contentContainerStyle = {{
            marginTop: 30
          }}
          numColumns={3}
          data={menu}
          renderItem={homeCell} /> */}
      </View>
    </SafeAreaView>
  );
};

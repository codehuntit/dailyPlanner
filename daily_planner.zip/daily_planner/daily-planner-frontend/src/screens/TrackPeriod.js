/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { COLORS } from '../config/colors';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from 'moment';
import { ActivityRepeatMode } from '../config/enums'
import { Calendar } from 'react-native-calendars';

const CELL_WIDTH = Dimensions.get('screen').width * 0.8

export const TrackPeriod = (props) => {

  const [isStartDatePickerVisible, setStartDatePickerVisibility] = useState(false);
  const [isEndDatePickerVisible, setEndDatePickerVisibility] = useState(false);

  const [selectedStartDate, setStartDate] = useState(new Date())
  const [selectedEndDate, setEndDate] = useState(null)

  const showStartDatePicker = () => {
    setStartDatePickerVisibility(true);
  };

  const hideStartDatePicker = () => {
    setStartDatePickerVisibility(false);
  };

  const handleStartDateConfirm = (date) => {
    setStartDate(date);
    hideStartDatePicker();
  };

  const showEndDatePicker = () => {
    setEndDatePickerVisibility(true);
  };

  const hideEndDatePicker = () => {
    setEndDatePickerVisibility(false);
  };

  const handleEndDateConfirm = (date) => {
    setEndDate(date);
    hideEndDatePicker();
  };


  const addEvent = () => {

  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite,
          alignItems: 'center'
        }}>
        <View style={{
          height: 44,
          width: '100%',
          alignItems: 'flex-end',
          justifyContent: 'center',
          marginTop: 10
        }}>
          <Text style={{
            fontSize: 18,
            fontWeight: '500',
            position: 'absolute',
            alignSelf: 'center'
          }}>Period Track</Text>
          <TouchableOpacity style={{
            height: 40,
            width: 40,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 15
          }}
            onPress={() => {
              Navigation.dismissModal(props.componentId)
            }} >
            <Image style={{
              height: 22,
              width: 22
            }}
              source={require('../assets/icons/journal_menu/close.png')} />
          </TouchableOpacity>
        </View>

        <View style={{
          alignItems: 'center',
          width: '100%'
        }}>
          {/* <View style={{
            minHeight: 40,
            width: '90%',
            // marginTop: 30
            // flexDirection: 'row',
            // alignItems: 'center',
            // paddingHorizontal: 15
          }}>
            <Text style={{
              fontSize: 16,
              fontWeight: '500',
              marginRight: 20,
              marginTop: 20
            }}>Period Start Date</Text>
            <TouchableOpacity
              style={{
                height: 40,
                justifyContent: 'center'
              }}
              onPress={showStartDatePicker}>
              <Text style={{
                fontSize: 17,
                // fontWeight: '500',
                minWidth: 100
              }}>{selectedStartDate != null ? moment(selectedStartDate).format('DD/MM/YYYY') : '__/__/____'}</Text>
            </TouchableOpacity>
          </View> */}

          <View style={{
            paddingHorizontal: 15,
            marginTop: 10,
            width: '100%'
          }}>
            <Text style={{
              fontSize: 16,
              fontWeight: '500',
              marginRight: 20,
            }}>Period Start Date</Text>
            <TouchableOpacity
              style={{
                height: 44,
                width: '100%',
                paddingHorizontal: 15,
                marginTop: 10,
                backgroundColor: '#eee',
                borderRadius: 7,
                justifyContent: 'center'
              }}
              onPress={showStartDatePicker}>
              <Text style={{
                fontSize: 17,
                fontWeight: '500',
                minWidth: 100,
                marginVertical: 10
              }}>{selectedStartDate != null ? moment(selectedStartDate).format('DD/MM/YYYY') : ''}</Text>
            </TouchableOpacity>
          </View>

          {/* <View style={{
            minHeight: 40,
            width: '90%',
            // marginTop: 30
            // flexDirection: 'row',
            // alignItems: 'center',
            // paddingHorizontal: 15
          }}>
            <Text style={{
              fontSize: 16,
              fontWeight: '500',
              marginRight: 20,
              marginTop: 20
            }}>Period End Date</Text>
            <TouchableOpacity
              style={{
                height: 40,
                justifyContent: 'center'
              }}
              onPress={showEndDatePicker}>
              <Text style={{
                fontSize: 17,
                // fontWeight: '500',
                minWidth: 100
              }}>{selectedEndDate != null ? moment(selectedEndDate).format('DD/MM/YYYY') : '__/__/____'}</Text>
            </TouchableOpacity>
          </View> */}

          <View style={{
            paddingHorizontal: 15,
            marginTop: 10,
            width: '100%'
          }}>
            <Text style={{
              fontSize: 16,
              fontWeight: '500',
              marginRight: 20,
            }}>Period End Date</Text>
            <TouchableOpacity
              style={{
                height: 44,
                width: '100%',
                paddingHorizontal: 15,
                marginTop: 10,
                backgroundColor: '#eee',
                borderRadius: 7,
                justifyContent: 'center'
              }}
              onPress={showEndDatePicker}>
              <Text style={{
                fontSize: 17,
                fontWeight: '500',
                minWidth: 100,
                marginVertical: 10
              }}>{selectedEndDate != null ? moment(selectedEndDate).format('DD/MM/YYYY') : ''}</Text>
            </TouchableOpacity>
          </View>


        </View>
        <AppButton
          style={{
            width: '90%',
            marginTop: 30,
            marginBottom: 40,
            backgroundColor: COLORS.appDarkBlue
          }}
          title='Continue'
          onPress={addEvent}
        />
      </View>

      <DateTimePickerModal
        isVisible={isStartDatePickerVisible}
        mode="date"
        onConfirm={handleStartDateConfirm}
        onCancel={hideStartDatePicker}
      />

      <DateTimePickerModal
        isVisible={isEndDatePickerVisible}
        mode="date"
        onConfirm={handleEndDateConfirm}
        onCancel={hideEndDatePicker}
      />


    </SafeAreaView>
  );
};

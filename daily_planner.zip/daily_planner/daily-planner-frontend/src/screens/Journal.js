/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const Journal = (props) => {

  const [journals, setJournals] = useState([{
    id: '1',
    title: 'Daily Journal',
    icon: require('../assets/icons/menu/edit.png'),
    componentId: 'com.planner.DailyJournal'
  }, {
    id: '2',
    title: 'Questions',
    icon: require('../assets/icons/question-mark.png'),
    componentId: 'com.planner.Questions'
  }, {
    id: '3',
    title: 'Inspiration',
    icon: require('../assets/icons/light.png'),
    componentId: 'com.planner.Inspirations'
  }])

  gotoScreen = (item) => {
    Navigation.push(props.componentId, {
      component: {
        name: item.componentId,
        options: {
          topBar: {
            title: {
              text: item.title,
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            rightButtons: item.id == '1' ? [{
              id: 'moremenu',
              color: COLORS.appDarkBlue,
              icon: Platform.OS == 'ios' ? {
                uri: 'more',
                scale: 5
              } : require('../assets/icons/more.png'),
            }] : []
          }
        }
      }
    })
  }

  const JournalCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 70,
      alignItems: 'center',
      flexDirection: 'row'
    }}
    onPress = {() => gotoScreen(item)} >
      <View style={{
        height: 50,
        width: 50,
        marginLeft: 10,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: 25,
        // borderWidth: 2,
        // borderColor: COLORS.appDarkBlue,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <Image style={{
          height: 22,
          width: 22,
          resizeMode: 'contain',
          tintColor: 'white'
        }}
          source={item.icon} />
      </View>
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title}</Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        <FlatList
          data={journals}
          renderItem={JournalCell} />
      </View>
    </SafeAreaView>
  );
};

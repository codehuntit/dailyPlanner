/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const Goals = (props) => {

  const [goals, setGoals] = useState([{
    id: '1',
    title: 'Weekly Goals',
    iconText: '7'
    // icon: require('../assets/icons/goals/week.png')
  }, {
    id: '2',
    title: 'Monthly Goals',
    iconText: '31'
    // icon: require('../assets/icons/goals/month.png')
  }, {
    id: '3',
    title: 'Quarterly Goals',
    iconText: '1/4'
    // icon: require('../assets/icons/goals/quarter.png')
  }, {
    id: '4',
    title: 'Annual Goals',
    iconText: '365'
    // icon: require('../assets/icons/goals/year.png')
  }])

  const gotoGoalsList = (item, index) => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.GoalsList',
        options: {
          topBar: {
            title: {
              text: item.title,
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            rightButtons: [{
              id: 'reminder',
              color: COLORS.appDarkBlue,
              text: 'Reminder'
            }]
          }
        }
      }
    })
  }

  const GoalCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      flexDirection: 'row'
    }}
    onPress = {() => gotoGoalsList(item, index)} >
      <View style={{
        height: 60,
        width: 60,
        marginLeft: 10,
        backgroundColor: COLORS.appWhite,
        borderRadius: 30,
        borderWidth: 2,
        borderColor: COLORS.appDarkBlue,
        overflow: 'hidden',
        alignItems: 'center',
      }} >
        <View style={{
          height: 15,
          width: '100%',
          backgroundColor: COLORS.appDarkBlue
        }} />
        <Text style={{
          fontSize: 20,
          fontWeight: '600',
          marginTop: 5,
          color: '#555'
        }}>{item.iconText}
        </Text>
      </View>
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title}</Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <FlatList
          data={goals}
          renderItem={GoalCell} />
      </View>
    </SafeAreaView>
  );
};

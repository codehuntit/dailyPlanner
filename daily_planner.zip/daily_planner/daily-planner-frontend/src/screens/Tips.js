/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const Tips = (props) => {

  const [tips, setTips] = useState([{
    id: '1',
    title: 'Morning tips',
    icon: require('../assets/icons/tips/morning.png')
  }, {
    id: '2',
    title: 'Afternoon tips',
    icon: require('../assets/icons/tips/afternoon.jpeg')
  }, {
    id: '3',
    title: 'Journal tips',
    icon: require('../assets/icons/tips/journal.jpeg')
  }, {
    id: '4',
    title: 'Sleep diary tips',
    icon: require('../assets/icons/tips/sleep-diary.jpeg')
  }, {
    id: '5',
    title: 'sleeping tips',
    icon: require('../assets/icons/tips/sleeping.jpeg')
  }])

  const TipCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      flexDirection: 'row'
    }} 
    onPress={() => {
      gotoTipDetail(item.title)
    }}>
      <Image style={{
        height: 60,
        width: 60,
        marginLeft: 10,
        backgroundColor: '#999',
        borderRadius: 30,
        borderWidth: 2,
        borderColor: COLORS.appBlue
      }}
        source={item.icon} />
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title}</Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  const gotoTipDetail = (title) => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.TipDetail',
        options: {
          topBar: {
            title: {
              text: title,
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            }
          }
        }
      }
    })
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <FlatList
          data={tips}
          renderItem={TipCell} />
      </View>
    </SafeAreaView>
  );
};

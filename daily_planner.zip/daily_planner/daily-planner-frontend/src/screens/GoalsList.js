/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const GoalsList = (props) => {

  const [goals, setGoals] = useState([{
    id: '1',
    title: 'Goal 1',
    fromDate: '14/04/2021',
    toDate: '23/04/2021',
    isReminder: false
  }, {
    id: '2',
    title: 'Goal 2',
    fromDate: '01/04/2021',
    toDate: '06/04/2021',
    isReminder: false
  }, {
    id: '3',
    title: 'Goal 3',
    fromDate: '12/04/2021',
    toDate: '24/04/2021',
    isReminder: false
  }, {
    id: '4',
    title: 'Goal 4',
    fromDate: '26/05/2021',
    toDate: '07/06/2021',
    isReminder: false
  }])

  useEffect(() => {
    const event = Navigation.events().registerNavigationButtonPressedListener(({ buttonId }) => {
      if (buttonId == 'reminder') {
        Navigation.showModal({
          component: {
            name: 'com.planner.Reminder'
          }
        })
      }
    })

    return () => {
      event.remove()
    }
  })

  const gotoAddGoal = () => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddGoal',
        passProps: {
          goalData: null
        }
      }
    })
  }

  const gotoEditGoal = (goalData) => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddGoal',
        passProps: {
          goalData: goalData
        }
      }
    })
  }

  const GoalCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      justifyContent: 'space-between',
      flexDirection: 'row'
    }}
      onPress={() => {
        gotoEditGoal(item)
      }} >
      <View>
        <Text style={{
          fontSize: 18,
          fontWeight: '500',
          marginHorizontal: 10
        }}>{item.title}</Text>
        <Text style={{
          fontSize: 16,
          marginHorizontal: 10,
          color: COLORS.appDarkGray
        }}>{item.fromDate + ' - ' + item.toDate}</Text>
      </View>
      <TouchableOpacity style={{
        alignItems: 'center',
        justifyContent: 'center',
        height: 40,
        width: 40,
        marginRight: 10
      }}
        onPress={() => {
          var _goals = [...goals]
          _goals[index].isReminder = !_goals[index].isReminder
          setGoals(_goals)
        }} >
        <View style={{
          height: 22,
          width: 22,
          borderRadius: 3,
          overflow: 'hidden'
        }}>
          <Image style={{
            height: 22,
            width: 22,
            backgroundColor: item.isReminder ? COLORS.appDarkBlue : 'white',
            tintColor: item.isReminder ? 'white' : COLORS.appDarkBlue
          }}
            source={item.isReminder ? require('../assets/icons/check.png') : require('../assets/icons/uncheck.png')} />
        </View>
      </TouchableOpacity>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <FlatList
          data={goals}
          renderItem={GoalCell} />
      </View>

      <TouchableOpacity style={{
        height: 60,
        width: 60,
        borderRadius: 30,
        backgroundColor: COLORS.appDarkBlue,
        position: 'absolute',
        right: 20,
        bottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
      }}
        onPress={gotoAddGoal}
      >
        <Image style={{
          height: 20,
          width: 20,
          tintColor: 'white'
        }}
          source={require('../assets/icons/plus.png')} />
      </TouchableOpacity>

    </SafeAreaView>
  );
};

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { PieChart } from 'react-native-chart-kit';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
import moment from 'moment';
import ActionSheet from 'react-native-actionsheet';
import { ViewType } from '../config/enums';

const screenWidth = Dimensions.get('screen').width

const data = [
  {
    name: "Entertainment",
    population: 2150000,
    color: "rgba(131, 167, 234, 1)",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }, {
    name: "Work",
    population: 2800000,
    color: "#F00",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }, {
    name: "Exercise",
    population: 527612,
    color: "orange",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }, {
    name: "Sleep",
    population: 8538000,
    color: "#534564",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }, {
    name: "Food",
    population: 2119200,
    color: "rgb(134, 34, 255)",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }, {
    name: "Study",
    population: 1192004,
    color: "rgb(23, 134, 255)",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }, {
    name: "Read",
    population: 11920000,
    color: "rgb(199, 56, 125)",
    legendFontColor: "#7F7F7F",
    legendFontSize: 15
  }
];

const chartConfig = {
  backgroundGradientFrom: "#1E2923",
  backgroundGradientFromOpacity: 0,
  backgroundGradientTo: "#08130D",
  backgroundGradientToOpacity: 0.5,
  color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
  strokeWidth: 2, // optional, default 3
  barPercentage: 0.5,
  useShadowColorFromDataset: false // optional
};

export const EventGraph = (props) => {
  const [selectedDate, setSelectedDate] = useState(moment(new Date()).format('DD MMMM YYYY'))
  const [viewTypes, setViewTypes] = useState(['Monthly Calendar', 'Weekly Calendar', 'Cancel'])

  const showActionSheet = () => {
    this.ActionSheet.show()
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          // height: '100%',
          alignItems: 'center'
        }}>
        <View style={{
          width: Dimensions.get('screen').width,
          height: 44,
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 15,
          justifyContent: 'space-between'
        }}>
          <Text style={{
            fontSize: 20,
            fontWeight: '500'
          }}>
            {selectedDate}
          </Text>
          <View style={{
            flexDirection: 'row'
          }}>
            <TouchableOpacity
              onPress={showActionSheet} >
              <Image style={{
                height: 28,
                width: 28,
                margin: 5
              }}
                source={require('../assets/icons/more-hor.png')} />
            </TouchableOpacity>
            {/* <TouchableOpacity style={{
              marginLeft: 10
            }}
              onPress={showActionSheet} >
              <Image style={{
                height: 28,
                width: 28,
                margin: 5
              }}
                source={require('../assets/icons/list.png')} />
            </TouchableOpacity> */}
            
          </View>
        </View>

        <PieChart
          data={data}
          width={screenWidth}
          height={screenWidth / 1.8}
          chartConfig={chartConfig}
          accessor={"population"}
          backgroundColor={"transparent"}

        // paddingLeft={"30"}

        // center={[10, 50]}
        // absolute
        />
      </View>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        // title={''}
        // options={['Creat your default activity', 'Weekend activities', 'cancel']}
        options={viewTypes}
        cancelButtonIndex={2}
        // destructiveButtonIndex={1}
        onPress={(index) => { /* do something */ }}
      />

    </SafeAreaView>
  );
};

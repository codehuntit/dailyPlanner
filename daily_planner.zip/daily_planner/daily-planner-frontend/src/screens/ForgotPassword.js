/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
  Dimensions,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { AppTextInput } from '../components/AppTextInput';
import { COLORS } from '../config/colors';

export const ForgotPassword = (props) => {
  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS = 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            bounces={false} >
            <View style={{
              height: Dimensions.get('screen').height / 1.2,
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {/* <View style={{
              height: Dimensions.get('screen').height / 2,
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              backgroundColor: COLORS.appDarkBlue
            }} /> */}
              <Image style={{
                height: 150,
                width: 150,
                // tintColor: 'white'
              }}
                source={require('../assets/icons/logo.png')} />

              <View style={{
                width: '90%',
                alignItems: 'center',
                justifyContent: 'center',
                marginVertical: 30,
                backgroundColor: 'white',
                borderRadius: 20,
                shadowRadius: 5,
                shadowOffset: {
                  width: 2,
                  height: 3,
                },
                shadowColor: 'black',
                elevation: 5,
                shadowOpacity: 0.3
              }}>

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 25
                  }}
                  icon={require('../assets/icons/at.png')}
                  label='EMAIL'
                  placeholder='EMAIL' />

                <AppButton
                  style={{
                    width: '90%',
                    marginVertical: 30
                  }}
                  title='Submit' />

              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </SafeAreaView>
  );
};

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { COLORS } from '../config/colors';
import ActionSheet from 'react-native-actionsheet';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';

export const AddInspiration = (props) => {

  const [selectedImage, setSecectedImage] = useState(null);

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        <View style={{
          height: 44,
          alignItems: 'flex-end',
          marginTop: 10
        }}>
          <TouchableOpacity style={{
            height: 40,
            width: 40,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 15
          }}
            onPress={() => {
              Navigation.dismissModal(props.componentId)
            }} >
            <Image style={{
              height: 22,
              width: 22
            }}
              source={require('../assets/icons/journal_menu/close.png')} />
          </TouchableOpacity>
        </View>

        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS == 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            contentContainerStyle={{
              marginTop: 20
            }} >
            <View style={{
              alignItems: 'center'
            }}>

              <Text style={{
                fontSize: 22,
                fontWeight: '600',
                width: '95%',
                textAlign: 'center',
                marginBottom: 20,
                color: COLORS.appDarkBlue
              }}>Save what Inspires you</Text>

              <View style={{
                marginTop: 10,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Subject</Text>
                <TextInput style={{
                  borderColor: COLORS.appGray,
                  borderWidth: 2,
                  height: 70,
                  marginVertical: 12,
                  borderRadius: 5,
                  padding: 5
                }}
                  textAlignVertical='top'
                  multiline={true}
                  numberOfLines={0} />
              </View>

              <View style={{
                marginTop: 10,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Quote</Text>
                <TextInput style={{
                  borderColor: COLORS.appGray,
                  borderWidth: 2,
                  height: 70,
                  marginVertical: 12,
                  borderRadius: 5,
                  padding: 5
                }}
                  textAlignVertical='top'
                  multiline={true}
                  numberOfLines={0} />
              </View>

              <View style={{
                marginTop: 10,
                width: '90%',
              }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: '500',
                }}>Description</Text>
                <TextInput style={{
                  borderColor: COLORS.appGray,
                  borderWidth: 2,
                  height: 70,
                  marginVertical: 12,
                  borderRadius: 5,
                  padding: 5
                }}
                  textAlignVertical='top'
                  multiline={true}
                  numberOfLines={0} />
              </View>

              <View style={{
                height: 50,
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '90%',
              }}>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}
                  onPress={() => {
                    this.ActionSheet.show()
                  }} >
                  <Image style={{
                    height: 25,
                    width: 25,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/camera.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 15
                }}>
                  <Image style={{
                    height: 25,
                    width: 25,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/bullet-list.png')} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  height: 40,
                  width: 40,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginLeft: 10
                }}>
                  <Image style={{
                    height: 25,
                    width: 25,
                    tintColor: COLORS.appBlack
                  }}
                    source={require('../assets/icons/journal_menu/mic.png')} />
                </TouchableOpacity>
              </View>
              <AppButton
                style={{
                  width: '90%',
                  marginTop: 30,
                  backgroundColor: COLORS.appDarkBlue
                }}
                title='Save'
              // onPress={gotoHome}
              />
            </View>
          </ScrollView>
        </KeyboardAvoidingView>

      </View>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
        }}
      />

    </SafeAreaView>
  );
};

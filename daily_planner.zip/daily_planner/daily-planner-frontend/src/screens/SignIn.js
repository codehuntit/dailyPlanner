/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { ApiClient } from '../api/ApiClient';
import { AppButton } from '../components/AppButton';
import { AppTextInput } from '../components/AppTextInput';
import { Loader } from '../components/Loader';
import { COLORS } from '../config/colors';
import { validate } from '../config/extensions';

export const SignIn = (props) => {

  const [isLoader, setLoader] = useState(false)

  const [email, setEmail] = useState('')
  const [emailError, setEmailError] = useState('')

  const [password, setPassword] = useState('')
  const [passwordError, setPasswordError] = useState('')

  const gotoForgotPassword = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.ForgotPassword',
        options: {
          topBar: {
            title: {
              text: 'Forgot Password',
              color: COLORS.appBlue
            },
            backButton: {
              color: COLORS.appBlue
            }
          }
        }
      }
    })
  }

  const clearAllMessages = () => {
    setEmailError('')
    setPasswordError('')
  }

  const validateData = () => {
    clearAllMessages()
    if (email == '') {
      setEmailError('Please enter email.')
    }
    else if(!validate(email)) {
      setEmailError('Please enter valid email.')
    }

    if (password == '') {
      setPasswordError('Please enter password.')
    }
    
    if(email != '' && validate(email) && password != '') {
      loginRequest()
    }
  }

  const loginRequest = () => {
    gotoHome()
    // ApiClient.fetchPost('login', {}, true, setLoader, (data) => {
    //     alert(JSON.stringify(data))
    // }, (error) => {
    //     alert(error)
    // })
  }

  const gotoHome = () => {
    Navigation.setRoot({
      root: {
        bottomTabs: {
          id: 'BOTTOM_TABS_ID',
          children: [
            {
              stack: {
                id: 'com.planner.TimeController',
                children: [
                  {
                    component: {
                      name: 'com.planner.TimeController',
                      options: {
                        topBar: {
                          title: {
                            text: 'Home',
                            color: COLORS.appDarkBlue
                          }
                        },
                      }
                    }
                  }
                ],
                options: {
                  bottomTab: {
                    iconColor: COLORS.appGray,
                    textColor: COLORS.appGray,
                    selectedIconColor: COLORS.appDarkBlue,
                    selectedTextColor: COLORS.appDarkBlue,
                    text: 'Home',
                    icon: Platform.OS == 'ios' ? {
                      scale: 20,
                      uri: 'home'
                    } : require('../assets/icons/home.png'),
                  }
                }
              }
            },
            {
              stack: {
                id: 'com.planner.Home',
                children: [
                  {
                    component: {
                      name: 'com.planner.Home',
                      options: {
                        topBar: {
                          title: {
                            text: 'Categories',
                            color: COLORS.appDarkBlue
                          }
                        },
                      }
                    }
                  }
                ],
                options: {
                  bottomTab: {
                    iconColor: COLORS.appGray,
                    textColor: COLORS.appGray,
                    selectedIconColor: COLORS.appDarkBlue,
                    selectedTextColor: COLORS.appDarkBlue,
                    text: 'Categories',
                    icon: Platform.OS == 'ios' ? {
                      scale: 20,
                      uri: 'category'
                    } : require('../assets/icons/category.png'),
                  }
                }
              }
            },
            {
              stack: {
                id: 'com.planner.DailyJournal',
                children: [
                  {
                    component: {
                      name: 'com.planner.DailyJournal',
                      options: {
                        topBar: {
                          title: {
                            text: 'Daily',
                            color: COLORS.appDarkBlue
                          }
                        },
                      }
                    }
                  }
                ],
                options: {
                  bottomTab: {
                    iconColor: COLORS.appGray,
                    textColor: COLORS.appGray,
                    selectedIconColor: COLORS.appDarkBlue,
                    selectedTextColor: COLORS.appDarkBlue,
                    text: 'Daily',
                    icon: Platform.OS == 'ios' ? {
                      scale: 20,
                      uri: 'calendar'
                    } : require('../assets/icons/calendar.png'),
                  }
                }
              }
            },
            {
              stack: {
                id: 'com.planner.Settings',
                children: [
                  {
                    component: {
                      name: 'com.planner.Settings',
                      options: {
                        topBar: {
                          title: {
                            text: 'Settings',
                            color: COLORS.appDarkBlue
                          }
                        },
                      }
                    }
                  }
                ],
                options: {
                  bottomTab: {
                    iconColor: COLORS.appGray,
                    textColor: COLORS.appGray,
                    selectedIconColor: COLORS.appDarkBlue,
                    selectedTextColor: COLORS.appDarkBlue,
                    text: 'Settings',
                    icon: Platform.OS == 'ios' ? {
                      scale: 20,
                      uri: 'gear'
                    } : require('../assets/icons/gear.png'),
                  }
                }
              }
            },
          ]
        }
      }
    })
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS = 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            bounces={false} >
            <View style={{
              height: Dimensions.get('screen').height / 1.2,
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {/* <View style={{
              height: Dimensions.get('screen').height / 2,
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              backgroundColor: COLORS.appDarkBlue
            }} /> */}
              <Image style={{
                height: 150,
                width: 150,
                // tintColor: 'white'
              }}
                source={require('../assets/icons/logo.png')} />

              <View style={{
                width: '90%',
                alignItems: 'center',
                justifyContent: 'center',
                marginVertical: 30,
                backgroundColor: 'white',
                borderRadius: 20,
                shadowRadius: 5,
                shadowOffset: {
                  width: 2,
                  height: 3,
                },
                shadowColor: 'black',
                elevation: 5,
                shadowOpacity: 0.3
              }}>

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 15
                  }}
                  icon={require('../assets/icons/at.png')}
                  errorMessage={emailError}
                  onChangeText={setEmail}
                  value = {email}
                  keyboardType={'email-address'}
                  label='EMAIL'
                  placeholder='EMAIL' />

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 15
                  }}
                  icon={require('../assets/icons/padlock.png')}
                  errorMessage={passwordError}
                  onChangeText={setPassword}
                  value = {password}
                  secureTextEntry = {true}
                  label='PASSWORD'
                  placeholder='PASSWORD' />

                <TouchableOpacity style={{
                  alignSelf: 'flex-end',
                  marginRight: 30
                }}
                  onPress={gotoForgotPassword} >
                  <Text style={{
                    marginTop: 20,
                    marginVertical: 10,
                    fontSize: 16,
                    color: COLORS.appBlue
                  }}>Forgot Password?</Text>
                </TouchableOpacity>

                <AppButton
                  style={{
                    width: '90%',
                    marginTop: 5
                  }}
                  title='Sign In'
                  // onPress={validateData}
                  onPress = {loginRequest}
                   />

                <Text style={{
                  fontSize: 17,
                  fontWeight: '500',
                  marginTop: 10,
                  height: 50,
                  color: COLORS.appGray
                }}>Don't have an account? <Text
                  style={{
                    color: COLORS.appBlue
                  }}
                  onPress={() => {
                    Navigation.pop(props.componentId)
                  }}>Register</Text></Text>

              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>

      {/* <Loader visible = {isLoader} /> */}

    </SafeAreaView>
  );
};

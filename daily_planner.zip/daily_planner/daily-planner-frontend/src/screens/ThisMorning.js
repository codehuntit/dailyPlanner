/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation, OptionsModalPresentationStyle } from 'react-native-navigation';
import { COLORS } from '../config/colors';

export const ThisMorning = (props) => {

  const [questions, setQuestions] = useState([{
    id: '1',
    title: 'Dummy 1',
    icon: require('../assets/icons/menu/edit.png'),
    date: '21/03/2021 11:30 AM'
  }, {
    id: '2',
    title: 'Dummy 2',
    icon: require('../assets/icons/question-mark.png'),
    date: '21/03/2021 11:30 AM'
  }, {
    id: '3',
    title: 'Dummy 3',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM'
  }, {
    id: '4',
    title: 'Dummy 4',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM'
  }, {
    id: '5',
    title: 'Dummy 5',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM'
  }, {
    id: '6',
    title: 'Dummy 6',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM'
  }])

  gotoThisMorningDetail = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.ThisMorningDetail',
        options: {
          topBar: {
            title: {
              text: 'This Morning',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            // rightButtons: item.id == '1' ? [{
            //   id: 'addevent',
            //   color: COLORS.appDarkBlue,
            //   icon: Platform.OS == 'ios' ? {
            //     uri: 'more',
            //     scale: 5
            //   } : require('../assets/icons/more.png'),
            // }] : []
          }
        }
      }
    })
  }

  gotoAddDream = () => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddThisMorning',
        options: {
          modalPresentationStyle: OptionsModalPresentationStyle.fullScreen
        }
      }
    })
  }

  const DreamCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      flexDirection: 'row'
    }}
      onPress={gotoThisMorningDetail} >
      <View style={{
        height: 60,
        width: 60,
        marginLeft: 10,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: 30,
        // borderWidth: 2,
        // borderColor: COLORS.appDarkBlue,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <Image style={{
          height: 30,
          width: 30,
          resizeMode: 'contain',
          tintColor: 'white'
        }}
        source={require('../assets/icons/dreaming.png')}
        />
      </View>
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title + '\n'}<Text style = {{
        color: COLORS.appGray
      }}>{item.date}</Text></Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-end',
          alignItems: 'flex-end'
        }}>
        <FlatList
          style={{
            width: '100%'
          }}
          contentContainerStyle={{
            paddingBottom: 85
          }}
          keyExtractor={(item, index) => index}
          data={questions}
          renderItem={DreamCell} />

        <TouchableOpacity style={{
          height: 60,
          width: 60,
          borderRadius: 30,
          backgroundColor: COLORS.appDarkBlue,
          position: 'absolute',
          right: 20,
          bottom: 20,
          justifyContent: 'center',
          alignItems: 'center'
        }}
          onPress={gotoAddDream} >
          <Image style={{
            height: 20,
            width: 20,
            tintColor: 'white'
          }}
            source={require('../assets/icons/plus.png')} />
        </TouchableOpacity>
      </View>

    </SafeAreaView>
  );
};

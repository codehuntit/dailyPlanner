/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { COLORS } from '../config/colors';

const dtext = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."

export const TipDetail = (props) => {

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
        }}>
        <ScrollView style={{
          flex: 1
        }}
          contentContainerStyle={{
            marginTop: 20
          }} >
          <View style={{
            alignItems: 'center'
          }}>

          <Image 
          style = {{
            width: '60%',
            aspectRatio: 1
          }}
          source = {require('../assets/icons/pig.png')} />

            <View style={{
              marginTop: 10,
              width: '90%',
            }}>
              <Text style={{
                fontSize: 16,
                fontWeight: '500',
              }}>Tip</Text>
              <TextInput style={{
                // borderColor: COLORS.appGray,
                // borderWidth: 2,
                // height: 70,
                marginVertical: 12,
                borderRadius: 5,
                padding: 5
              }}
                scrollEnabled={false}
                value={dtext}
                editable={false}
                textAlignVertical='top'
                multiline={true}
                numberOfLines={0} />
            </View>

          </View>
        </ScrollView>

      </View>
    </SafeAreaView>
  );
};

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation, OptionsModalPresentationStyle } from 'react-native-navigation';
import { COLORS } from '../config/colors';

export const Questions = (props) => {

  const [questions, setQuestions] = useState([{
    id: '1',
    title: 'Question 1',
    icon: require('../assets/icons/menu/edit.png'),
  }, {
    id: '2',
    title: 'Question 2',
    icon: require('../assets/icons/question-mark.png')
  }, {
    id: '3',
    title: 'Question 3',
    icon: require('../assets/icons/light.png')
  }, {
    id: '4',
    title: 'Question 4',
    icon: require('../assets/icons/light.png')
  }, {
    id: '5',
    title: 'Question 5',
    icon: require('../assets/icons/light.png')
  }, {
    id: '6',
    title: 'Question 6'
  }])

  gotoQuestionDetail = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.QuestionDetail',
        options: {
          topBar: {
            title: {
              text: 'Question',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            // rightButtons: item.id == '1' ? [{
            //   id: 'addevent',
            //   color: COLORS.appDarkBlue,
            //   icon: Platform.OS == 'ios' ? {
            //     uri: 'more',
            //     scale: 5
            //   } : require('../assets/icons/more.png'),
            // }] : []
          }
        }
      }
    })
  }

  gotoAddQuestion = () => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddQuestion',
        options: {
          modalPresentationStyle: OptionsModalPresentationStyle.fullScreen
        }
      }
    })
  }

  const QuestionCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      flexDirection: 'row'
    }}
      onPress={gotoQuestionDetail} >
      <View style={{
        height: 60,
        width: 60,
        marginLeft: 10,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: 30,
        // borderWidth: 2,
        // borderColor: COLORS.appDarkBlue,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <Image style={{
          height: 30,
          width: 30,
          resizeMode: 'contain',
          tintColor: 'white'
        }}
        source={require('../assets/icons/question-mark.png')}
        />
      </View>
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title + '\n'}<Text style = {{
        color: COLORS.appGray
      }}>{'27-04-2021'}</Text></Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-end',
          alignItems: 'flex-end'
        }}>
        <FlatList
          style={{
            width: '100%'
          }}
          contentContainerStyle={{
            paddingBottom: 85
          }}
          keyExtractor={(item, index) => index}
          data={questions}
          renderItem={QuestionCell} />

        <TouchableOpacity style={{
          height: 60,
          width: 60,
          borderRadius: 30,
          backgroundColor: COLORS.appDarkBlue,
          position: 'absolute',
          right: 20,
          bottom: 20,
          justifyContent: 'center',
          alignItems: 'center'
        }}
          onPress={gotoAddQuestion} >
          <Image style={{
            height: 20,
            width: 20,
            tintColor: 'white'
          }}
            source={require('../assets/icons/plus.png')} />
        </TouchableOpacity>
      </View>

    </SafeAreaView>
  );
};

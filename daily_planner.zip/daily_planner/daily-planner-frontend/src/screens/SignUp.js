/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
  Dimensions,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { AppButton } from '../components/AppButton';
import { AppTextInput } from '../components/AppTextInput';
import { COLORS } from '../config/colors';
import { UserType } from '../config/enums';

export const SignUp = (props) => {

  const [userType, setUserType] = useState(UserType.nonMuslim)

  const gotoLogin = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.SignIn',
        options: {
          topBar: {
            title: {
              text: 'Sign In',
              color: COLORS.appBlue
            },
            backButton: {
              color: COLORS.appBlue
            }
          }
        }
      }
    })
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          backgroundColor: COLORS.appWhite
        }}>
        <KeyboardAvoidingView style={{
          flex: 1
        }}
          behavior={'padding'}
          enabled={Platform.OS = 'ios'} >
          <ScrollView style={{
            flex: 1
          }}
            bounces={false} >
            <View style={{
              // height: Dimensions.get('screen').height / 1.2,
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {/* <View style={{
              height: Dimensions.get('screen').height / 2,
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              backgroundColor: COLORS.appDarkBlue
            }} /> */}
              <Image style={{
                height: 150,
                width: 150,
                marginTop: 30
                // tintColor: 'white'
              }}
                source={require('../assets/icons/logo.png')} />

              <View style={{
                width: '90%',
                alignItems: 'center',
                justifyContent: 'center',
                marginVertical: 30,
                backgroundColor: 'white',
                borderRadius: 20,
                shadowRadius: 5,
                shadowOffset: {
                  width: 2,
                  height: 3,
                },
                shadowColor: 'black',
                elevation: 5,
                shadowOpacity: 0.3
              }}>

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 30
                  }}
                  icon={require('../assets/icons/user.png')}
                  label='USERNAME'
                  placeholder='USERNAME' />

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 15
                  }}
                  icon={require('../assets/icons/at.png')}
                  label='EMAIL'
                  placeholder='EMAIL' />

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 15
                  }}
                  icon={require('../assets/icons/padlock.png')}
                  label='PASSWORD'
                  placeholder='PASSWORD' />

                <AppTextInput
                  style={{
                    width: '90%',
                    marginTop: 15
                  }}
                  icon={require('../assets/icons/padlock.png')}
                  label='CONFIRM PASSWORD'
                  placeholder='CONFIRM PASSWORD' />

                <View
                  style={{
                    height: 50,
                    width: "80%",
                    flexDirection: 'row',
                    marginTop: 20
                  }}
                >
                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      setUserType(UserType.muslim)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                      borderRadius: 20,
                      tintColor: COLORS.appGray
                    }}
                      source={userType == UserType.muslim ? require('../assets/icons/radio-on.png') : require('../assets/icons/radio-off.png')} />
                    <Text style={{
                      fontSize: 16,
                      fontWeight: '600',
                      color: COLORS.appGray,
                      marginLeft: 15
                    }}>Muslim</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flex: 1,
                    alignItems: 'center',
                    flexDirection: 'row'
                  }}
                    onPress={() => {
                      setUserType(UserType.nonMuslim)
                    }} >
                    <Image style={{
                      height: 20,
                      width: 20,
                      borderRadius: 20,
                      tintColor: COLORS.appGray
                    }}
                      source={userType == UserType.nonMuslim ? require('../assets/icons/radio-on.png') : require('../assets/icons/radio-off.png')} />
                    <Text style={{
                      fontSize: 16,
                      fontWeight: '600',
                      color: COLORS.appGray,
                      marginLeft: 15
                    }}>Non-Muslim</Text>
                  </TouchableOpacity>
                </View>

                <AppButton
                  style={{
                    width: '90%',
                    marginTop: 20
                  }}
                  title='REGISTER' />

                <Text style={{
                  fontSize: 17,
                  fontWeight: '500',
                  marginTop: 10,
                  height: 50,
                  color: COLORS.appGray
                }}>Already have an account? <Text
                  style={{
                    color: COLORS.appBlue
                  }}
                  onPress={gotoLogin}>Sign In</Text></Text>

              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </SafeAreaView>
  );
};

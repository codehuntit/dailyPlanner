import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { AppButton } from "../components/AppButton";
import { AppTextInput } from "../components/AppTextInput";
import { COLORS } from "../config/colors";

export const editprofile = (props) => {

  const [username, setUsername] = useState('')

  const [usernameError, setUsernameError] = useState('')

  const clearAllMessages = () => {
    setUsernameError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (username == '') {
      setUsernameError('Please enter username.')
    }

    if (username != '') {

    }
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        // backgroundColor: COLORS.appGray,
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}>
        <ScrollView
          style={{
            flex: 1
          }}
        >
          <View
            style={{
              alignItems: "center",
            }}
          >
            <TouchableOpacity style={{
              height: 100,
              width: 100,
              borderRadius: 50,
              backgroundColor: "#999",
              marginTop: 20,
            }} >
              <Image
                style={{
                  height: 100,
                  width: 100
                }}
                source={require('../assets/icons/avatar.png')} />
              <View style = {{
                height: 30,
                width: 30,
                borderRadius: 15,
                overflow: 'hidden',
                backgroundColor: 'white',
                position: 'absolute',
                bottom: 4,
                right: 4,
                justifyContent: 'center',
                alignItems: 'center',
                borderColor: COLORS.appDarkGray,
                borderWidth: 2
              }}>
                <Image style = {{
                  height: 18,
                  width: 18,
                  tintColor: COLORS.appDarkGray
                }}
                source = {require('../assets/icons/pen.png')} />
              </View>
            </TouchableOpacity>
            <AppTextInput style={{
              marginTop: 30,
              width: '90%',
            }}
              icon={require('../assets/icons/user.png')}
              errorMessage={usernameError}
              onChangeText={setUsername}
              value={username}
              placeholder='Username' />
            {/* <AppTextInput style={{
              marginTop: 20,
              width: '90%',
            }}
              placeholder='Email'
              keyboardType='email-address' /> */}

            <AppButton style={{
              marginTop: 30,
              width: '90%'
            }}
              title='Save'
              onPress={validateData}
            />

          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

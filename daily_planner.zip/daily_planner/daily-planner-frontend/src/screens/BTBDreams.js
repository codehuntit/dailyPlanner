/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Navigation, OptionsModalPresentationStyle } from 'react-native-navigation';
import { COLORS } from '../config/colors';

export const BTBDreams = (props) => {

  const [isSelected, setSelected] = useState(false)
  const [dreams, setDreams] = useState([{
    id: '1',
    title: 'Dummy 1',
    icon: require('../assets/icons/menu/edit.png'),
    date: '21/03/2021 11:30 AM',
    isSelected: false
  }, {
    id: '2',
    title: 'Dummy 2',
    icon: require('../assets/icons/question-mark.png'),
    date: '21/03/2021 11:30 AM',
    isSelected: false
  }, {
    id: '3',
    title: 'Dummy 3',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM',
    isSelected: false
  }, {
    id: '4',
    title: 'Dummy 4',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM',
    isSelected: false
  }, {
    id: '5',
    title: 'Dummy 5',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM',
    isSelected: false
  }, {
    id: '6',
    title: 'Dummy 6',
    icon: require('../assets/icons/light.png'),
    date: '21/03/2021 11:30 AM',
    isSelected: false
  }])

  useEffect(() => {
    const event = Navigation.events().registerNavigationButtonPressedListener(({ buttonId }) => {
      if (buttonId == 'selectitem') {
        Navigation.mergeOptions(props.componentId, {
          topBar: {
            rightButtons: [
              {
                id: 'selectitem',
                color: COLORS.appDarkBlue,
                text: !isSelected ? 'Merge' : 'Select'
              },
            ],
            leftButtons: !isSelected ? [{
              id: 'selectdone',
              color: COLORS.appDarkBlue,
              text: 'Done'
            }] : []
          }
        })
        setSelected(!isSelected)
      }
      else if (buttonId == 'selectdone') {
        setSelected(false)
        Navigation.mergeOptions(props.componentId, {
          topBar: {
            rightButtons: [
              {
                id: 'selectitem',
                color: COLORS.appDarkBlue,
                text: 'Select'
              },
            ],
            leftButtons: []
          }
        })
      }
    })

    return () => {
      event.remove()
    }
  })

  const cellPress = (item, index) => {
    if (isSelected) {
      var _dreams = [...dreams]
      _dreams[index].isSelected = !item.isSelected
      setDreams(_dreams)
    }
    else {
      gotoThisMorningDetail(item.title)
    }
  }

  const gotoThisMorningDetail = (title) => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.ThisMorningDetail',
        options: {
          topBar: {
            title: {
              text: title,
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            // rightButtons: item.id == '1' ? [{
            //   id: 'addevent',
            //   color: COLORS.appDarkBlue,
            //   icon: Platform.OS == 'ios' ? {
            //     uri: 'more',
            //     scale: 5
            //   } : require('../assets/icons/more.png'),
            // }] : []
          }
        }
      }
    })
  }

  const DreamCell = ({ item, index }) => {
    return <TouchableOpacity style={{
      height: 80,
      alignItems: 'center',
      flexDirection: 'row'
    }}
      onPress={() => cellPress(item, index)} >
      {isSelected && <View style={{
        height: 30,
        width: 30,
        marginLeft: 10
      }}>
        <Image style={{
          height: 30,
          width: 30,
          tintColor: COLORS.appGray
        }}
          source={item.isSelected ? require('../assets/icons/checked.png') : require('../assets/icons/uncheck.png')} />
      </View>}
      <View style={{
        height: 60,
        width: 60,
        marginLeft: 10,
        backgroundColor: COLORS.appDarkBlue,
        borderRadius: 30,
        // borderWidth: 2,
        // borderColor: COLORS.appDarkBlue,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <Image style={{
          height: 30,
          width: 30,
          resizeMode: 'contain',
          tintColor: 'white'
        }}
          source={require('../assets/icons/dreaming.png')}
        />
      </View>
      <Text style={{
        fontSize: 17,
        fontWeight: '500',
        marginHorizontal: 10
      }}>{item.title + '\n'}<Text style={{
        color: COLORS.appGray
      }}>{item.date}</Text></Text>
      <View style={{
        height: 1,
        backgroundColor: '#bbb',
        position: 'absolute',
        width: '100%',
        bottom: 0
      }} />
    </TouchableOpacity>
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-end',
          alignItems: 'flex-end'
        }}>
        <FlatList
          style={{
            width: '100%'
          }}
          contentContainerStyle={{
            // paddingBottom: 85
          }}
          keyExtractor={(item, index) => index}
          data={dreams}
          renderItem={DreamCell} />
      </View>
    </SafeAreaView>
  );
};

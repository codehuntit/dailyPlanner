/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Agenda, Calendar } from 'react-native-calendars';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';

export const AllTime = (props) => {
  useEffect(() => {
    const event = Navigation.events().registerNavigationButtonPressedListener(({ buttonId }) => {
      if (buttonId == 'addevent') {
        gotoAddEvent()
      }
    })

    return () => {
      event.remove()
    }
  }, [])

  const gotoThisMorningDetail = (title) => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.ThisMorningDetail',
        options: {
          topBar: {
            title: {
              text: title,
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
            // rightButtons: item.id == '1' ? [{
            //   id: 'addevent',
            //   color: COLORS.appDarkBlue,
            //   icon: Platform.OS == 'ios' ? {
            //     uri: 'more',
            //     scale: 5
            //   } : require('../assets/icons/more.png'),
            // }] : []
          }
        }
      }
    })
  }

  gotoAddEvent = () => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddEvent',
        options: {
          topBar: {
            title: {
              text: 'Add Event',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
          }
        }
      }
    })
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1
        }}>
        <Calendar
          enableSwipeMonths={true}
          // markedDates={{
          //   '2021-04-16': { selected: true, marked: true, selectedColor: COLORS.appDarkBlue },
          //   '2021-04-17': { marked: true },
          //   '2021-04-19': { disabled: true, disableTouchEvent: true },
          //   '2021-04-25': { marked: true, dotColor: 'red', activeOpacity: 0 },
          // }}
          onDayPress = {(date) => gotoThisMorningDetail(date.dateString)}
        // markingType={'multi-dot'}
        />

      </View>
    </SafeAreaView>
  );
};

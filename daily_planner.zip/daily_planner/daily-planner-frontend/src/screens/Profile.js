/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useCallback, useEffect, useState } from 'react';
import {
  SafeAreaView,
  View,
  ScrollView,
  Image,
  Text,
  TouchableOpacity,
  RefreshControl
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';

export const Profile = (props) => {

  const gotoChangePassword = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.ChangePassword',
        options: {
          topBar: {
            title: {
              text: 'Change Password',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            }
          }
        }
      }
    })
  }

  const gotoEditProfile = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'com.planner.editprofile',
        options: {
          topBar: {
            title: {
              text: 'Edit Profile',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            }
          }
        }
      }
    })
  }

  return (
    <SafeAreaView style={{
      flex: 1
    }}>
      <ScrollView style={{
        flex: 1,
      }}
        // refreshControl={
        //   <RefreshControl
        //     refreshing={refreshing}
        //     onRefresh={onRefresh}
        //   />
        // }
         >
        <View style={{
          width: '100%',
          alignItems: 'center',
          paddingBottom: 50
        }}>
          <Image style={{
            height: 150,
            width: '100%',
            backgroundColor: COLORS.appBlue
          }}
            blurRadius={20}
            source={require('../assets/icons/cover.png')}
             />
          <Image style={{
            height: 120,
            width: 120,
            marginTop: -60,
            borderRadius: 60,
            backgroundColor: COLORS.appWhite,
            resizeMode: 'cover',
          }}
            source={require('../assets/icons/avatar-profile.png')}
             />
          <Text style={{
            fontSize: 18,
            fontWeight: '600',
            marginTop: 10
          }}>Dummy name</Text>
          <Text style={{
            fontSize: 17,
            marginTop: 5
          }}>test@email.com</Text>
          <Text style={{
            fontSize: 17,
            marginTop: 5
          }}></Text>

          <View style={{
            marginTop: 40,
            // height: 200,
            width: '80%',
            backgroundColor: 'white',
            shadowColor: '#000000',
            shadowOffset: {
              width: 2,
              height: 2
            },
            shadowRadius: 3,
            shadowOpacity: 0.4,
            borderRadius: 15,
            elevation: 5,
          }}>
            <TouchableOpacity style={{
              justifyContent: 'center'
            }}
              onPress={gotoChangePassword}
               >
              <View style={{
                height: 50,
                justifyContent: 'center',
                alignItems: 'center'
              }}>
                <Text style={{
                  textAlign: 'center',
                }}>Change password</Text>
                <View style={{
                  height: 1,
                  width: '100%',
                  bottom: 0,
                  backgroundColor: '#ccc',
                  position: 'absolute'
                }} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={{
              justifyContent: 'center'
            }}
              onPress={gotoEditProfile}
               >
              <View style={{
                height: 50,
                justifyContent: 'center',
                alignItems: 'center'
              }}>
                <Text style={{
                  textAlign: 'center',
                }}>Edit Profile</Text>
                {/* <View style={{
                  height: 1,
                  width: '100%',
                  bottom: 0,
                  backgroundColor: '#ccc',
                  position: 'absolute'
                }} /> */}
              </View>
            </TouchableOpacity>

            {/* <TouchableOpacity style={{
              justifyContent: 'center'
            }}
              // onPress={logOutPressed}
               >
              <View style={{
                height: 50,
                justifyContent: 'center',
                alignItems: 'center'
              }}>
                <Text style={{
                  textAlign: 'center',
                }}>Logout</Text>
              </View>
            </TouchableOpacity> */}
          </View>

        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
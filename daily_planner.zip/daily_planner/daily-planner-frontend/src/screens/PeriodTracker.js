/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
} from 'react-native';
import { Agenda, Calendar } from 'react-native-calendars';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../config/colors';
import moment from 'moment';

const vacation = { key: 'vacation', color: 'red', selectedDotColor: 'blue' };
const massage = { key: 'massage', color: 'blue', selectedDotColor: 'blue' };
const workout = { key: 'workout', color: 'green' };

const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const prevDates = [{
  title: '14',
  isP: false
}, {
  title: '15',
  isP: false
}, {
  title: '16',
  isP: false
}, {
  title: '17',
  isP: false
}, {
  title: '18',
  isP: true,
  isStart: true
}, {
  title: '19',
  isP: true
}, {
  title: '20',
  isP: true
}, {
  title: '21',
  isP: true
}, {
  title: '22',
  isP: true
}, {
  title: '23',
  isP: true,
  isEnd: true
}, {
  title: '24',
  isP: false
}, {
  title: '25',
  isP: false
}, {
  title: '26',
  isP: false
}, {
  title: '27',
  isP: false
}];

export const PeriodTracker = (props) => {

  const [selectedIndex, setIndex] = useState(0)

  useEffect(() => {
    const event = Navigation.events().registerNavigationButtonPressedListener(({ buttonId }) => {
      if (buttonId == 'addevent') {
        gotoAddEvent()
      }
    })

    return () => {
      event.remove()
    }
  }, [])

  gotoAddEvent = () => {
    Navigation.showModal({
      component: {
        name: 'com.planner.AddEvent',
        options: {
          topBar: {
            title: {
              text: 'Add Event',
              color: COLORS.appDarkBlue
            },
            backButton: {
              color: COLORS.appDarkBlue
            },
          }
        }
      }
    })
  }

  return (

    <SafeAreaView style={{
      flex: 1,
      backgroundColor: COLORS.appWhite
    }}>
      <StatusBar barStyle={'dark-content'} />
      <View
        style={{
          flex: 1
        }}>

        <View style={{
          height: 70,
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <View style={{
            height: 40,
            width: '70%',
            overflow: 'visible',
            flexDirection: 'row',
            backgroundColor: COLORS.appDarkBlue,
            borderRadius: 20
          }}>
            <TouchableOpacity style={{
              height: 40,
              flex: 1,
              borderColor: COLORS.appDarkBlue,
              borderWidth: 2,
              borderTopLeftRadius: 20,
              borderBottomLeftRadius: 20,
              backgroundColor: selectedIndex == 0 ? COLORS.appDarkBlue : COLORS.appWhite,
              justifyContent: 'center',
              alignItems: 'center'
            }}
              onPress={() => {
                setIndex(0)
              }}>
              <Text style={{
                color: selectedIndex == 0 ? COLORS.appWhite : COLORS.appDarkBlue,
                fontWeight: '500',
                fontSize: 16
              }}>Calendar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={{
              height: 40,
              flex: 1,
              borderColor: COLORS.appDarkBlue,
              borderWidth: 2,
              borderTopRightRadius: 20,
              borderBottomRightRadius: 20,
              backgroundColor: selectedIndex == 1 ? COLORS.appDarkBlue : COLORS.appWhite,
              alignItems: 'center',
              justifyContent: 'center'
            }}
              onPress={() => {
                setIndex(1)
              }}>
              <Text style={{
                color: selectedIndex == 1 ? COLORS.appWhite : COLORS.appDarkBlue,
                fontWeight: '500',
                fontSize: 16
              }}>Analysis</Text>
            </TouchableOpacity>
          </View>
        </View>

        {selectedIndex == 0 ?
          <ScrollView contentContainerStyle={{
            paddingBottom: 80
          }}>
            <Text style={{
              width: '100%',
              height: 40,
              textAlign: 'center',
              marginTop: 20,
              fontSize: 17,
              fontWeight: '600',
              color: COLORS.appDarkGray
            }}>Previous Month</Text>

            {/* <View style={{
            // height: 100,
            // alignItems: 'center'
          }}>
            <View style={{
              height: 40,
              flexDirection: 'row',
              justifyContent: 'space-between'
            }}>
              {weekDays.map((item, index) => {
                return <Text style={{
                  flex: 1,
                  color: '#aaaaaa',
                  textAlign: 'center',
                  fontSize: 13
                }}>{item}</Text>
              })}
            </View>
            <View style={{
              // height: 30,
              // justifyContent: 'space-between',
            }}>
              <View style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 0
              }}>
                {prevDates.map((item, index) => {
                  return index < 7 &&
                    <View style={{
                      flex: 1,
                      height: 36,
                      // width: 20,
                      // borderRadius: 18,
                      borderTopLeftRadius: item.isStart ? 18 : 0,
                      borderBottomLeftRadius: item.isStart ? 18 : 0,
                      borderTopEndRadius: item.isEnd ? 18 : 0,
                      borderBottomEndRadius: item.isEnd ? 18 : 0,
                      backgroundColor: item.isP ? COLORS.appBlue : 'white',
                      justifyContent: 'center',
                      alignItems: 'center'
                    }}>
                      <Text style={{
                        color: item.isP ? 'white' : '#777777',
                        textAlign: 'center',
                        fontSize: 15,
                      }}>{item.title}</Text>
                    </View>
                })}
              </View>
              <View style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 0
              }}>
                {prevDates.map((item, index) => {
                  return index >= 7 && <View style={{
                    flex: 1,
                    height: 36,
                    // width: 20,
                    // borderRadius: 18,
                    borderTopLeftRadius: item.isStart ? 18 : 0,
                    borderBottomLeftRadius: item.isStart ? 18 : 0,
                    borderTopEndRadius: item.isEnd ? 18 : 0,
                    borderBottomEndRadius: item.isEnd ? 18 : 0,
                    backgroundColor: item.isP ? COLORS.appBlue : 'white',
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}>
                    <Text style={{
                      color: item.isP ? 'white' : '#777777',
                      textAlign: 'center',
                      fontSize: 15,
                    }}>{item.title}</Text>
                  </View>
                })}
              </View>
            </View>
          </View> */}

            <Calendar
              // Collection of dates that have to be colored in a special way. Default = {}
              hideArrows={true}
              current = {'2021-03-14'}
              markedDates={{
                // '2021-04-20': { textColor: 'green' },
                '2021-03-14': { startingDay: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-15': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-16': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-17': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-18': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-19': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-20': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-03-21': { endingDay: true, color: COLORS.appBlue, textColor: 'white' },
                // '2021-04-04': { disabled: true, startingDay: true, color: 'green', endingDay: true }
              }}
              // Date marking style [simple/period/multi-dot/custom]. Default = 'simple'
              markingType={'period'}
            />
            <View style={{
              height: 1,
              backgroundColor: COLORS.appGray
            }} />
            <Text style={{
              width: '100%',
              height: 40,
              textAlign: 'center',
              marginTop: 20,
              fontSize: 17,
              fontWeight: '600',
              color: COLORS.appDarkGray
            }}>This Month</Text>

            <Calendar
              enableSwipeMonths={true}
              current = {'2021-04-13'}
              markedDates={{
                '2021-04-13': { startingDay: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-14': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-15': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-16': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-17': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-18': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-19': { selected: true, color: COLORS.appBlue, textColor: 'white' },
                '2021-04-20': { endingDay: true, color: COLORS.appBlue, textColor: 'white' },
              }}
              // dayComponent={({ date, state, marking }) => {
              //   return (
              //     <View style = {marking}>
              //       <Text style={{
              //         textAlign: 'center', 
              //         color: '#777777',
              //         fontSize: 15,
              //       }}>
              //         {date.day}
              //       </Text>
              //     </View>
              //   )
              // }}
              markingType={'period'}
            // markingType={'multi-dot'}
            />

          </ScrollView> :
          <View style={{
            alignItems: 'center'
          }}>
            <Text style={{
              width: '100%',
              height: 40,
              textAlign: 'center',
              marginTop: 0,
              fontSize: 17,
              fontWeight: '600',
              color: COLORS.appDarkGray
            }}>Cycle Analysis</Text>
            <View style={{
              height: 200,
              width: '80%',
              flexDirection: 'row'
            }}>
              <View style={{
                flex: 1,
                backgroundColor: COLORS.appDarkBlue,
                borderRadius: 20
              }}>
                <Text style={{
                  height: 40,
                  marginTop: 10,
                  textAlign: 'center',
                  fontSize: 17,
                  fontWeight: '600',
                  color: COLORS.appWhite
                }}>Cycle Length</Text>
                <View style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center'
                }}>
                  <Image
                    style={{
                      flex: 1,
                      height: '100%',
                      width: '100%',
                      resizeMode: 'contain',
                      tintColor: COLORS.appWhite
                    }}
                    source={require('../assets/icons/reload-icon.png')} />
                  <Text style={{
                    // height: 40,
                    // marginTop: 10,
                    textAlign: 'center',
                    fontSize: 20,
                    fontWeight: '600',
                    color: COLORS.appWhite,
                    position: 'absolute'
                  }}>{'28\nDays'}</Text>
                </View>
              </View>

              <View style={{
                flex: 1,
                backgroundColor: COLORS.appDarkBlue,
                borderRadius: 20,
                marginLeft: 20
              }}>
                <Text style={{
                  height: 40,
                  marginTop: 10,
                  textAlign: 'center',
                  fontSize: 17,
                  fontWeight: '600',
                  color: COLORS.appWhite
                }}>Period Length</Text>
                <View style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center'
                }}>
                  <Image
                    style={{
                      flex: 1,
                      height: '100%',
                      width: '100%',
                      resizeMode: 'contain',
                      tintColor: COLORS.appWhite
                    }}
                    source={require('../assets/icons/reload-icon.png')} />
                  <Text style={{
                    // height: 40,
                    // marginTop: 10,
                    textAlign: 'center',
                    fontSize: 20,
                    fontWeight: '600',
                    color: COLORS.appWhite,
                    position: 'absolute'
                  }}>{'4\nDays'}</Text>
                </View>
              </View>

            </View>
          </View>
        }
      </View>

      <TouchableOpacity style={{
        height: 60,
        width: 60,
        borderRadius: 30,
        backgroundColor: COLORS.appDarkBlue,
        position: 'absolute',
        right: 20,
        bottom: 20,
        justifyContent: 'center',
        alignItems: 'center'
      }}
        onPress={() => {
          Navigation.showModal({
            component: {
              name: 'com.planner.TrackPeriod'
            }
          })
        }} >
        <Image style={{
          height: 20,
          width: 20,
          tintColor: 'white'
        }}
          source={require('../assets/icons/plus.png')} />
      </TouchableOpacity>

    </SafeAreaView>
  );
};

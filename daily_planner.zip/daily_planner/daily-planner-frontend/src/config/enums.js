export const UserType = {
    muslim: 'muslim',
    nonMuslim: 'nonMuslim'
}

export const WeatherType = {
    sunny: 'sunny',
    cloudy: 'cloudy',
    rainy: 'rainy'
}

export const MoodType = {
    fullHappy: 'fullHappy',
    happy: 'happy',
    normal: 'normal',
    sad: 'sad',
    upset: 'upset',
    none: 'none'
}

export const ActivityRepeatMode = {
    selectedDate: 'selectedDate',
    calendar: 'calendar',
    weekends: 'weekends',
    allDays: 'allDays',
    none: 'none'
}

export const ViewType = {
    calendar: 'Calendar',
    fullWeek: 'Full Week',
    today: 'Today'
}
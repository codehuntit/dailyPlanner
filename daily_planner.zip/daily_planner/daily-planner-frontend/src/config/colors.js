export const COLORS = {
    appBlue: '#7EB6FF',
    appDarkBlue: '#1B3F8B',
    appWhite: '#ffffff',
    appGray: '#999999',
    appDarkGray: '#444444',
    appBlack: '#000000'
}
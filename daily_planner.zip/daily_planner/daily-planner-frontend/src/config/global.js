export const global = {
    splitor: '{/,/}'
}
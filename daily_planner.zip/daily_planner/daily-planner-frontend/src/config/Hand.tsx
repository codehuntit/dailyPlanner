import React from 'react';
import { G, Line, Circle } from 'react-native-svg';
import { polarToCartesian } from './Helpers/Geometry';

interface Props {
  center: number;
  radius: number;
  angle: number;
  strokeWidth: string;
  stroke: string;
}

const Hand = (props) => {
  const { x, y } = polarToCartesian(
    props.center,
    props.center,
    props.radius,
    props.angle,
  );

  return (
    <G onPress = {props.onPress}>
      <Line
        x1={props.center}
        y1={props.center}
        x2={x}
        y2={y}
        strokeWidth={props.strokeWidth}
        strokeLinecap="round"
        stroke={props.stroke}
      />
      <Circle
        cx={x + ''}
        cy={y + ''}
        r="8"
        stroke="white"
        strokeWidth="4"
        fill="white"
      />
    </G>
  );
};

export default Hand;

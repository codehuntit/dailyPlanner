/**
 * @format
 */

import { Navigation } from "react-native-navigation";
import { AddActivity } from "./src/screens/AddActivity";
import { AddDailyJournal } from "./src/screens/AddDailyJournal";
import { AddEvent } from "./src/screens/AddEvent";
import { AddGoal } from "./src/screens/AddGoal";
import { AddInspiration } from "./src/screens/AddInspiration";
import { AddQuestion } from "./src/screens/AddQuestion";
import { AddThisMorning } from "./src/screens/AddThisMorning";
import { AllTime } from "./src/screens/AllTime";
import { BTBDreams } from "./src/screens/BTBDreams";
import { Categories } from "./src/screens/Categories";
import { ChangePassword } from "./src/screens/ChangePassword";
import { Daily } from "./src/screens/Daily";
import { DailyJournal } from "./src/screens/DailyJournal";
import { DailyJournalDetail } from "./src/screens/DailyJournalDetail";
import { EditActivity } from "./src/screens/EditActivity";
import { editprofile } from "./src/screens/editprofile";
import { EventAlerts } from "./src/screens/EventAlerts";
import { EventGraph } from "./src/screens/EventGraph";
import { Events } from "./src/screens/Events";
import { ForgotPassword } from "./src/screens/ForgotPassword";
import { Goals } from "./src/screens/Goals";
import { GoalsList } from "./src/screens/GoalsList";
import { Home } from "./src/screens/Home";
import { InspirationDetail } from "./src/screens/InspirationDetail";
import { Inspirations } from "./src/screens/Inspirations";
import { Journal } from "./src/screens/Journal";
import { PeriodTracker } from "./src/screens/PeriodTracker";
import { Profile } from "./src/screens/Profile";
import { QuestionDetail } from "./src/screens/QuestionDetail";
import { Questions } from "./src/screens/Questions";
import { Reminder } from "./src/screens/Reminder";
import { Settings } from "./src/screens/Settings";
import { SignIn } from "./src/screens/SignIn";
import { SignUp } from "./src/screens/SignUp";
import { SleepDiary } from "./src/screens/SleepDiary";
import { ThisMorning } from "./src/screens/ThisMorning";
import { ThisMorningDetail } from "./src/screens/ThisMorningDetail";
import { TimeController } from "./src/screens/TimeController";
import { TipDetail } from "./src/screens/TipDetail";
import { Tips } from "./src/screens/Tips";
import { TrackPeriod } from "./src/screens/TrackPeriod";

Navigation.registerComponent('com.planner.SignUp', () => SignUp);
Navigation.registerComponent('com.planner.SignIn', () => SignIn);
Navigation.registerComponent('com.planner.ForgotPassword', () => ForgotPassword);
Navigation.registerComponent('com.planner.Home', () => Home);
Navigation.registerComponent('com.planner.Categories', () => Categories);
Navigation.registerComponent('com.planner.Daily', () => Daily);
Navigation.registerComponent('com.planner.Settings', () => Settings);
Navigation.registerComponent('com.planner.Events', () => Events);
Navigation.registerComponent('com.planner.AddEvent', () => AddEvent);
Navigation.registerComponent('com.planner.Tips', () => Tips);
Navigation.registerComponent('com.planner.Profile', () => Profile);
Navigation.registerComponent('com.planner.Journal', () => Journal);
Navigation.registerComponent('com.planner.DailyJournal', () => DailyJournal);
Navigation.registerComponent('com.planner.AddDailyJournal', () => AddDailyJournal);
Navigation.registerComponent('com.planner.DailyJournalDetail', () => DailyJournalDetail);
Navigation.registerComponent('com.planner.Questions', () => Questions);
Navigation.registerComponent('com.planner.AddQuestion', () => AddQuestion);
Navigation.registerComponent('com.planner.QuestionDetail', () => QuestionDetail);
Navigation.registerComponent('com.planner.Inspirations', () => Inspirations);
Navigation.registerComponent('com.planner.InspirationDetail', () => InspirationDetail);
Navigation.registerComponent('com.planner.AddInspiration', () => AddInspiration);
Navigation.registerComponent('com.planner.SleepDiary', () => SleepDiary);
Navigation.registerComponent('com.planner.AddThisMorning', () => AddThisMorning);
Navigation.registerComponent('com.planner.ThisMorning', () => ThisMorning);
Navigation.registerComponent('com.planner.ThisMorningDetail', () => ThisMorningDetail);
Navigation.registerComponent('com.planner.BTBDreams', () => BTBDreams);
Navigation.registerComponent('com.planner.AllTime', () => AllTime);
Navigation.registerComponent('com.planner.TimeController', () => TimeController);
Navigation.registerComponent('com.planner.AddActivity', () => AddActivity);
Navigation.registerComponent('com.planner.EditActivity', () => EditActivity);
Navigation.registerComponent('com.planner.Goals', () => Goals);
Navigation.registerComponent('com.planner.AddGoal', () => AddGoal);
Navigation.registerComponent('com.planner.GoalsList', () => GoalsList);
Navigation.registerComponent('com.planner.Reminder', () => Reminder);
Navigation.registerComponent('com.planner.PeriodTracker', () => PeriodTracker);
Navigation.registerComponent('com.planner.EventAlerts', () => EventAlerts);
Navigation.registerComponent('com.planner.TrackPeriod', () => TrackPeriod);
Navigation.registerComponent('com.planner.EventGraph', () => EventGraph);
Navigation.registerComponent('com.planner.ChangePassword', () => ChangePassword);
Navigation.registerComponent('com.planner.editprofile', () => editprofile);
Navigation.registerComponent('com.planner.TipDetail', () => TipDetail);

Navigation.events().registerAppLaunchedListener(() => {
   Navigation.setRoot({
     root: {
       stack: {
         children: [
           {
             component: {
               name: 'com.planner.SignUp',
               options: {
                 topBar: {
                   visible: false
                 }
               }
             },
           }
         ]
       }
     }
  });
});
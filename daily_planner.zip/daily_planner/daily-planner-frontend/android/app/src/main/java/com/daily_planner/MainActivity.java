package com.daily_planner;

import com.reactnativenavigation.NavigationActivity;

public class MainActivity extends NavigationActivity {

  
}

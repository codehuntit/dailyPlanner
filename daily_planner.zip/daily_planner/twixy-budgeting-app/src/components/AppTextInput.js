/**
 * twixy-budgeting-app
 */

import React from 'react';
import {
    Text,
    TextInput,
    View,
} from 'react-native';
import { COLORS } from '../../config/colors';


export const AppTextInput = (props) => {
    return (
        <View style={[{
            
        }, props.style]}>
            <TextInput style={[props.inputStyle, {
                // flex: 1,
                padding: 0,
                color: 'white',
                fontSize: 17,
                padding: 0,
                height: 50,
                borderRadius: 10,
                borderColor: COLORS.appTheme,
                borderWidth: 3,
                paddingHorizontal: 15
            }]}
                placeholder={props.placeholder}
                placeholderTextColor='#999'
                secureTextEntry={props.secureTextEntry}
                selectionColor={'white'}
                keyboardType={props.keyboardType}
                value = {props.value}
                onChangeText = {props.onChangeText} />
            {props.errorMessage != null && props.errorMessage != '' &&
                <Text style={{
                    color: 'white',
                    marginTop: 5
                }}>* {props.errorMessage}</Text>}
        </View>
    );
};
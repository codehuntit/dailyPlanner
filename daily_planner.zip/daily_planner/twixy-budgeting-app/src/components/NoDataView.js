import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { COLORS } from '../../config/colors';


export const NoDataView = (props) => {
    return (
        <View style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center'
        }}>
            <View style = {{
                width: props.width == null ? 250 : props.width,
                height: props.height == null ? 250 : props.height,
                // tintColor: 'white',
                borderRadius: 125,
                borderColor: '#666',
                borderWidth: 1,
                overflow: 'hidden',
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                <Image style={{
                    flex: 1,
                    tintColor: 'white'
                }}
                    resizeMode='contain'
                    source={require('../../assets/icons/nodata-icon.png')} />
            </View>
            <Text style={{
                fontSize: 20,
                color: '#999',
                marginTop: 15
            }}>{(props.text != null && props.text != '') ? props.text : 'No data found'}</Text>
            {props.isRetry && <TouchableOpacity onPress={props.onRetry}>
                <Text style={{
                    fontSize: 20,
                    marginTop: 20,
                    color: 'white'
                }}>Retry</Text>
            </TouchableOpacity>}
        </View>
    );
}
/**
 * twixy-budgeting-app
 */

import React from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { COLORS } from '../../config/colors';


export const AppButton = (props) => {
    return (
        <TouchableOpacity style = {[{
            backgroundColor: COLORS.appTheme,
            height: 50,
            borderRadius: 10,
            justifyContent: 'center',
            alignItems: 'center'
        }, props.style]}
        onPress = {props.onPress} >
            <Text style = {{
                color: 'white',
                fontSize: 17,
                fontWeight: '500'
            }}>{props.title}</Text>
        </TouchableOpacity>
    );
};
import React, { useState, useEffect } from "react";
import {
    Text,
    View,
    SafeAreaView,
    StatusBar,
    Dimensions,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Image,
    ScrollView,
    KeyboardAvoidingView,
    FlatList,
    SectionList,
    Alert,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { COLORS } from "../../config/colors";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";
import ActionSheet from 'react-native-actionsheet'
import { FloatingAction } from "react-native-floating-action";
import { ApiClient } from "../../config/ApiClient";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";
import { NoDataView } from "../components/NoDataView";

const actions = [
    {
        text: "Add Transaction",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/coin.png"),
        name: "bt_addtransaction",
        position: 1
    }
];

var currentPage = 0

export const transactions = (props) => {
    // const [isPopupMenu, setPopupMenu] = useState(false)

    const [isLoader, setLoader] = useState(false)
    // const [currentPage, setCurrentPage] = useState(0)
    const [selectedSection, setSection] = useState('')

    const [categories, setCategories] = useState([
        { id: 1, isSelected: false, title: 'Books', icon: require('../../assets/icons/category_icons/Books.png') },
        { id: 2, title: 'Drinks', icon: require('../../assets/icons/category_icons/Drinks.png') },
        { id: 3, isSelected: false, title: 'Entertain', icon: require('../../assets/icons/category_icons/Entertain.png') },
        { id: 4, isSelected: false, title: 'Food', icon: require('../../assets/icons/category_icons/Food.png') },
        { id: 5, isSelected: false, title: 'General', icon: require('../../assets/icons/category_icons/General.png') },
        { id: 6, isSelected: false, title: 'Groceries', icon: require('../../assets/icons/category_icons/Groceries.png') },
        { id: 7, isSelected: false, title: 'Personal', icon: require('../../assets/icons/category_icons/Personal.png') },
        { id: 8, isSelected: false, title: 'Shopping', icon: require('../../assets/icons/category_icons/Shopping.png') },
        { id: 9, isSelected: false, title: 'Transfer', icon: require('../../assets/icons/category_icons/Transfer.png') },
        { id: 10, isSelected: false, title: 'Transport', icon: require('../../assets/icons/category_icons/Transport.png') },
        { id: 11, isSelected: false, title: 'Travel', icon: require('../../assets/icons/category_icons/Travel.png') }]);

    const [accounts, setAccounts] = useState([]);
    const [transactions, setTransactions] = useState([
        //     { title: '31/03/2021',
        //     data: [{
        //         id: 1,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'debit',
        //         amount: 100,
        //         currency: 'USD',
        //         symbol: '$'
        //     }, {
        //         id: 2,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'credit',
        //         amount: 123,
        //         currency: 'USD',
        //         symbol: '$'
        //     }, {
        //         id: 3,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'credit',
        //         amount: 122,
        //         currency: 'USD',
        //         symbol: '$'
        //     }]
        // }, {
        //     title: '28/03/2021',
        //     data: [{
        //         id: 4,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'debit',
        //         amount: 45,
        //         currency: 'USD',
        //         symbol: '$'
        //     }, {
        //         id: 5,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'debit',
        //         amount: 27,
        //         currency: 'USD',
        //         symbol: '$'
        //     }]
        // }, {
        //     title: '10/03/2021',
        //     data: [{
        //         id: 6,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'debit',
        //         amount: 231,
        //         currency: 'USD',
        //         symbol: '$'
        //     }, {
        //         id: 7,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'credit',
        //         amount: 258,
        //         currency: 'USD',
        //         symbol: '$'
        //     }, {
        //         id: 8,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'debit',
        //         amount: 100,
        //         currency: 'USD',
        //         symbol: '$'
        //     }, {
        //         id: 9,
        //         title: 'Transffered to XYZ account',
        //         toAccount: 'xxxx xxxx xx12 3321',
        //         transId: 'ABCD1234',
        //         type: 'credit',
        //         amount: 133,
        //         currency: 'USD',
        //         symbol: '$'
        //     }]
        // }
    ]);

    useEffect(() => {
        Navigation.events().registerNavigationButtonPressedListener(navigationButtonPressed)
        getAccountsRequest()
    }, [])

    const navigationButtonPressed = ({ buttonId }) => {
        if (buttonId == 'sideMenu') {
            Navigation.mergeOptions(props.componentId, {
                sideMenu: {
                    left: {
                        visible: true
                    }
                }
            });
        }
        else if (buttonId == 'moreMenu') {
            // setPopupMenu(true)
        }
    }

    const getAccountsRequest = () => {
        ApiClient.fetchPostWithFormData('fetch_account_by_user_id', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true' && data.details != null) {
                setAccounts(data.details)
                // if (data.details.length > currentPage) {
                getTransactionsRequest(data.details[currentPage].id, categories)
                // }
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const getTransactionsRequest = (accId, selCategories) => {
        var selectedCats = []
        selCategories.map((item, index) => {
            if (item.isSelected) {
                selectedCats.push(item.id)
            }
        })
        // console.log({ user_id: GlobalData.UserId, account_id: accounts[currentPage].id, category_ids: selectedCats.join(',') })
        console.log({ user_id: GlobalData.UserId, account_id: accId, category_ids: selectedCats.join(',') })
        ApiClient.fetchPostWithFormData('fetch_transaction', { user_id: GlobalData.UserId, account_id: accId, category_ids: selectedCats.join(',') }, transactions.length == 0, setLoader, (data) => {
            // alert(JSON.stringify(data.details))
            // if (data.status + '' == 'true' && data.details != null) {

            var _transactions = []
            if (data.details != null && data.details.length > 0) {
                var _dates = []
                data.details.map((item, index) => {
                    if (!_dates.includes(item.transaction_date)) {
                        _dates.push(item.transaction_date)
                        _transactions.push({
                            title: item.transaction_date,
                            data: [item]
                        })
                    }
                    else {
                        var _index = 0
                        _transactions.map((_item, index) => {
                            if (_item.title == item.transaction_date) {
                                _index = index
                            }
                        })
                        var _data = { ..._transactions[_index] }
                        var __data = [..._data.data]
                        __data.push(item)
                        _data.data = __data
                        _transactions[_index] = _data
                    }
                })
            }
            setTransactions(_transactions)

            // setTransactions(data.details)
            // }
            // else {
            //     // alert(data.message)
            // }
        }, (error) => {
            alert(error)
        })
    }

    const removeTransactionRequest = () => {
        ApiClient.fetchPostWithFormData('remove_transaction', { transaction_id: selectedSection.id }, true, setLoader, (data) => {
            if (data.status + '' == 'true') {
                getTransactionsRequest(accounts[currentPage].id, categories)
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const accountCell = ({ item, index }) => {
        return (
            <TouchableOpacity
                style={{
                    justifyContent: "center",
                    alignItems: "center",
                    width: Dimensions.get('screen').width
                }}>
                <View style={{
                    height: 200,
                    width: '90%',
                    backgroundColor: 'white',
                    borderRadius: 20,
                    overflow: 'hidden'
                }}>
                    <Image style={{
                        position: 'absolute',
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        resizeMode: 'contain'
                    }}
                        source={require('../../assets/icons/wave-icon.png')} />
                    {/* <View
                        style={{
                            height: 1,
                            position: "absolute",
                            bottom: 0,
                            width: "100%",
                            backgroundColor: '#ccc',
                        }}
                    />
                    <Image
                        style={{
                            height: 30,
                            width: 30,
                            borderRadius: 15,
                            marginLeft: 15,
                            backgroundColor: "#999",
                        }}
                    /> */}
                    <View style={{
                        flex: 1,
                        justifyContent: 'flex-end'
                    }}>
                        <Text
                            style={{
                                color: "#111",
                                fontSize: 22,
                                fontWeight: "700",
                                marginLeft: 20
                            }}
                        >{item.title}</Text>
                        <Text
                            style={{
                                color: "#aaa",
                                fontSize: 20,
                                marginLeft: 20,
                                marginBottom: 20
                            }}
                        >{item.account_number}</Text>
                    </View>
                    {/* <Image
                        style={{
                            height: 20,
                            width: 20,
                            resizeMode: 'contain',
                            marginRight: 10,
                            tintColor: '#ccc'
                        }}
                        source={require('../../assets/icons/right-arrow-angle.png')} /> */}
                </View>
            </TouchableOpacity>
        );
    };

    const transationCell = ({ item, index }) => {
        return (
            <TouchableOpacity
                style={{
                    height: 80,
                    flexDirection: "row",
                    alignItems: "center",
                }} onLongPress={() => {
                    setSection(item)
                    this.ActionSheet.show()
                }}>
                <View
                    style={{
                        height: 1,
                        position: "absolute",
                        bottom: 0,
                        width: "100%",
                        backgroundColor: '#cccccc44',
                    }}
                />
                <View style={{
                    height: 50,
                    width: 50,
                    borderRadius: 25,
                    marginLeft: 10,
                    overflow: item.image_url != null ? 'hidden' : 'visible'
                    // backgroundColor: "#999",
                }}>
                    <Image
                        style={{
                            height: 50,
                            width: 50,
                            // backgroundColor: "#999",
                        }}
                        source={item.image_url != null && item.image_url.includes('http') ? { uri: item.image_url } : require('../../assets/icons/photos.png')}
                    />
                </View>
                <View style={{
                    flex: 1
                }}>
                    <Text
                        style={{
                            color: "white",
                            fontSize: 16,
                            fontWeight: "600",
                            marginLeft: 10,
                        }}
                    >{item.title}</Text>
                    <Text
                        style={{
                            color: "#ddd",
                            fontSize: 15,
                            marginLeft: 10,
                        }}
                    >{item.category_name}</Text>
                    {/* <Text
                        style={{
                            color: "white",
                            fontSize: 15,
                            marginLeft: 10,
                        }}
                    >{item.transId}</Text> */}
                </View>
                <Text
                    style={{
                        color: item.type == 'credit' ? 'green' : COLORS.appTheme,
                        fontSize: 16,
                        fontWeight: "600",
                        marginHorizontal: 10
                    }}
                >{(item.type == 'credit' ? '+' : '-') + '$ ' + item.amount}</Text>
            </TouchableOpacity>
        );
    };

    // const PopupMenu = (props) => {
    //     return <View style={{
    //         position: 'absolute',
    //         top: 0,
    //         bottom: 0,
    //         left: 0,
    //         right: 0,
    //         alignItems: 'flex-end'
    //     }} >
    //         <TouchableOpacity style={{
    //             position: 'absolute',
    //             top: 0,
    //             bottom: 0,
    //             left: 0,
    //             right: 0,
    //             backgroundColor: '#00000088'
    //         }} onPress={() => {
    //             setPopupMenu(false)
    //         }} />
    //         <View style={{
    //             height: 200,
    //             width: 150,
    //             backgroundColor: 'white',
    //             borderRadius: 10,
    //             marginRight: 10
    //         }}>
    //             <FlatList data = {['Add transaction']} />
    //         </View>
    //     </View>
    // }

    const CategoryCell = ({ item, index }) => {
        return <TouchableOpacity style={{
            paddingHorizontal: 15,
            height: 40,
            borderRadius: 20,
            backgroundColor: item.isSelected ? 'white' : '#00000000',
            justifyContent: 'center',
            alignItems: 'center',
            marginHorizontal: 5,
            borderWidth: 2,
            borderColor: 'white'
        }}
            onPress={() => {
                var _categories = [...categories]
                _categories[index].isSelected = !_categories[index].isSelected
                setCategories(_categories)
                getTransactionsRequest(accounts[currentPage].id, _categories)
            }} >
            <Text style={{
                color: item.isSelected ? COLORS.appDarkGray : 'white',
                fontSize: 17,
                fontWeight: '600'
            }}>{item.title}</Text>
        </TouchableOpacity>
    }

    const onScrollEnd = (e) => {
        let contentOffset = e.nativeEvent.contentOffset;
        let viewSize = e.nativeEvent.layoutMeasurement;

        let pageNum = Math.floor(contentOffset.x / viewSize.width);
        console.log('scrolled to page ', pageNum);
        currentPage = pageNum
        getTransactionsRequest(accounts[currentPage].id, categories)
    }

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: COLORS.appGray,
            }}
        >
            <StatusBar barStyle='light-content' />
            <View
                style={{
                    flex: 1,
                    // alignItems: 'center'
                }}
            >
                <View
                    style={{
                        // position: "absolute",
                        // height: 150,
                        width: "100%",
                        justifyContent: "center",
                    }}
                >
                    <FlatList
                        style={{
                            // backgroundColor: "white",
                            height: 250,
                            width: '100%',
                            // marginVertical: 15
                        }}
                        showsHorizontalScrollIndicator={false}
                        horizontal
                        pagingEnabled
                        onMomentumScrollEnd={onScrollEnd}
                        keyExtractor={(item, index) => item.id}
                        data={accounts}
                        renderItem={accountCell}
                    />
                </View>
                <View
                    style={{
                        width: "100%",
                        height: 40
                    }}
                >
                    <FlatList
                        style={{
                            height: 40,
                            width: '100%',
                        }}
                        showsHorizontalScrollIndicator={false}
                        horizontal
                        // keyExtractor={(item, index) => item.id}
                        data={categories}
                        renderItem={CategoryCell}
                    />
                </View>
                {/* <ScrollView style={{
                    // width: '95%'
                }} */}
                {/* showsVerticalScrollIndicator={false} > */}
                {transactions.length > 0 ?
                    <SectionList
                        contentContainerStyle={{
                            paddingBottom: 100
                        }}
                        style={{
                            flex: 1,
                        }}
                        keyExtractor={(item, index) => item.id}
                        sections={transactions}
                        renderItem={transationCell}
                        renderSectionHeader={({ section }) => {
                            return <View style={{
                                height: 50,
                                justifyContent: 'center',
                                paddingHorizontal: 10,
                                backgroundColor: COLORS.appDarkGray
                            }}>
                                <Text style={{
                                    color: 'white',
                                    fontSize: 18,
                                    fontWeight: '600'
                                }}>{section.title}</Text>
                            </View>
                        }}
                    /> : <NoDataView width={120} height={120} isRetry={false} />}
                {/* </ScrollView> */}
            </View>


            <FloatingAction
                color={COLORS.appTheme}
                actions={actions}
                onPressItem={name => {
                    if (name == 'bt_addtransaction') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addtransaction',
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Transaction'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                }}
            />
            {/* {isPopupMenu && <PopupMenu />} */}

            <ActionSheet
                ref={o => this.ActionSheet = o}
                // title={''}
                options={['Edit', 'Delete', 'Cancel']}
                cancelButtonIndex={2}
                destructiveButtonIndex={1}
                onPress={(index) => {
                    if (index == 0) {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addtransaction',
                                passProps: {
                                    data: selectedSection
                                },
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Transaction'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                    else if (index == 1) {
                        Alert.alert(
                            ('Delete Transaction'),
                            ('Are you sure you want to delete this transaction?'),
                            [
                                {
                                    text: ('Delete'),
                                    style: 'destructive',
                                    onPress: async () => {
                                        removeTransactionRequest()
                                    },
                                },
                                { text: ('Cancel'), style: 'cancel' },
                            ],
                            {
                                cancelable: false,
                            },
                        );
                    }
                }}
            />

            <Loader visible={isLoader} />

        </SafeAreaView>
    );
};


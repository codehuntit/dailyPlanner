/**
 * twixy-budgeting-app
 */

import React, { useState } from 'react';
import {
    Image,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    ScrollView,
    StatusBar,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { ApiClient } from '../../config/ApiClient';
import { COLORS } from '../../config/colors';
import { validateEmail } from '../../config/validator';
import { AppButton } from '../components/AppButton';
import { AppTextInput } from '../components/AppTextInput';
import { Loader } from '../components/Loader';


export const signup = (props) => {

    const [isLoader, setLoader] = useState(false)

    const [username, setUsername] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')

    const [usernameError, setUsernameError] = useState('')
    const [emailError, setEmailError] = useState('')
    const [passwordError, setPasswordError] = useState('')
    const [confirmPasswordError, setConfirmError] = useState('')

    const clearAllMessages = () => {
        setUsernameError('')
        setEmailError('')
        setPasswordError('')
        setConfirmError('')
    }
    const validateData = () => {
        clearAllMessages()
        if (username == '') {
            setUsernameError('Please enter username.')
        }
        if (email == '') {
            setEmailError('Please enter email.')
        }
        else if (!validateEmail(email)) {
            setEmailError('Please enter valid email.')
        }
        if (password == '') {
            setPasswordError('Please enter password.')
        }
        if (confirmPassword == '') {
            setConfirmError('Please enter confirm password.')
        }

        if (password != '' && confirmPassword != '' && password != confirmPassword) {
            setConfirmError('New password and confirm password mismatch.')
        }

        if (username != '' && email != '' && validateEmail(email) && password != '' && confirmPassword != '' && password == confirmPassword) {
            onSignupPressed()
        }
    }

    onSignupPressed = () => {
        signUpRequest()
    }

    const signUpRequest = () => {
        ApiClient.fetchPostWithFormData('signup', { fullname: username, email: email, password: password, confirm_password: password}, true, setLoader, (data) => {
            if (data.status + '' == 'true') {
                setUsername('')
                setEmail('')
                setPassword('')
                setConfirmPassword('')
                alert(data.message)
                gotoLogin()
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    gotoLogin = () => {
        Navigation.push(props.componentId, {
            component: {
                name: 'com.twixy.login',
                options: {
                    topBar: {
                        title: {
                            text: 'Log in'
                        }
                    }
                }
            }
        })
    }

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: COLORS.appGray
        }}>
            <StatusBar barStyle='light-content' />
            <KeyboardAvoidingView
                style={{
                    flex: 1
                }}
                behavior='padding'
                enabled={Platform.OS == 'ios'}
                keyboardVerticalOffset={40} >
                <ScrollView style={{
                    flex: 1
                }}>
                    <View style={{
                        flex: 1,
                        alignItems: 'center'
                    }}>
                        <Image style={{
                            height: 100,
                            width: '60%',
                            marginTop: 30,
                            resizeMode: 'contain'
                        }}
                            source={require('../../assets/icons/twixy-icon.png')} />

                        <AppTextInput style={{
                            marginTop: 30,
                            width: '90%',
                        }}
                            errorMessage={usernameError}
                            onChangeText={setUsername}
                            value={username}
                            placeholder='Username' />
                        <AppTextInput style={{
                            marginTop: 20,
                            width: '90%',
                        }}
                            errorMessage={emailError}
                            onChangeText={setEmail}
                            value={email}
                            placeholder='Email'
                            keyboardType='email-address' />
                        <AppTextInput style={{
                            marginTop: 20,
                            width: '90%',
                        }}
                            errorMessage={passwordError}
                            onChangeText={setPassword}
                            value={password}
                            placeholder='Password'
                            secureTextEntry />
                        <AppTextInput style={{
                            marginTop: 20,
                            width: '90%',
                        }}
                            errorMessage={confirmPasswordError}
                            onChangeText={setConfirmPassword}
                            value={confirmPassword}
                            placeholder='Confirm password'
                            secureTextEntry />

                        <AppButton style={{
                            marginTop: 30,
                            width: '90%'
                        }}
                            title='Sign up'
                            onPress={validateData}
                        // onPress = {() => {
                        //     ApiClient.fetchGet('users', true, setLoader, (data) => {
                        //         alert(JSON.stringify(data))
                        //     }, (error) => {
                        //         alert(error)
                        //     })
                        // }}

                        />

                        <View style={{
                            marginTop: 20,
                            width: '90%',
                            height: 40,
                            alignItems: 'center'
                        }}>
                            <Text style={{
                                color: 'white',
                                fontSize: 16,
                            }}>Already have an account? {<Text style={{
                                color: COLORS.appTheme,
                                fontWeight: '500'
                            }} onPress={gotoLogin}>Sign in</Text>}</Text>
                        </View>

                    </View>
                </ScrollView>
            </KeyboardAvoidingView>

            <Loader visible={isLoader} />

        </SafeAreaView>
    );
};
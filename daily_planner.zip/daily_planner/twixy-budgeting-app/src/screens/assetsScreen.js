/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
    Dimensions,
    FlatList,
    Image,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TouchableOpacity,
    useColorScheme,
    View,
} from 'react-native';
import { FloatingAction } from 'react-native-floating-action';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../../config/colors';
//  import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

const actions = [
    {
        text: "Add Asset",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/coin.png"),
        name: "bt_addasset",
        position: 1
    }
];

export const assets = (props) => {

    const [tips, setTips] = useState([{
        id: '1',
        title: 'Assets 1',
        value: '$1300'
        //  icon: require('../assets/icons/tips/morning.png')
    }, {
        id: '2',
        title: 'Assets 2',
        value: '$1550'
        //  icon: require('../assets/icons/tips/afternoon.jpeg')
    }, {
        id: '3',
        title: 'Assets 3',
        value: '$1700'
        //  icon: require('../assets/icons/tips/journal.jpeg')
    }, {
        id: '4',
        title: 'Assets 4',
        value: '$890'
        //  icon: require('../assets/icons/tips/sleep-diary.jpeg')
    }, {
        id: '5',
        title: 'Assets 5',
        value: '$1000'
        //  icon: require('../assets/icons/tips/sleeping.jpeg')
    }])

    const TipCell = ({ item, index }) => {
        return <TouchableOpacity style={{
            height: 80,
            alignItems: 'center',
            flexDirection: 'row'
        }}>
            <View style={{
                height: 50,
                width: 50,
                borderRadius: 25,
                marginLeft: 10,
                overflow: item.image_url != null ? 'hidden' : 'visible'
                // backgroundColor: "#999",
            }}>
                <Image
                    style={{
                        height: 50,
                        width: 50,
                        // backgroundColor: "#999",
                    }}
                    source={item.image_url != null && item.image_url.includes('http') ? { uri: item.image_url } : require('../../assets/icons/photos.png')}
                />
            </View>
            <View>
                <Text style={{
                    fontSize: 17,
                    fontWeight: '500',
                    marginHorizontal: 10,
                    color: 'white'
                }}>{item.title}</Text>
                <Text style={{
                    fontSize: 17,
                    fontWeight: '500',
                    marginHorizontal: 10,
                    color: '#bbb'
                }}>{item.value}</Text>
            </View>
            <View style={{
                height: 1,
                backgroundColor: '#aaa',
                position: 'absolute',
                width: '100%',
                bottom: 0
            }} />
        </TouchableOpacity>
    }

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: COLORS.appGray
        }}>
            {/* <StatusBar barStyle={'dark-content'} /> */}
            {/* <View style = {{
                height: 44,
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                <Text style = {{
                    color: 'white',
                    fontSize: 17,
                    fontWeight: '500'
                }}>Assets</Text>
            </View> */}
            <View
                style={{
                    flex: 1,
                    // alignItems: 'center'
                }}
            >
                <View
                    style={{
                        position: "absolute",
                        height: 150,
                        width: "100%",
                        justifyContent: "center",
                        // backgroundColor: 'white'
                    }}
                >
                    <Text
                        style={{
                            fontSize: 30,
                            fontWeight: "700",
                            color: 'white',
                            textAlign: "center",
                            marginTop: -20,
                        }}
                    >$12350.50</Text>
                    <Text
                        style={{
                            fontSize: 14,
                            color: 'white',
                            textAlign: "center",
                        }}
                    >
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry.
          </Text>
                </View>
                <ScrollView style={{
                    // width: '95%'
                }}
                    showsVerticalScrollIndicator={false}>

                    <FlatList
                        style={{
                            backgroundColor: COLORS.appGray,
                            marginTop: 150,
                            borderTopLeftRadius: 20,
                            borderTopRightRadius: 20
                        }}

                        data={tips}
                        renderItem={TipCell} />
                </ScrollView>
            </View>
            <FloatingAction
                color={COLORS.appTheme}
                actions={actions}
                onPressItem={name => {
                    if (name == 'bt_addasset') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addasset',
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Asset'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                }}
            />

        </SafeAreaView>
    );
};

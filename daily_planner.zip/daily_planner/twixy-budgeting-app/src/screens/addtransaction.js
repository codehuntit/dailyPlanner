import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
  Platform,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import ActionSheet from "react-native-actionsheet";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from "moment";
import { COLORS } from "../../config/colors";
import { ApiClient } from "../../config/ApiClient";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";

const TransactionType = {
  debit: 'debit',
  credit: 'credit'
};


export const addtransaction = (props) => {
  const [isLoader, setLoader] = useState(false)

  const [selectedImage, setSecectedImage] = useState(null);
  const [selectedCategory, setCategory] = useState(null);
  const [selectedAccount, setAccount] = useState(null);
  const [selectedDate, setDate] = useState(null);
  const [selectedType, setType] = useState(TransactionType.debit);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const [trancName, setBudgetName] = useState('')
  const [trancAmount, setBudgetAmount] = useState('')

  const [nameError, setNameError] = useState('')
  const [categoryError, setCategoryError] = useState('')
  const [accountError, setAccountError] = useState('')
  const [amountError, setAmountError] = useState('')
  const [dateError, setDateError] = useState('')

  const getItemFromProps = (item, def) => {
    if(props.data != null && props.data[item] != null) {
      return props.data[item]
    }
    else {
      return def
    }
  }

  const clearAllMessages = () => {
    setNameError('')
    setCategoryError('')
    setAmountError('')
    setDateError('')
    setAccountError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (trancName == '') {
      setNameError('Please enter a name.')
    }
    if (selectedAccount == null) {
      setAccountError('Please choose an account.')
    }
    if (selectedCategory == null) {
      setCategoryError('Please choose a category.')
    }
    if (trancAmount == '') {
      setAmountError('Please enter amount.')
    }
    if (selectedDate == null) {
      setDateError('Please choose trasaction date.')
    }

    if (trancName != '' && selectedAccount != null && selectedCategory != null && trancAmount != '' && selectedDate != null) {
      addTransactionRequest()
    }
  }

  const addTransactionRequest = () => {
    var photo = {
      uri: (selectedImage != null && selectedImage != '') ? selectedImage.uri : '',
      type: 'image/jpeg',
      name: 'photo.jpg',
    };
    console.log({
      user_id: GlobalData.UserId,
      category_id: selectedCategory.id + '',
      category_name: selectedCategory.title + '',
      title: trancName,
      amount: trancAmount,
      transaction_date: moment(selectedDate).format('DD-MM-YYYY'),
      type: selectedType,
      account_id: selectedAccount.id
    })
    ApiClient.fetchPostWithFormData('add_transaction',
      (selectedImage != null && selectedImage != '') ? {
        user_id: GlobalData.UserId,
        category_id: selectedCategory.id + '',
        category_name: selectedCategory.title + '',
        title: trancName,
        amount: trancAmount,
        transaction_date: moment(selectedDate).format('DD-MM-YYYY'),
        type: selectedType,
        account_id: selectedAccount.id,
        image: photo
      } : {
          user_id: GlobalData.UserId,
          category_id: selectedCategory.id + '',
          category_name: selectedCategory.title + '',
          title: trancName,
          amount: trancAmount,
          transaction_date: moment(selectedDate).format('DD-MM-YYYY'),
          type: selectedType,
          account_id: selectedAccount.id
        }, true, setLoader, (data) => {
          if (data.status + '' == 'true') {
            alert(data.message)
            // props.getAccountsRequest()
            Navigation.pop(props.componentId)
          }
          else {
            alert(data.message)
          }
        }, (error) => {
          alert(error)
        })
  }

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    setDate(date)
    hideDatePicker();
  };

  const selectCategory = (category, index) => {
    setCategory(category)
  }

  const selectAccount = (account, index) => {
    setAccount(account)
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray,
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}
        behavior='padding'
        enabled={Platform.OS == 'ios'} >
        <ScrollView style={{
          flex: 1
        }}>
          <View
            style={{
              // flex: 1,
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              style={{
                height: 80,
                width: 80,
                // backgroundColor: "#999",
                marginTop: 30,
                justifyContent: 'center',
                alignItems: 'center'
              }}
              onPress={() => {
                this.ActionSheet.show()
              }} >
              <Image style={{
                height: 80,
                width: 80,
                borderRadius: selectedImage != null ? 40 : 0,
                resizeMode: selectedImage != null ? 'cover' : 'contain'
              }}
                source={selectedImage != null ? selectedImage : require('../../assets/icons/photos.png')} />
            </TouchableOpacity>

            <View
              style={{
                // height: 50,
                width: "80%",
              }}
            >
              <TextInput
                style={{
                  // flex: 1,
                  height: 40,
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                onChangeText={setBudgetName}
                value={trancName}
                placeholderTextColor='#999'
                placeholder="Title"
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {nameError != null && nameError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {nameError}</Text>}
            </View>

            <TouchableOpacity
              style={{
                // height: 50,
                width: "80%",
              }}
              onPress={() => {
                Navigation.showModal({
                  component: {
                    name: 'com.twixy.chooseAccount',
                    passProps: {
                      selectAccount: selectAccount
                    }
                  }
                })
              }} >
              <Text
                style={{
                  // flex: 1,
                  height: 40,
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white'
                }}
              >{selectedAccount != null ? selectedAccount.title : 'Choose Account'}</Text>

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {accountError != null && accountError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {accountError}</Text>}
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                // height: 50,
                width: "80%",
              }}
              onPress={() => {
                Navigation.showModal({
                  component: {
                    name: 'com.twixy.chooseCategories',
                    passProps: {
                      selectCategory: selectCategory
                    }
                  }
                })
              }} >
              <Text
                style={{
                  // flex: 1,
                  height: 40,
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white'
                }}
              >{selectedCategory != null ? selectedCategory.title : 'Choose Category'}</Text>

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {categoryError != null && categoryError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {categoryError}</Text>}
            </TouchableOpacity>

            <View
              style={{
                // height: 50,
                width: "80%",
              }}
            >
              <TextInput
                style={{
                  // flex: 1,
                  height: 40,
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                value={trancAmount}
                onChangeText={setBudgetAmount}
                keyboardType='decimal-pad'
                placeholderTextColor='#999'
                placeholder="Amount"
              />
              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {amountError != null && amountError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {amountError}</Text>}
            </View>

            <TouchableOpacity
              style={{
                // height: 50,
                width: "80%",
              }}
              onPress={showDatePicker}
            >
              <Text
                style={{
                  // flex: 1,
                  height: 40,
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white'
                }}
              >{selectedDate != null ? moment(selectedDate).format('DD-MM-YYYY') : 'Choose Date'}</Text>
              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {dateError != null && dateError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {dateError}</Text>}
            </TouchableOpacity>

            <View
              style={{
                height: 50,
                width: "80%",
                flexDirection: 'row',
                marginTop: 20
              }}
            >
              <TouchableOpacity style={{
                flex: 1,
                // justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
              }}
                onPress={() => {
                  setType(TransactionType.debit)
                }} >
                <Image style={{
                  height: 20,
                  width: 20,
                  borderRadius: 20,
                  tintColor: 'white'
                }}
                  source={selectedType == TransactionType.debit ? require('../../assets/icons/radio-on.png') : require('../../assets/icons/radio-off.png')} />
                <Text style={{
                  fontSize: 16,
                  fontWeight: '600',
                  color: 'white',
                  marginLeft: 15
                }}>Debit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                flex: 1,
                // justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
              }}
                onPress={() => {
                  setType(TransactionType.credit)
                }} >
                <Image style={{
                  height: 20,
                  width: 20,
                  borderRadius: 20,
                  tintColor: 'white'
                }}
                  source={selectedType == TransactionType.credit ? require('../../assets/icons/radio-on.png') : require('../../assets/icons/radio-off.png')} />
                <Text style={{
                  fontSize: 16,
                  fontWeight: '600',
                  color: 'white',
                  marginLeft: 15
                }}>Credit</Text>
              </TouchableOpacity>
            </View>


            <TouchableOpacity style={{
              height: 40,
              backgroundColor: '#A74834',
              width: '80%',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: 20,
              marginTop: 40
            }}
              onPress={validateData} >
              <Text style={{
                color: 'white',
                fontSize: 16,
                fontWeight: '500'
              }}>Submit</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
        }}
      />

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        maximumDate={new Date()}
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />

      <Loader visible={isLoader} />

    </SafeAreaView>
  );
};

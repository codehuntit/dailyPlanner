import React, { useState, useEffect } from "react";
import {
    Text,
    View,
    SafeAreaView,
    StatusBar,
    Dimensions,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Image,
    ScrollView,
    KeyboardAvoidingView,
    FlatList,
} from "react-native";
import { FloatingAction } from "react-native-floating-action";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";
import { NoDataView } from "../components/NoDataView";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";

const actions = [
    {
        text: "Add Account",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/coin.png"),
        name: "bt_addaccount",
        position: 1
    }
];

export const accounts = (props) => {

    const [isLoader, setLoader] = useState(false)

    const [accounts, setAccounts] = useState([
        // {
        //     id: 3,
        //     title: 'BNP Paribas Norway',
        //     bankName: 'BNP Paribas Norway',
        //     cardNo: 'xxxx xxxx xxxx 9898'
        // }, {
        //     id: 4,
        //     title: 'Swedbank Norway',
        //     bankName: 'BNP Paribas Norway',
        //     cardNo: 'xxxx xxxx xxxx 4513'
        // }, {
        //     id: 5,
        //     title: 'Handelsbanken Norway',
        //     bankName: 'BNP Paribas Norway',
        //     cardNo: 'xxxx xxxx xxxx 7854'
        // }, {
        //     id: 6,
        //     title: 'Skandia Bank',
        //     bankName: 'BNP Paribas Norway',
        //     cardNo: 'xxxx xxxx xxxx 1545'
        // }, {
        //     id: 7,
        //     title: 'Bank Norwegian',
        //     bankName: 'BNP Paribas Norway',
        //     cardNo: 'xxxx xxxx xxxx 9654'
        // }, {
        //     id: 8,
        //     title: 'DinBank',
        //     bankName: 'BNP Paribas Norway',
        //     cardNo: 'xxxx xxxx xxxx 7485'
        // }, 
        // {
        //     id: 9,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 10,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 11,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 12,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }
    ]);

    useEffect(() => {
        Navigation.events().registerNavigationButtonPressedListener(navigationButtonPressed)
        getAccountsRequest()
    }, [])

    const getAccountsRequest = () => {
        ApiClient.fetchPostWithFormData('fetch_account_by_user_id', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true' && data.details != null) {
                setAccounts(data.details)
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const navigationButtonPressed = ({ buttonId }) => {
        if (buttonId == 'sideMenu') {
            Navigation.mergeOptions(props.componentId, {
                sideMenu: {
                    left: {
                        visible: true
                    }
                }
            });
        }
        else if (buttonId == 'editAccount') {

        }
    }

    const gotoAccountDetail = (item, index) => {
        Navigation.push(props.componentId, {
            component: {
                name: 'com.twixy.accountDetail',
                passProps: {
                    data: item,
                    getAccountsRequest: getAccountsRequest
                },
                options: {
                    sideMenu: {
                        left: {
                            visible: false,
                        },
                    },
                    topBar: {
                        backButton: {
                            color: COLORS.appTheme
                        },
                        background: {
                            color: COLORS.appDarkGray
                        },
                        title: {
                            text: 'Account Detail',
                            color: 'white'
                        },
                        rightButtons: [{
                            id: 'editAccount',
                            text: 'Edit',
                            color: COLORS.appTheme
                        }]
                    }
                },
            }
        })
    }

    const accountCell = ({ item, index }) => {
        return (
            <TouchableOpacity
                style={{
                    height: 80,
                    flexDirection: "row",
                    alignItems: "center",
                }}
                onPress={() => {
                    gotoAccountDetail(item, index)
                }} >
                <View
                    style={{
                        height: 1,
                        position: "absolute",
                        bottom: 0,
                        width: "100%",
                        backgroundColor: '#ccc',
                    }}
                />
                <View style={{
                    height: 50,
                    width: 50,
                    borderRadius: 25,
                    marginLeft: 10,
                    overflow: item.image_url != null ? 'hidden' : 'visible'
                    // backgroundColor: "#999",
                }}>
                    <Image
                        style={{
                            height: 50,
                            width: 50,
                            // backgroundColor: "#999",
                        }}
                        source={item.image_url != null ? { uri: item.image_url } : require('../../assets/icons/photos.png')}
                    />
                </View>
                <View style={{
                    flex: 1
                }}>
                    <Text
                        style={{
                            fontSize: 16,
                            fontWeight: "500",
                            marginLeft: 10,
                            color: 'white'
                        }}
                    >{item.title}</Text>
                    <Text
                        style={{
                            color: "#aaa",
                            fontSize: 15,
                            marginLeft: 10,
                        }}
                    >{item.bank_name}</Text>
                    <Text
                        style={{
                            color: "#aaa",
                            fontSize: 15,
                            marginLeft: 10,
                        }}
                    >{item.account_number}</Text>
                </View>
                <Image
                    style={{
                        height: 20,
                        width: 20,
                        resizeMode: 'contain',
                        marginRight: 10,
                        tintColor: '#ccc'
                    }}
                    source={require('../../assets/icons/right-arrow-angle.png')} />
            </TouchableOpacity>
        );
    };

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: COLORS.appGray,
            }}
        >
            <StatusBar barStyle='light-content' />
            <View
                style={{
                    flex: 1,
                    // alignItems: 'center'
                }}
            >
                {accounts.length > 0 ? <FlatList
                    style={{
                        // backgroundColor: "white",
                    }}
                    keyExtractor={(item, index) => item.id}
                    data={accounts}
                    renderItem={accountCell}
                />
                    : <NoDataView
                        isRetry={true}
                        onRetry={() => {
                            getAccountsRequest()
                            // setLoader(true)
                            // getCompaniesApi()
                        }} />}
            </View>

            <FloatingAction
                color={COLORS.appTheme}
                actions={actions}
                onPressItem={name => {
                    if (name == 'bt_addaccount') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addaccount',
                                passProps: {
                                    getAccountsRequest: getAccountsRequest
                                },
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Account'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                    // else if (name == 'bt_addbudget') {
                    //     Navigation.push(props.componentId, {
                    //         component: {
                    //             name: 'com.twixy.addbudget',
                    //             options: {
                    //                 topBar: {
                    //                     background: {
                    //                         color: COLORS.appDarkGray
                    //                     },
                    //                     title: {
                    //                         color: 'white',
                    //                         fontSize: 20,
                    //                         text: 'Add Budget'
                    //                     },
                    //                     backButton: {
                    //                         color: 'white'
                    //                     }
                    //                 }
                    //             }
                    //         }
                    //     })
                    // }
                }}
            />

            <Loader visible={isLoader} />

        </SafeAreaView>
    );
};


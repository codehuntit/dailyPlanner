import React, { useState, useEffect } from "react";
import {
    Text,
    View,
    SafeAreaView,
    StatusBar,
    Dimensions,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Image,
    ScrollView,
    KeyboardAvoidingView,
    FlatList,
} from "react-native";
import { BarChart, LineChart } from "react-native-chart-kit";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { COLORS } from "../../config/colors";
import { NoDataView } from "../components/NoDataView";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";

const chartConfig = {
    backgroundGradientFrom: COLORS.appTheme,
    // backgroundGradientFromOpacity: 0,
    backgroundGradientTo: COLORS.appTheme,
    // backgroundGradientToOpacity: 0.5,
    color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
    strokeWidth: 2, // optional, default 3
    // barPercentage: 0.5,
    useShadowColorFromDataset: false // optional
};

const data = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    datasets: [
      {
        data: [20, 45, 28, 80, 99, 43, 54, 345, 23, 43, 89, 22]
      }
    ]
  };

export const report = (props) => {


    useEffect(() => {
        Navigation.events().registerNavigationButtonPressedListener(navigationButtonPressed)
    }, [])

    const navigationButtonPressed = ({ buttonId }) => {
        if (buttonId == 'sideMenu') {
            Navigation.mergeOptions(props.componentId, {
                sideMenu: {
                    left: {
                        visible: true
                    }
                }
            });
        }
    }

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: COLORS.appGray,
            }}
        >
            <StatusBar barStyle='light-content' />
            <View
                style={{
                    flex: 1,
                    alignItems: 'center'
                }}
            >
                <LineChart
                    data={{
                        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                        datasets: [
                            {
                                data: [
                                    Math.random() * 100,
                                    Math.random() * 100,
                                    Math.random() * 100,
                                    Math.random() * 100,
                                    Math.random() * 100,
                                    Math.random() * 100,
                                    Math.random() * 100,
                                    Math.random() * 100
                                ]
                            }
                        ]
                    }}
                    width={Dimensions.get("window").width / 1.05} // from react-native
                    height={220}
                    yAxisLabel="$"
                    yAxisSuffix="k"
                    yAxisInterval={1} // optional, defaults to 1
                    chartConfig={chartConfig}
                    bezier
                    style={{
                        marginVertical: 8,
                        borderRadius: 16
                    }}
                />

                <BarChart
                    style={{
                        marginVertical: 8,
                        borderRadius: 16
                    }}
                    data={data}
                    width={Dimensions.get("window").width / 1.05}
                    height={220}
                    yAxisLabel="$"
                    chartConfig={chartConfig}
                    verticalLabelRotation={30}
                />
            </View>

        </SafeAreaView>
    );
};


import React, { useState, useEffect } from "react";
import {
    Text,
    View,
    SafeAreaView,
    StatusBar,
    Dimensions,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Image,
    ScrollView,
    KeyboardAvoidingView,
    FlatList,
    SectionList,
    Alert,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { COLORS } from "../../config/colors";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";
import ActionSheet from 'react-native-actionsheet'
import { FloatingAction } from "react-native-floating-action";
import { ApiClient } from "../../config/ApiClient";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";
import { NoDataView } from "../components/NoDataView";

const actions = [
    {
        text: "Add Category",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/list.png"),
        name: "bt_addcategory",
        position: 1
    },
    {
        text: "Add Budget",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/pie-chart.png"),
        name: "bt_addbudget",
        position: 2
    }
];

const TransactionType = {
    debit: 'debit',
    credit: 'credit'
};

const getBudgetsRequest = () => {
    ApiClient.fetchPostWithFormData('fetch_account_by_user_id', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
        console.log(data)
        if (data.status + '' == 'true' && data.details != null) {
            setAccounts(data.details)
        }
        else {
            alert(data.message)
        }
    }, (error) => {
        alert(error)
    })
}

export const budget = (props) => {

    const [isLoader, setLoader] = useState(false)

    const [selectedIndex, setIndex] = useState(-1)
    const [budgets, setBudgets] = useState([
        //     {
        //     id: 1,
        //     title: 'My food',
        //     category: {
        //         id: 1,
        //         title: 'Food',
        //         image: ''
        //     },
        //     amount: '$120',
        //     expDate: '21/04/2021',
        //     type: TransactionType.debit
        // }, {
        //     id: 2,
        //     title: 'My drinking',
        //     category: {
        //         id: 1,
        //         title: 'Food',
        //         image: ''
        //     },
        //     amount: '$123',
        //     expDate: '10/04/2021',
        //     type: TransactionType.debit
        // }, {
        //     id: 3,
        //     title: 'My shopping',
        //     category: {
        //         id: 1,
        //         title: 'Shopping',
        //         image: ''
        //     },
        //     amount: '$20',
        //     expDate: '12/04/2021',
        //     type: TransactionType.debit
        // }, {
        //     id: 4,
        //     title: 'Demo budget',
        //     category: {
        //         id: 1,
        //         title: 'Others',
        //         image: ''
        //     },
        //     amount: '$240',
        //     expDate: '18/04/2021',
        //     type: TransactionType.credit
        // }, {
        //     id: 5,
        //     title: 'Flat rent',
        //     category: {
        //         id: 1,
        //         title: 'Rent',
        //         image: ''
        //     },
        //     amount: '$145',
        //     expDate: '30/04/2021',
        //     type: TransactionType.debit
        // }
    ]);

    useEffect(() => {
        getBudgetsRequest()
    }, [])

    const getBudgetsRequest = () => {
        ApiClient.fetchPostWithFormData('budget_listing', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true' && data.details != null) {
                setBudgets(data.details)
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const removeBudgetRequest = () => {
        ApiClient.fetchPostWithFormData('delete_budget', { budget_id: budgets[selectedIndex].id }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true') {
                if (selectedIndex != -1 && selectedIndex < budgets.length) {
                    var _items = [...budgets]
                    _items.splice(selectedIndex, 1)
                    setBudgets(_items)
                    setIndex(-1)
                }
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const budgetCell = ({ item, index }) => {
        return <TouchableOpacity style={{
            minHeight: 80,
            flexDirection: 'row',
            alignItems: 'center'
        }} onLongPress={() => {
            setIndex(index)
            this.ActionSheet.show()
        }}>
            <View style={{
                position: 'absolute',
                height: 1,
                bottom: 0,
                width: '100%',
                backgroundColor: '#ffffff33'
            }} />
            <View style={{
                height: 50,
                width: 50,
                borderRadius: 25,
                marginLeft: 10,
                overflow: item.image_url != null ? 'hidden' : 'visible'
                // backgroundColor: "#999",
            }}>
                <Image
                    style={{
                        height: 50,
                        width: 50,
                        // borderRadius: 25,
                        // marginLeft: 10,
                        // backgroundColor: "#999",
                    }}
                    source={item.image_url != null ? { uri: item.image_url } : require('../../assets/icons/photos.png')} />
            </View>
            <View style={{
                flex: 1,
                marginLeft: 15,
                flexDirection: 'row',
                alignItems: 'center'
            }}>
                <View style={{
                    flex: 1,
                    justifyContent: 'center',
                }}>
                    <Text
                        style={{
                            color: "white",
                            fontSize: 17,
                            fontWeight: "500"
                        }}
                    >
                        {item.title}
                    </Text>
                    {/* <View style = {{
                        backgroundColor: 'white',
                        height: 20,
                        borderRadius: 10,
                        paddingHorizontal: 7,
                        marginVertical: 3,
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}> */}
                    <Text
                        style={{
                            color: 'white',
                            fontSize: 14,
                            fontWeight: '500'
                        }}
                    >
                        {item.category_name}
                    </Text>
                    {/* </View> */}
                    <Text
                        style={{
                            color: "#999",
                            fontSize: 14,
                            fontWeight: "500"
                        }}
                    >
                        Exp. Date: {item.expire_date}
                    </Text>
                </View>
                <Text
                    style={{
                        color: item.type == TransactionType.credit ? 'green' : COLORS.appTheme,
                        fontSize: 17,
                        fontWeight: "500",
                        marginRight: 15
                    }}
                >
                    $ {item.amount}
                </Text>
            </View>
        </TouchableOpacity>
    }

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: COLORS.appGray,
            }}>
            <StatusBar barStyle='light-content' />
            {budgets.length > 0 ? <View
                style={{
                    flex: 1,
                    // alignItems: 'center'
                }}
            >
                <FlatList
                    style={{
                        flex: 1
                    }}
                    data={budgets}
                    renderItem={budgetCell} />
            </View> : <NoDataView isRetry={true}
                onRetry={() => {
                    getBudgetsRequest()
                    // setLoader(true)
                    // getCompaniesApi()
                }} />}
            {/* <TouchableOpacity style={{
                backgroundColor: COLORS.appTheme,
                position: 'absolute',
                bottom: 40,
                right: 15,
                height: 60,
                width: 60,
                borderRadius: 30,
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                <Image style={{
                    height: 30,
                    width: 30,
                    resizeMode: 'contain',
                    tintColor: 'white'
                }} source={require('../../assets/icons/plus.png')} />
            </TouchableOpacity> */}
            {/* {isPopupMenu && <PopupMenu />} */}

            <FloatingAction
                color={COLORS.appTheme}
                actions={actions}
                onPressItem={name => {
                    if (name == 'bt_addcategory') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addcategory',
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Category'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                    else if (name == 'bt_addbudget') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addbudget',
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Budget'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                }}
            />

            <ActionSheet
                ref={o => this.ActionSheet = o}
                // title={''}
                options={['Delete', 'Cancel']}
                cancelButtonIndex={1}
                destructiveButtonIndex={0}
                onPress={(index) => {
                    if (index == 0) {
                        Alert.alert(
                            ('Delete Budget'),
                            ('Are you sure you want to delete this budget?'),
                            [
                                {
                                    text: ('Delete'),
                                    style: 'destructive',
                                    onPress: async () => {
                                        removeBudgetRequest()
                                    },
                                },
                                { text: ('Cancel'), style: 'cancel' },
                            ],
                            {
                                cancelable: false,
                            },
                        );

                    }
                }}
            />

            <Loader visible={isLoader} />

        </SafeAreaView>
    );
};


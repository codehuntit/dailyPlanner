import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";

export const chooseAccount = (props) => {

  const [isLoader, setLoader] = useState(false)

  const [selectedIndex, setIndex] = useState(-1)
  const [accounts, setAccounts] = useState([])

  useEffect(() => {
    getAccountsRequest()
  }, [])

  const getAccountsRequest = () => {
    ApiClient.fetchPostWithFormData('fetch_account_by_user_id', { user_id: GlobalData.UserId }, false, setLoader, (data) => {
      console.log(data)
      if (data.status + '' == 'true' && data.details != null) {
        setAccounts(data.details)
      }
      else {
        alert(data.message)
      }
    }, (error) => {
      alert(error)
    })
  }

  const accountCell = ({ item, index }) => {
    return <TouchableOpacity
      style={{
        height: 70,
        flexDirection: "row",
        alignItems: "center",
      }}
      onPress={() => {
        setIndex(index)
      }} >
      <View
        style={{
          height: 1,
          position: "absolute",
          bottom: 0,
          width: "100%",
          backgroundColor: '#999',
        }}
      />
      <Image
        style={{
          height: 30,
          width: 30,
          borderRadius: 15,
          marginLeft: 10,
          // backgroundColor: "#999",
        }}
        source={item.icon} />
      <View style={{
        flex: 1
      }}>
        <Text
          style={{
            // color: "white",
            fontSize: 18,
            fontWeight: "500",
            marginLeft: 10,
          }}
        >
          {item.title}
        </Text>
        <Text
          style={{
            color: "#888",
            fontSize: 15,
            marginLeft: 10,
          }}
        >{item.bank_name}</Text>
        <Text
          style={{
            color: "#888",
            fontSize: 15,
            marginLeft: 10,
          }}
        >{item.account_number}</Text>
      </View>
      {selectedIndex == index && <Image
        style={{
          height: 24,
          width: 24,
          marginRight: 15,
          tintColor: COLORS.appTheme
        }}
        source={require('../../assets/icons/checked.png')} />}
    </TouchableOpacity>
  }

  return (
    <SafeAreaView
      style={{
        flex: 1
      }}
    >
      <View
        style={{
          flex: 1,
          alignItems: "center",
        }}
      >
        <View style={{
          height: 44,
          width: '100%',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <Text style={{
            fontSize: 17,
            fontWeight: '600'
          }}>Choose Account</Text>

          <TouchableOpacity style={{
            position: 'absolute',
            right: 10,
            height: 44,
            width: 44,
            justifyContent: 'center',
            alignItems: 'center'
          }}
            onPress={() => {
              Navigation.dismissModal(props.componentId)
            }} >
            <Image
              style={{
                height: 20,
                width: 20,
              }}
              source={require('../../assets/icons/close.png')} />
          </TouchableOpacity>

        </View>
        <FlatList
          style={{
            flex: 1,
            width: '100%'
          }}
          data={accounts}
          keyExtractor={(item, index) => item.id}
          renderItem={accountCell} />

        <TouchableOpacity style={{
          height: 40,
          backgroundColor: '#A74834',
          width: '80%',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: 20,
          marginTop: 20
        }}
          onPress={() => {
            if (selectedIndex != -1) {
              props.selectAccount(accounts[selectedIndex], selectedIndex)
              Navigation.dismissModal(props.componentId)
            }
            else {
              alert('Please choose a account.')
            }
          }} >
          <Text style={{
            color: 'white',
            fontSize: 16,
            fontWeight: '500'
          }}>Choose</Text>
        </TouchableOpacity>
      </View>

      {/* <Loader visible={isLoader} /> */}

    </SafeAreaView>
  );
};

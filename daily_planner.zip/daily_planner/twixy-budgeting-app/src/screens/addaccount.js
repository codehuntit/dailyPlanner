import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
  Platform,
} from "react-native";
import ActionSheet from "react-native-actionsheet";
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";

export const addaccount = (props) => {

  const [isLoader, setLoader] = useState(false)

  const [selectedImage, setSecectedImage] = useState(null);

  const [accountTitle, setTitle] = useState('')
  const [bankName, setBankName] = useState('')
  const [accountNumber, setAccountNumber] = useState('')

  const [titleError, setTitleError] = useState('')
  const [bankNameError, setBankNameError] = useState('')
  const [accountNumberError, setAccountNumberError] = useState('')

  const clearAllMessages = () => {
    setTitleError('')
    setBankNameError('')
    setAccountNumberError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (accountTitle == '') {
      setTitleError('Please enter title.')
    }
    if (bankName == '') {
      setBankNameError('Please enter bank name.')
    }
    if (accountNumber == '') {
      setAccountNumberError('Please enter account number.')
    }

    if (accountTitle != '' && bankName != '' && accountNumber != '') {
      addAccountRequest()
    }
  }

  const addAccountRequest = () => {
    var photo = {
      uri: (selectedImage != null && selectedImage != '') ? selectedImage.uri : '',
      type: 'image/jpeg',
      name: 'photo.jpg',
    };
    ApiClient.fetchPostWithFormData('add_account',
      (selectedImage != null && selectedImage != '') ? {
        user_id: GlobalData.UserId,
        bank_name: bankName,
        title: accountTitle,
        account_number: accountNumber,
        image: photo
      } : {
          user_id: GlobalData.UserId,
          bank_name: bankName,
          title: accountTitle,
          account_number: accountNumber
        }, true, setLoader, (data) => {
          if (data.status + '' == 'true') {
            alert(data.message)
            props.getAccountsRequest()
            Navigation.pop(props.componentId)
            // props.getProfileRequest()
          }
          else {
            alert(data.message)
          }
        }, (error) => {
          alert(error)
        })
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray,
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}
        behavior='padding'
        enabled={Platform.OS == 'ios'} >
        <ScrollView style={{
          flex: 1
        }}>
          <View
            style={{
              flex: 1,
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              style={{
                height: 80,
                width: 80,
                // backgroundColor: "#999",
                marginTop: 30,
                justifyContent: 'center',
                alignItems: 'center'
              }}
              onPress={() => {
                this.ActionSheet.show()
              }} >
              <Image style={{
                height: 80,
                width: 80,
                borderRadius: selectedImage != null ? 40 : 0,
                resizeMode: selectedImage != null ? 'cover' : 'contain'
              }}
                source={selectedImage != null ? selectedImage : require('../../assets/icons/photos.png')} />
            </TouchableOpacity>

            <View
              style={{
                // height: 50,
                width: "90%",
              }}
            >
              <TextInput
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                value={accountTitle}
                onChangeText={setTitle}
                placeholderTextColor='#999'
                placeholder="Title"
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />

              {titleError != null && titleError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {titleError}</Text>}

            </View>

            <View
              style={{
                // height: 50,
                width: "90%",
              }}
            >
              <TextInput
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                value={bankName}
                onChangeText={setBankName}
                placeholderTextColor='#999'
                placeholder="Bank Name"
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />

              {bankNameError != null && bankNameError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {bankNameError}</Text>}

            </View>

            <View
              style={{
                // height: 50,
                width: "90%",
              }}
            >
              <TextInput
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                value={accountNumber}
                onChangeText={setAccountNumber}
                keyboardType='number-pad'
                placeholderTextColor='#999'
                placeholder="Account Number"
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />

              {accountNumberError != null && accountNumberError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {accountNumberError}</Text>}

            </View>

            <TouchableOpacity style={{
              height: 40,
              backgroundColor: '#A74834',
              width: '90%',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: 20,
              marginTop: 40
            }}
              onPress={validateData} >
              <Text style={{
                color: 'white',
                fontSize: 16,
                fontWeight: '500'
              }}>Submit</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
        }}
      />

      <Loader visible={isLoader} />

    </SafeAreaView>
  );
};

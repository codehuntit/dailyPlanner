import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";
import ActionSheet from "react-native-actionsheet";
import { FloatingAction } from "react-native-floating-action";
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";

const actions = [
  {
    text: "Add Category",
    color: COLORS.appTheme,
    icon: require("../../assets/icons/list.png"),
    name: "bt_addcategory",
    position: 1
  }
];

export const CategoriesList = (props) => {
  const [isLoader, setLoader] = useState(false)

  const [selectedIndex, setIndex] = useState(-1)
  const [categories, setCategories] = useState([
    // { id: 1, title: 'Books', icon: require('../../assets/icons/category_icons/Books.png') },
    // { id: 2, title: 'Drinks', icon: require('../../assets/icons/category_icons/Drinks.png') },
    // { id: 3, title: 'Entertain', icon: require('../../assets/icons/category_icons/Entertain.png') },
    // { id: 4, title: 'Food', icon: require('../../assets/icons/category_icons/Food.png') },
    // { id: 5, title: 'General', icon: require('../../assets/icons/category_icons/General.png') },
    // { id: 6, title: 'Groceries', icon: require('../../assets/icons/category_icons/Groceries.png') },
    // { id: 7, title: 'Personal', icon: require('../../assets/icons/category_icons/Personal.png') },
    // { id: 8, title: 'Shopping', icon: require('../../assets/icons/category_icons/Shopping.png') },
    // { id: 9, title: 'Transfer', icon: require('../../assets/icons/category_icons/Transfer.png') },
    // { id: 10, title: 'Transport', icon: require('../../assets/icons/category_icons/Transport.png') },
    // { id: 11, title: 'Travel', icon: require('../../assets/icons/category_icons/Travel.png') }
  ]);

  useEffect(() => {
    getCategoriesRequest()
  }, [])

  const getCategoriesRequest = () => {
    ApiClient.fetchPostWithFormData('fetch_category', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
      console.log(data)
      if (data.status + '' == 'true' && data.details != null) {
        setCategories(data.details)
      }
      else {
        alert(data.message)
      }
    }, (error) => {
      alert(error)
    })
  }

  // const removeCategoryRequest = () => {
  //   ApiClient.fetchPostWithFormData('delete_budget', { budget_id: budgets[selectedIndex].id }, true, setLoader, (data) => {
  //     console.log(data)
  //     if (data.status + '' == 'true') {
  //       if (selectedIndex != -1 && selectedIndex < budgets.length) {
  //         var _items = [...budgets]
  //         _items.splice(selectedIndex, 1)
  //         setBudgets(_items)
  //         setIndex(-1)
  //       }
  //     }
  //     else {
  //       alert(data.message)
  //     }
  //   }, (error) => {
  //     alert(error)
  //   })
  // }

  const categoryCell = ({ item, index }) => {
    return <TouchableOpacity
      style={{
        height: 70,
        flexDirection: "row",
        alignItems: "center",
      }}
      onPress={() => {
        // setIndex(index)
      }} >
      <View
        style={{
          height: 1,
          position: "absolute",
          bottom: 0,
          width: "100%",
          backgroundColor: '#999',
        }}
      />
      <View style={{
        height: 40,
        width: 40,
        borderRadius: 20,
        marginLeft: 10,
        overflow: item.image_url != null ? 'hidden' : 'visible'
      }}>
        <Image
          style={{
            height: 40,
            width: 40,
            // borderRadius: 15,
            // marginLeft: 10,
            // backgroundColor: "#999",
          }}
          source={item.image_url != null ? { uri: item.image_url } : require('../../assets/icons/photos.png')} />
      </View>
      <View style={{
        flex: 1
      }}>
        <Text
          style={{
            color: "white",
            fontSize: 18,
            fontWeight: "500",
            marginLeft: 10,
          }}
        >
          {item.category_name}
        </Text>
      </View>
      {selectedIndex == index && <Image
        style={{
          height: 24,
          width: 24,
          marginRight: 15,
          tintColor: COLORS.appTheme
        }}
        source={require('../../assets/icons/checked.png')} />}
    </TouchableOpacity>
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray
      }}
    >
      <View
        style={{
          flex: 1,
          alignItems: "center",
        }}
      >
        <FlatList
          style={{
            flex: 1,
            width: '100%'
          }}
          data={categories}
          keyExtractor={(item, index) => item.id}
          renderItem={categoryCell} />

      </View>


      <FloatingAction
        color={COLORS.appTheme}
        actions={actions}
        onPressItem={name => {
          if (name == 'bt_addcategory') {
            Navigation.push(props.componentId, {
              component: {
                name: 'com.twixy.addcategory',
                passProps: {
                  getCategoriesRequest: getCategoriesRequest
                },
                options: {
                  topBar: {
                    background: {
                      color: COLORS.appDarkGray
                    },
                    title: {
                      color: 'white',
                      fontSize: 20,
                      text: 'Add Category'
                    },
                    backButton: {
                      color: 'white'
                    }
                  }
                }
              }
            })
          }
        }}
      />

      {/* <ActionSheet
        ref={o => this.ActionSheet = o}
        // title={''}
        options={['Delete', 'Cancel']}
        cancelButtonIndex={1}
        destructiveButtonIndex={0}
        onPress={(index) => {
          if (index == 0) {
            Alert.alert(
              ('Delete Category'),
              ('Are you sure you want to delete this category?'),
              [
                {
                  text: ('Delete'),
                  style: 'destructive',
                  onPress: async () => {
                    removeBudgetRequest()
                  },
                },
                { text: ('Cancel'), style: 'cancel' },
              ],
              {
                cancelable: false,
              },
            );

          }
        }}
      /> */}

      <Loader visible={isLoader} />

    </SafeAreaView>
  );
};

import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
  Platform,
} from "react-native";
import ActionSheet from "react-native-actionsheet";
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";

export const accountDetail = (props) => {
  const [isLoader, setLoader] = useState(false)
  const [isEdit, setEdit] = useState(false);
  const [selectedImage, setSecectedImage] = useState(props.data.image_url != null && props.data.image_url != '' ? { uri: props.data.image_url } : null);
  const [title, setTitle] = useState(props.data.title);
  const [bankName, setBankName] = useState(props.data.bank_name);
  const [accountNumber, setAccountNumber] = useState(props.data.account_number);

  useEffect(() => {
    const event = Navigation.events().registerNavigationButtonPressedListener(({ buttonId }) => {
      if (buttonId == 'editAccount') {
        Navigation.mergeOptions(props.componentId, {
          topBar: {
            rightButtons: [
              {
                id: 'saveAccount',
                color: COLORS.appTheme,
                text: 'Save'
              },
            ],
          }
        })
        setEdit(!isEdit)
      }
      else if (buttonId == 'saveAccount') {
        updateAccountRequest()
      }

    })

    return () => {
      event.remove()
    }
  })

  gotoSignup = () => {
    Navigation.push(props.componentId, {
      component: {
        name: "com.itg.Signup",
      },
    });
  };

  const updateAccountRequest = () => {
    var photo = {
      uri: (selectedImage != null && selectedImage != '') ? selectedImage.uri : '',
      type: 'image/jpeg',
      name: 'photo.jpg',
    };
    ApiClient.fetchPostWithFormData('update_account',
      (selectedImage != null && selectedImage != '') ? {
        user_id: GlobalData.UserId,
        account_id: props.data.id,
        bank_name: bankName,
        title: title,
        account_number: accountNumber,
        image: photo
      } : {
          user_id: GlobalData.UserId,
          account_id: props.data.id,
          bank_name: bankName,
          title: title,
          account_number: accountNumber
        }, true, setLoader, (data) => {
          if (data.status + '' == 'true') {
            Navigation.mergeOptions(props.componentId, {
              topBar: {
                rightButtons: [
                  {
                    id: 'editAccount',
                    color: COLORS.appTheme,
                    text: 'Edit'
                  },
                ],
              }
            })
            setEdit(!isEdit)
            alert(data.message)
            props.getAccountsRequest()
            // Navigation.pop(props.componentId)
          }
          else {
            alert(data.message)
          }
        }, (error) => {
          alert(error)
        })
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}
        behavior='padding'
        enabled={Platform.OS == 'ios'} >
        <ScrollView style={{
          flex: 1
        }}>
          <View
            style={{
              flex: 1,
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              style={{
                height: 80,
                width: 80,
                // backgroundColor: "#999",
                marginTop: 30,
                justifyContent: 'center',
                alignItems: 'center'
              }}
              onPress={() => {
                if (isEdit) {
                  this.ActionSheet.show()
                }
              }}
              activeOpacity={isEdit ? 0.5 : 1.0} >
              <Image style={{
                height: 80,
                width: 80,
                // marginTop: 30,
                borderRadius: selectedImage != null ? 40 : 0,
                resizeMode: selectedImage != null ? 'cover' : 'contain'
              }}
                source={selectedImage != null ? selectedImage : require('../../assets/icons/photos.png')} />
              {isEdit && <View style={{
                height: 30,
                width: 30,
                backgroundColor: COLORS.appDarkGray,
                justifyContent: 'center',
                alignItems: 'center',
                borderRadius: 15,
                position: 'absolute',
                right: 0,
                bottom: 0
              }}>
                <Image style={{
                  height: 15,
                  width: 15,
                  tintColor: 'white'
                }}
                  source={require('../../assets/icons/pencil.png')} />
              </View>}
            </TouchableOpacity>

            <View
              style={{
                // height: 50,
                width: "90%",
                marginTop: 25
              }}
            >
              <Text
                style={{
                  flex: 1,
                  fontSize: 17,
                  color: '#999',
                }}
              >Title</Text>
              <TextInput
                style={{
                  flex: 1,
                  // textAlign: 'center',
                  marginTop: 5,
                  marginBottom: 2,
                  fontSize: 17,
                  color: 'white',
                  height: 30
                }}
                editable={isEdit}
                value={title}
                onChangeText={setTitle}
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
            </View>

            <View
              style={{
                // height: 50,
                width: "90%",
                marginTop: 20
              }}
            >
              <Text
                style={{
                  flex: 1,
                  fontSize: 17,
                  color: '#999',
                }}
              >Bank Name</Text>
              <TextInput
                style={{
                  flex: 1,
                  // textAlign: 'center',
                  marginTop: 5,
                  marginBottom: 2,
                  fontSize: 17,
                  color: 'white',
                  height: 30
                }}
                editable={isEdit}
                value={bankName}
                onChangeText={setBankName}
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
            </View>

            <View
              style={{
                // height: 50,
                width: "90%",
                marginTop: 20
              }}
            >
              <Text
                style={{
                  flex: 1,
                  fontSize: 17,
                  color: '#999',
                }}
              >Account Number</Text>
              <TextInput
                style={{
                  flex: 1,
                  // textAlign: 'center',
                  marginTop: 5,
                  marginBottom: 2,
                  fontSize: 17,
                  color: 'white',
                  height: 30
                }}
                editable={isEdit}
                value={accountNumber}
                onChangeText={setAccountNumber}
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
            </View>

            {/* <TouchableOpacity style={{
              height: 40,
              backgroundColor: '#A74834',
              width: '90%',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: 20,
              marginTop: 40
            }}>
              <Text style={{
                color: 'white',
                fontSize: 16,
                fontWeight: '500'
              }}>Submit</Text>
            </TouchableOpacity> */}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
        }}
      />

      <Loader visible={isLoader} />

    </SafeAreaView>
  );
};

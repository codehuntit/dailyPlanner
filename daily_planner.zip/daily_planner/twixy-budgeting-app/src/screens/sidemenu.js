import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { COLORS } from "../../config/colors";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";

export const sidemenu = (props) => {
  const [menu, setMenu] = useState([{
    id: 1,
    title: 'Dashboard',
    componentId: 'com.twixy.dashboard'
  }, {
    id: 2,
    title: 'Budget',
    componentId: 'com.twixy.budget'
  }, {
    id: 3,
    title: 'Accounts',
    componentId: 'com.twixy.accounts'
  }, {
    id: 4,
    title: 'Transactions',
    componentId: 'com.twixy.transactions'
  }, {
    id: 5,
    title: 'Categories',
    componentId: 'com.twixy.CategoriesList'
  }, {
    id: 6,
    title: 'Report',
    componentId: 'com.twixy.report'
  }, {
    id: 7,
    title: 'Connections',
    componentId: 'com.twixy.connections'
  }, {
    id: 8,
    title: 'Assets',
    componentId: 'com.twixy.assets'
  }, {
    id: 9,
    title: 'Profile',
    componentId: 'com.twixy.profile'
  }, {
    id: 10,
    title: 'Settings',
    componentId: 'com.twixy.settings'
  }, {
    id: 11,
    title: 'Support',
    componentId: 'com.twixy.supportscreen'
  }]);

  const gotoScreen = (item) => {
    if(item.componentId != null) {
      Navigation.push('STACK_ROOT_ID', {
        component: {
          name: item.componentId,
          options: {
            sideMenu: {
              left: {
                visible: false,
              },
            },
            topBar: {
              leftButtonColor: 'white',
              rightButtonColor: 'white',
              background: {
                color: COLORS.appDarkGray
              },
              title: {
                text: item.title,
                color: 'white'
              },
              leftButtons: {
                id: 'sideMenu',
                icon: Platform.OS == 'ios' ? {
                  scale: 10,
                  uri: 'menu'
                } : require('../../assets/icons/menu.png')
              },
              // rightButtons: item.id == 4 ? [{
              //   id: 'moreMenu',
              //   icon: Platform.OS == 'ios' ? {
              //     scale: 7,
              //     uri: 'more'
              //   } : require('../../assets/icons/more.png')
              // }] : [],
            }
          },
        },
      })
    }
    else {
      alert('In progress')
    }

  };

  const menuCell = ({ item, index }) => {
    return (
      <TouchableOpacity
        style={{
          height: 60,
          flexDirection: "row",
          alignItems: "center",
        }}
        onPress={() => {
          gotoScreen(item)
        }} >
        <View
          style={{
            height: 1,
            position: "absolute",
            bottom: 0,
            width: "100%",
            backgroundColor: COLORS.appGray,
          }}
        />
        {/* <Image
          style={{
            height: 30,
            width: 30,
            borderRadius: 15,
            marginLeft: 10,
            backgroundColor: "#999",
          }}
        /> */}
        <View>
          <Text
            style={{
              color: "white",
              fontSize: 18,
              fontWeight: "500",
              marginLeft: 15,
            }}
          >
            {item.title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appDarkGray,
      }}
    >
      <ScrollView
        style={{
          flex: 1
        }}
      >
        <View
          style={{
            alignItems: "center",
          }}
        >
          <Image
            style={{
              height: 100,
              width: 100,
              borderRadius: 50,
              backgroundColor: "#999",
              marginTop: 20,
            }}
          />
          <Text
            style={{
              fontSize: 17,
              fontWeight: "600",
              marginTop: 5,
              color: 'white'
            }}
          >
            Username
          </Text>
          <Text
            style={{
              fontSize: 17,
              fontWeight: "500",
              marginTop: 5,
              color: 'white'
            }}
          >
            username@gmail.com
          </Text>
        </View>

        <FlatList
          style={{
            marginTop: 30
          }}
          keyExtractor={(item, index) => item.id}
          data={menu}
          renderItem={menuCell}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

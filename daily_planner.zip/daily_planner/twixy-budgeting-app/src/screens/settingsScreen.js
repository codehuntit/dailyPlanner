/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
    Dimensions,
    FlatList,
    Image,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TouchableOpacity,
    useColorScheme,
    View,
} from 'react-native';
//  import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

export const settings = (props) => {

    const [tips, setTips] = useState([{
        id: '1',
        title: 'Dark mode',
        //  icon: require('../assets/icons/tips/morning.png')
    }, {
        id: '2',
        title: 'How often transactions should be synced',
        //  icon: require('../assets/icons/tips/afternoon.jpeg')
    }, {
        id: '3',
        title: 'Billing/subscriptions',
        //  icon: require('../assets/icons/tips/journal.jpeg')
    }])

    const TipCell = ({ item, index }) => {
        return <TouchableOpacity style={{
            height: 80,
            alignItems: 'center',
            flexDirection: 'row'
        }}>
            <Image style={{
                height: 60,
                width: 60,
                marginLeft: 10,
                backgroundColor: '#999',
                borderRadius: 30,
                borderWidth: 2,
                borderColor: '#1E2F3C'
            }}
                source={item.icon} />
            <Text style={{
                fontSize: 15,
                fontWeight: '500',
                marginHorizontal: 10,
                color: 'white'
            }}>{item.title}</Text>
            <View style={{
                height: 1,
                backgroundColor: '#bbb',
                position: 'absolute',
                width: '100%',
                bottom: 0
            }} />
        </TouchableOpacity>
    }

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: '#1E2F3C'
        }}>
            {/* <StatusBar barStyle={'dark-content'} /> */}
            {/* <View style = {{
                height: 44,
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                <Text style = {{
                    color: 'white',
                    fontSize: 17,
                    fontWeight: '500'
                }}>Settings</Text>
            </View> */}
            <View
                style={{
                    flex: 1,
                    //    backgroundColor: 'white'
                }}>
                <FlatList
                    data={tips}
                    renderItem={TipCell} />
            </View>
        </SafeAreaView>
    );
};

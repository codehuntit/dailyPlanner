import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
  Platform,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import ActionSheet from "react-native-actionsheet";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from "moment";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { ApiClient } from "../../config/ApiClient";
import { Loader } from "../components/Loader";

const TransactionType = {
  debit: 'debit',
  credit: 'credit'
};


export const addbudget = (props) => {
  const [isLoader, setLoader] = useState(false)

  const [selectedImage, setSecectedImage] = useState(null);
  const [selectedCategory, setCategory] = useState(null);
  const [selectedExpDate, setExpDate] = useState(null);
  const [selectedType, setType] = useState(TransactionType.debit);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const [budgetName, setBudgetName] = useState('')
  const [budgetAmount, setBudgetAmount] = useState('')

  const [nameError, setNameError] = useState('')
  const [categoryError, setCategoryError] = useState('')
  const [amountError, setAmountError] = useState('')
  const [expError, setExpError] = useState('')

  const clearAllMessages = () => {
    setNameError('')
    setCategoryError('')
    setAmountError('')
    setExpError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (budgetName == '') {
      setNameError('Please enter budget name.')
    }
    if (selectedCategory == null) {
      setCategoryError('Please choose budget category.')
    }
    if (budgetAmount == '') {
      setAmountError('Please enter budget amount.')
    }
    if (selectedExpDate == null) {
      setExpError('Please choose budget expire date.')
    }

    if (budgetName != '' && selectedCategory != null && budgetAmount != '' && selectedExpDate != null) {
      addBudgetRequest()
    }
  }

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    setExpDate(date)
    hideDatePicker();
  };

  const selectCategory = (category, index) => {
    setCategory(category)
  }

  const addBudgetRequest = () => {
    var photo = {
      uri: (selectedImage != null && selectedImage != '') ? selectedImage.uri : '',
      type: 'image/jpeg',
      name: 'photo.jpg',
    };
    console.log({
      user_id: GlobalData.UserId,
      category_id: selectedCategory.id + '',
      title: budgetName,
      amount: budgetAmount,
      expire_date: moment(selectedExpDate).format('DD-MM-YYYY'),
      type: selectedType,
    })
    ApiClient.fetchPostWithFormData('addBudget',
      (selectedImage != null && selectedImage != '') ? {
        user_id: GlobalData.UserId,
        category_id: selectedCategory.id + '',
        title: budgetName,
        amount: budgetAmount,
        expire_date: moment(selectedExpDate).format('DD-MM-YYYY'),
        type: selectedType,
        image: photo
      } : {
          user_id: GlobalData.UserId,
          category_id: selectedCategory.id,
          title: budgetName,
          amount: budgetAmount,
          expire_date: moment(selectedExpDate).format('DD-MM-YYYY'),
          type: selectedType,
        }, true, setLoader, (data) => {
          if (data.status + '' == 'true') {
            alert(data.message)
            // props.getAccountsRequest()
            Navigation.pop(props.componentId)
          }
          else {
            alert(data.message)
          }
        }, (error) => {
          alert(error)
        })
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray,
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}
        behavior='padding'
        enabled={Platform.OS == 'ios'} >
        <ScrollView style={{
          flex: 1
        }}>
          <View
            style={{
              // flex: 1,
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              style={{
                height: 80,
                width: 80,
                // backgroundColor: "#999",
                marginTop: 30,
                justifyContent: 'center',
                alignItems: 'center'
              }}
              onPress={() => {
                this.ActionSheet.show()
              }} >
              <Image style={{
                height: 80,
                width: 80,
                borderRadius: selectedImage != null ? 40 : 0,
                resizeMode: selectedImage != null ? 'cover' : 'contain'
              }}
                source={selectedImage != null ? selectedImage : require('../../assets/icons/photos.png')} />
            </TouchableOpacity>

            <View
              style={{
                // height: 50,
                width: "80%",
              }}
            >
              <TextInput
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                value={budgetName}
                onChangeText={setBudgetName}
                placeholderTextColor='#999'
                placeholder="Budget Title"
              />

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {nameError != null && nameError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {nameError}</Text>}
            </View>

            <TouchableOpacity
              style={{
                // height: 50,
                width: "80%",
              }}
              onPress={() => {
                Navigation.showModal({
                  component: {
                    name: 'com.twixy.chooseCategories',
                    passProps: {
                      selectCategory: selectCategory
                    }
                  }
                })
              }} >
              <Text
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white'
                }}
              >{selectedCategory != null ? selectedCategory.title : 'Choose Category'}</Text>

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />

              {categoryError != null && categoryError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {categoryError}</Text>}

            </TouchableOpacity>

            <View
              style={{
                // height: 50,
                width: "80%",
              }}
            >
              <TextInput
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white',
                  padding: 0
                }}
                value={budgetAmount}
                onChangeText={setBudgetAmount}
                keyboardType='decimal-pad'
                placeholderTextColor='#999'
                placeholder="Amount"
              />
              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {amountError != null && amountError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {amountError}</Text>}
            </View>

            <TouchableOpacity
              style={{
                // height: 50,
                width: "80%",
              }}
              onPress={showDatePicker}
            >
              <Text
                style={{
                  height: 40,
                  width: '100%',
                  textAlign: 'center',
                  marginTop: 20,
                  fontSize: 17,
                  color: 'white'
                }}
              >{selectedExpDate != null ? moment(selectedExpDate).format('DD-MM-YYYY') : 'Choose Expire Date'}</Text>

              <View style={{
                height: 1,
                backgroundColor: '#ffffff33'
              }} />
              {expError != null && expError != '' &&
                <Text style={{
                  color: 'white',
                  marginTop: 5,
                  // marginBottom: 5
                }}>* {expError}</Text>}
            </TouchableOpacity>

            <View
              style={{
                height: 50,
                width: "80%",
                flexDirection: 'row',
                marginTop: 20
              }}
            >
              <TouchableOpacity style={{
                flex: 1,
                // justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
              }}
                onPress={() => {
                  setType(TransactionType.debit)
                }} >
                <Image style={{
                  height: 20,
                  width: 20,
                  borderRadius: 20,
                  tintColor: 'white'
                }}
                  source={selectedType == TransactionType.debit ? require('../../assets/icons/radio-on.png') : require('../../assets/icons/radio-off.png')} />
                <Text style={{
                  fontSize: 16,
                  fontWeight: '600',
                  color: 'white',
                  marginLeft: 15
                }}>Debit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                flex: 1,
                // justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
              }}
                onPress={() => {
                  setType(TransactionType.credit)
                }} >
                <Image style={{
                  height: 20,
                  width: 20,
                  borderRadius: 20,
                  tintColor: 'white'
                }}
                  source={selectedType == TransactionType.credit ? require('../../assets/icons/radio-on.png') : require('../../assets/icons/radio-off.png')} />
                <Text style={{
                  fontSize: 16,
                  fontWeight: '600',
                  color: 'white',
                  marginLeft: 15
                }}>Credit</Text>
              </TouchableOpacity>
            </View>


            <TouchableOpacity style={{
              height: 40,
              backgroundColor: '#A74834',
              width: '80%',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: 20,
              marginTop: 40
            }}
              onPress={validateData} >
              <Text style={{
                color: 'white',
                fontSize: 16,
                fontWeight: '500'
              }}>Submit</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
        }}
      />

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        minimumDate={new Date()}
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />

      <Loader visible={isLoader} />

    </SafeAreaView>
  );
};

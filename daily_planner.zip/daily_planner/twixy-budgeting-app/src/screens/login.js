/**
 * twixy-budgeting-app
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useState } from 'react';
import {
    Dimensions,
    Image,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    ScrollView,
    StatusBar,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { ApiClient } from '../../config/ApiClient';
import { COLORS } from '../../config/colors';
import { Constants } from '../../config/Constants';
import { GlobalData } from '../../config/GlobalData';
import { validateEmail } from '../../config/validator';
import { AppButton } from '../components/AppButton';
import { AppTextInput } from '../components/AppTextInput';
import { Loader } from '../components/Loader';


export const login = (props) => {

    const [isLoader, setLoader] = useState(false)

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const [emailError, setEmailError] = useState('')
    const [passwordError, setPasswordError] = useState('')

    const clearAllMessages = () => {
        setEmailError('')
        setPasswordError('')
    }
    const validateData = () => {
        clearAllMessages()
        if (email == '') {
            setEmailError('Please enter email.')
        }
        else if (!validateEmail(email)) {
            setEmailError('Please enter valid email.')
        }
        if (password == '') {
            setPasswordError('Please enter password.')
        }

        if (email != '' && validateEmail(email) && password != '') {
            loginRequest()
        }
    }

    const loginRequest = () => {
        ApiClient.fetchPostWithFormData('login', {email: email, password: password}, true, setLoader, (data) => {
            if(data.status + '' == 'true' && data.details != null && data.details.id != null) {
                AsyncStorage.setItem(Constants.USER_ID_KEY, data.details.id + '')
                GlobalData.UserId = data.details.id + ''
                setEmail('')
                setPassword('')
                onLoginPressed()
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const onLoginPressed = () => {
        Navigation.setRoot({
            root: {
                sideMenu: {
                    center: {
                        stack: {
                            id: 'STACK_ROOT_ID',
                            children: [
                                {
                                    component: {
                                        name: 'com.twixy.dashboard',
                                        options: {
                                            topBar: {
                                                leftButtonColor: 'white',
                                                background: {
                                                    color: COLORS.appDarkGray
                                                },
                                                title: {
                                                    text: 'Dashboard',
                                                    color: 'white'
                                                },
                                                leftButtons: {
                                                    id: 'sideMenu',
                                                    icon: Platform.OS == 'ios' ? {
                                                        scale: 10,
                                                        uri: 'menu'
                                                    } : require('../../assets/icons/menu.png')
                                                }
                                            }
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    left: {
                        component: {
                            name: 'com.twixy.sidemenu',
                        }
                    },
                    options: {
                        sideMenu: {
                            left: {
                                width: Dimensions.get('screen').width / 1.3
                            }
                        }
                    }
                }
            }
        })


        // Navigation.push(props.componentId, {
        //     component: {
        //         name: 'com.twixy.dashboard',
        //         options: {
        //             topBar: {
        //                 title: {
        //                     text: 'Dashboard'
        //                 }
        //             }
        //         }
        //     }
        // })
    }

    const gotoForgotPassword = () => {
        Navigation.push(props.componentId, {
            component: {
                name: 'com.twixy.forgotPassword',
                options: {
                    topBar: {
                        title: {
                            text: 'Forgot password'
                        }
                    }
                }
            }
        })
    }

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: COLORS.appGray
        }}>
            <StatusBar barStyle='light-content' />
            <KeyboardAvoidingView
                style={{
                    flex: 1
                }}
                behavior='padding'
                enabled={Platform.OS == 'ios'}
                keyboardVerticalOffset={40} >
                <ScrollView style={{
                    flex: 1
                }}>
                    <View style={{
                        flex: 1,
                        alignItems: 'center'
                    }}>
                        <Image style={{
                            height: 100,
                            width: '60%',
                            marginTop: 30,
                            resizeMode: 'contain'
                        }}
                            source={require('../../assets/icons/twixy-icon.png')} />

                        <AppTextInput style={{
                            marginTop: 30,
                            width: '90%'
                        }}
                            errorMessage={emailError}
                            onChangeText={setEmail}
                            value={email}
                            placeholder='Email'
                            keyboardType='email-address' />
                        <AppTextInput style={{
                            marginTop: 20,
                            width: '90%',
                        }}
                            errorMessage={passwordError}
                            onChangeText={setPassword}
                            value={password}
                            placeholder='Password'
                            secureTextEntry />

                        <View style={{
                            height: 60,
                            width: '90%',
                            justifyContent: 'center',
                            alignItems: 'flex-end'
                        }}>
                            <TouchableOpacity onPress={gotoForgotPassword}>
                                <Text style={{
                                    color: COLORS.appTheme,
                                    fontSize: 16,
                                    fontWeight: '500',
                                    margin: 10
                                }}>Forgot password?</Text>
                            </TouchableOpacity>
                        </View>

                        <AppButton style={{
                            width: '90%'
                        }}
                            title='Log in'
                            onPress={validateData} />

                        <View style={{
                            marginTop: 20,
                            width: '90%',
                            height: 40,
                            alignItems: 'center'
                        }}>
                            <Text style={{
                                color: 'white',
                                fontSize: 16,
                            }}>Don't have an account? {<Text style={{
                                color: COLORS.appTheme,
                                fontWeight: '500'
                            }} onPress={() => {
                                Navigation.pop(props.componentId)
                            }}>Register</Text>}</Text>
                        </View>

                    </View>
                </ScrollView>
            </KeyboardAvoidingView>

            <Loader visible={isLoader} />
        </SafeAreaView>
    );
};
import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";
import ActionSheet from "react-native-actionsheet";
import { launchCamera, launchImageLibrary } from "react-native-image-picker";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { AppButton } from "../components/AppButton";
import { AppTextInput } from "../components/AppTextInput";
import { Loader } from "../components/Loader";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";

export const editprofile = (props) => {

  const [isLoader, setLoader] = useState(false)

  const [username, setUsername] = useState(props.userData != null ? props.userData.username : '')
  const [userImage, setUserImage] = useState(props.userData != null ? {uri: props.userData.userImage} : '')

  const [usernameError, setUsernameError] = useState('')

  const clearAllMessages = () => {
    setUsernameError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (username == '') {
      setUsernameError('Please enter username.')
    }

    if (username != '') {
      updateProfileRequest()
    }
  }

  const updateProfileRequest = () => {
    var photo = {
      uri: userImage.uri,
      type: 'image/jpeg',
      name: 'photo.jpg',
    };
    ApiClient.fetchPostWithFormData('update_profile',
      (userImage != null && userImage != '') ? {
        user_id: GlobalData.UserId,
        fullname: username,
        image: photo
      } : {
          user_id: GlobalData.UserId,
          fullname: username
        }, true, setLoader, (data) => {
          if (data.status + '' == 'true') {
            alert(data.message)
            Navigation.pop(props.componentId)
            props.getProfileRequest()
          }
          else {
            alert(data.message)
          }
        }, (error) => {
          alert(error)
        })
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray,
      }}
    >
      <KeyboardAvoidingView style={{
        flex: 1
      }}>
        <ScrollView
          style={{
            flex: 1
          }}
        >
          <View
            style={{
              alignItems: "center",
            }}
          >
            <TouchableOpacity style={{
              height: 100,
              width: 100,
              borderRadius: 50,
              backgroundColor: "#999",
              marginTop: 20,
            }}
            onPress = {() => {
              this.ActionSheet.show()
            }} >
              <Image
                style={{
                  height: 100,
                  width: 100,
                  borderRadius: 50
                }}
                source={(userImage != null && userImage != '') ? userImage : require('../../assets/icons/avatar.png')} />
            </TouchableOpacity>
            <AppTextInput style={{
              marginTop: 30,
              width: '90%',
            }}
              errorMessage={usernameError}
              onChangeText={setUsername}
              value={username}
              placeholder='Username' />
            {/* <AppTextInput style={{
              marginTop: 20,
              width: '90%',
            }}
              placeholder='Email'
              keyboardType='email-address' /> */}

            <AppButton style={{
              marginTop: 30,
              width: '90%'
            }}
              title='Save'
              onPress={validateData}
            />

          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setUserImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setUserImage(response)
            });
          }
        }}
      />

      <Loader visible={isLoader} />
      
    </SafeAreaView>
  );
};

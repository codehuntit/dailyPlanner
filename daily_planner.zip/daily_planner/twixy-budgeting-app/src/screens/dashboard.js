import React, { useState, useEffect } from "react";
import {
    Text,
    View,
    SafeAreaView,
    StatusBar,
    Dimensions,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Image,
    ScrollView,
    KeyboardAvoidingView,
    FlatList,
    RefreshControl,
    Alert,
} from "react-native";
import ActionSheet from "react-native-actionsheet";
import { FloatingAction } from "react-native-floating-action";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";
import { NoDataView } from "../components/NoDataView";
import { APP_BLUE, APP_LIGHT_BLUE, APP_DARK_GRAY } from "../config/colors";

const actions = [
    {
        text: "Add Account",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/coin.png"),
        name: "bt_addaccount",
        position: 1
    }
];

const wait = (timeout) => {
    return new Promise(resolve => setTimeout(resolve, timeout));
}

export const dashboard = (props) => {

    const [isLoader, setLoader] = useState(false)

    const [accounts, setAccounts] = useState([
        //     {
        //     id: 1,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 2,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 3,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 4,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 5,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 6,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 7,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 8,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 9,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 10,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 11,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }, {
        //     id: 12,
        //     title: 'Demo account',
        //     cardNo: 'xxxx xxxx xxxx 1234'
        // }
    ]);
    const [refreshing, setRefreshing] = React.useState(false);
    const [selectedIndex, setIndex] = useState(-1)

    const onRefresh = React.useCallback(() => {
        setRefreshing(true);
        wait(2000).then(() => setRefreshing(false));
    }, []);

    useEffect(() => {
        Navigation.events().registerNavigationButtonPressedListener(navigationButtonPressed)
        getAccountsRequest()
    }, [])

    const getAccountsRequest = () => {
        ApiClient.fetchPostWithFormData('fetch_account_by_user_id', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true' && data.details != null) {
                setAccounts(data.details)
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const removeAccountRequest = () => {
        ApiClient.fetchPostWithFormData('remove_account', { account_id: accounts[selectedIndex].id }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true') {
                var _items = [...accounts]
                _items.splice(selectedIndex, 1)
                setAccounts(_items)
                setIndex(-1)
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    const navigationButtonPressed = ({ buttonId }) => {
        if (buttonId == 'sideMenu') {
            Navigation.mergeOptions(props.componentId, {
                sideMenu: {
                    left: {
                        visible: true
                    }
                }
            });
        }
    }

    const gotoAccountDetail = (item, index) => {
        Navigation.push(props.componentId, {
            component: {
                name: 'com.twixy.accountDetail',
                passProps: {
                    data: item,
                    getAccountsRequest: getAccountsRequest
                },
                options: {
                    sideMenu: {
                        left: {
                            visible: false,
                        },
                    },
                    topBar: {
                        backButton: {
                            color: COLORS.appTheme
                        },
                        background: {
                            color: COLORS.appDarkGray
                        },
                        title: {
                            text: 'Account Detail',
                            color: 'white'
                        },
                        rightButtons: [{
                            id: 'editAccount',
                            text: 'Edit',
                            color: COLORS.appTheme
                        }]
                    }
                },
            }
        })
    }

    const accountCell = ({ item, index }) => {
        return (
            <TouchableOpacity
                style={{
                    height: 80,
                    flexDirection: "row",
                    alignItems: "center",
                }}
                onLongPress={() => {
                    setIndex(index)
                    this.ActionSheet.show()
                }}
                onPress={() => { gotoAccountDetail(item, index) }} >
                <View
                    style={{
                        height: 1,
                        position: "absolute",
                        bottom: 0,
                        width: "100%",
                        backgroundColor: '#ccc',
                    }}
                />
                <View style={{
                    height: 50,
                    width: 50,
                    borderRadius: 25,
                    marginLeft: 10,
                    overflow: item.image_url != null ? 'hidden' : 'visible'
                    // backgroundColor: "#999",
                }}>
                    <Image
                        style={{
                            height: 50,
                            width: 50,
                            // backgroundColor: "#999",
                        }}
                        source={item.image_url != null ? { uri: item.image_url } : require('../../assets/icons/photos.png')}
                    />
                </View>
                <View style={{
                    flex: 1
                }}>
                    <Text
                        style={{
                            color: "#111",
                            fontSize: 16,
                            fontWeight: "500",
                            marginLeft: 10,
                        }}
                    >{item.title}</Text>
                    <Text
                        style={{
                            color: "#111",
                            fontSize: 15,
                            marginLeft: 10,
                        }}
                    >{item.bank_name}</Text>
                    <Text
                        style={{
                            color: "#222",
                            fontSize: 15,
                            marginLeft: 10,
                        }}
                    >{item.account_number}</Text>
                </View>
                <Image
                    style={{
                        height: 20,
                        width: 20,
                        resizeMode: 'contain',
                        marginRight: 10,
                        tintColor: '#ccc'
                    }}
                    source={require('../../assets/icons/right-arrow-angle.png')} />
            </TouchableOpacity>
        );
    };

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: COLORS.appGray,
            }}
        >
            <StatusBar barStyle='light-content' />
            {accounts.length > 0 ? <View
                style={{
                    flex: 1,
                    // alignItems: 'center'
                }}
            >
                <View
                    style={{
                        position: "absolute",
                        height: 150,
                        width: "100%",
                        justifyContent: "center",
                    }}
                >
                    <Text
                        style={{
                            fontSize: 30,
                            fontWeight: "700",
                            color: "white",
                            textAlign: "center",
                            marginTop: -20,
                        }}
                    >$120.50</Text>
                    <Text
                        style={{
                            fontSize: 14,
                            color: "#ddd",
                            textAlign: "center",
                        }}
                    >
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry.
          </Text>
                </View>
                <ScrollView style={{
                    flex: 1
                }}
                    bounces={false}
                    contentContainerStyle={{
                        flex: 1
                    }}
                    showsVerticalScrollIndicator={false}
                // refreshControl={
                //     <RefreshControl
                //         style={{
                //         }}
                //         // tintColor = 'white'
                //         refreshing={refreshing}
                //         onRefresh={onRefresh}
                //     /> }
                >
                    <FlatList
                        bounces={false}
                        style={{
                            backgroundColor: "white",
                            marginTop: 150,
                            borderTopLeftRadius: 20,
                            borderTopRightRadius: 20,
                            flex: 1
                        }}
                        // ListFooterComponent={() => {
                        //     return <View style={{
                        //         backgroundColor: 'white',
                        //         flex: 1
                        //     }} />
                        // }}
                        // ListFooterComponentStyle={{
                        //     flex: 1,
                        //     backgroundColor: 'white'
                        // }}
                        keyExtractor={(item, index) => item.id}
                        data={accounts}
                        renderItem={accountCell}
                    />
                </ScrollView>
            </View>
                :
                <NoDataView isRetry={true}
                    onRetry={() => {
                        getAccountsRequest()
                        // setLoader(true)
                        // getCompaniesApi()
                    }} />}
            <FloatingAction
                color={COLORS.appTheme}
                actions={actions}
                onPressItem={name => {
                    if (name == 'bt_addaccount') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addaccount',
                                passProps: {
                                    getAccountsRequest: getAccountsRequest
                                },
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Account'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                    // else if (name == 'bt_addbudget') {
                    //     Navigation.push(props.componentId, {
                    //         component: {
                    //             name: 'com.twixy.addbudget',
                    //             options: {
                    //                 topBar: {
                    //                     background: {
                    //                         color: COLORS.appDarkGray
                    //                     },
                    //                     title: {
                    //                         color: 'white',
                    //                         fontSize: 20,
                    //                         text: 'Add Budget'
                    //                     },
                    //                     backButton: {
                    //                         color: 'white'
                    //                     }
                    //                 }
                    //             }
                    //         }
                    //     })
                    // }
                }}
            />

            <ActionSheet
                ref={o => this.ActionSheet = o}
                // title={''}
                options={['Delete', 'Cancel']}
                cancelButtonIndex={1}
                destructiveButtonIndex={0}
                onPress={(index) => {
                    if (index == 0) {
                        if (selectedIndex != -1 && selectedIndex < accounts.length) {
                            Alert.alert(
                                ('Delete Account'),
                                ('Are you sure you want to delete this account?'),
                                [
                                    {
                                        text: ('Delete'),
                                        style: 'destructive',
                                        onPress: async () => {
                                            removeAccountRequest()
                                        },
                                    },
                                    { text: ('Cancel'), style: 'cancel' },
                                ],
                                {
                                    cancelable: false,
                                },
                            );

                        }
                    }
                }}
            />

            <Loader visible={isLoader} />

        </SafeAreaView>
    );
};


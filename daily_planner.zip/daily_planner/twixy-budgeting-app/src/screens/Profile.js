import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
  Alert,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { ApiClient } from "../../config/ApiClient";
import { COLORS } from "../../config/colors";
import { Constants } from "../../config/Constants";
import { GlobalData } from "../../config/GlobalData";
import { Loader } from "../components/Loader";

export const profile = (props) => {

  const [isLoader, setLoader] = useState(false)

  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [userImage, setUserImage] = useState(null)

  useEffect(() => {
    getProfileRequest()
  }, [])

  const getProfileRequest = () => {
    ApiClient.fetchPostWithFormData('fetchById', { user_id: GlobalData.UserId }, true, setLoader, (data) => {
      console.log(data)
      if (data.status + '' == 'true' && data.details != null) {
        setUsername(data.details.fullname)
        setEmail(data.details.email)
        setUserImage(data.details.image_url)
      }
      else {
        alert(data.message)
      }
    }, (error) => {
      alert(error)
    })
  }

  const logoutUser = () => {
    AsyncStorage.setItem(Constants.USER_ID_KEY, '')
    Navigation.setRoot({
      root: {
        stack: {
          children: [
            {
              component: {
                name: 'com.twixy.signup',
                options: {
                  topBar: {
                    title: {
                      text: 'Sign up'
                    }
                  },
                  // statusBar: {
                  //     backgroundColor: 'green'
                  // }
                }
              }
            }
          ],
          options: {
            topBar: {
              background: {
                color: COLORS.appDarkGray
              },
              title: {
                color: 'white',
                fontSize: 20
              },
              backButton: {
                color: COLORS.appTheme
              }
            }
          }
        }
      }
    })
  }

  const profileCell = ({ item, index }) => {
    return (
      <TouchableOpacity
        style={{
          height: 60,
          flexDirection: "row",
          alignItems: "center",
        }}
        onPress={() => {
          if (index == 0) {
            Navigation.push(props.componentId, {
              component: {
                name: 'com.twixy.editprofile',
                passProps: {
                  userData: {
                    username: username,
                    userImage: userImage
                  },
                  getProfileRequest: getProfileRequest
                },
                options: {
                  topBar: {
                    background: {
                      color: COLORS.appDarkGray
                    },
                    title: {
                      color: 'white',
                      text: 'Edit Profile'
                    },
                    backButton: {
                      color: COLORS.appTheme
                    }
                  }
                }
              }
            })
          }
          else if (index == 1) {
            Navigation.push(props.componentId, {
              component: {
                name: 'com.twixy.changePassword',
                options: {
                  topBar: {
                    background: {
                      color: COLORS.appDarkGray
                    },
                    title: {
                      color: 'white',
                      text: 'Change Password'
                    },
                    backButton: {
                      color: COLORS.appTheme
                    }
                  }
                }
              }
            })
          }
          else if (index == 2) {
            Navigation.push(props.componentId, {
              component: {
                name: 'com.twixy.about',
                options: {
                  topBar: {
                    background: {
                      color: COLORS.appDarkGray
                    },
                    title: {
                      color: 'white',
                      text: 'About'
                    },
                    backButton: {
                      color: COLORS.appTheme
                    }
                  }
                }
              }
            })
          }
          else if (index == 3) {
            Alert.alert(
              ('Logout'),
              ('Are you sure you want to logout?'),
              [
                {
                  text: ('Logout'),
                  onPress: async () => {
                    // AsyncStorage.setItem(USER_ID_KEY, '')
                    logoutUser()
                  },
                },
                { text: ('Cancel'), style: 'cancel' },
              ],
              {
                cancelable: false,
              },
            );
          }
        }} >
        <View
          style={{
            height: 1,
            position: "absolute",
            bottom: 0,
            width: "100%",
            backgroundColor: "#888",
          }}
        />
        <View style={{
          height: 30,
          width: 30,
          borderRadius: 15,
          marginLeft: 10,
          backgroundColor: 'white',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <Image
            style={{
              height: 17,
              width: 17,
              tintColor: COLORS.appDarkGray
            }}
            source={item.icon} />
        </View>
        <View>
          <Text
            style={{
              color: "white",
              fontSize: 17,
              fontWeight: "500",
              marginLeft: 10,
            }}
          >
            {item.title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray,
      }}
    >
      <ScrollView
        style={{
          flex: 1,
          // backgroundColor: "white",
        }}
      >
        <View
          style={{
            alignItems: "center",
          }}
        >
          <Image
            style={{
              height: 100,
              width: 100,
              borderRadius: 50,
              backgroundColor: "#999",
              marginTop: 20,
            }}
            source={(userImage != null && userImage != '') ? { uri: userImage } : require('../../assets/icons/avatar.png')} />
          <Text
            style={{
              fontSize: 17,
              fontWeight: "600",
              marginTop: 5,
              color: 'white'
            }}
          >
            {username}
          </Text>
          <Text
            style={{
              fontSize: 17,
              fontWeight: "500",
              marginTop: 5,
              color: 'white'
            }}
          >
            {email}
          </Text>
        </View>

        <FlatList
          style={{
            // backgroundColor: "white",
            marginTop: 30,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
          keyExtractor={(item, index) => index}
          data={[{ title: "Edit Profile", icon: require('../../assets/icons/pencil.png') },
          { title: "Change Password", icon: require('../../assets/icons/padlock.png') },
          { title: "About", icon: require('../../assets/icons/info.png') },
          { title: "Logout", icon: require('../../assets/icons/logout.png') }]}
          renderItem={profileCell}
        />
      </ScrollView>

      <Loader visible={isLoader} />

    </SafeAreaView>
  );
};

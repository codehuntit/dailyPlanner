/**
 * twixy-budgeting-app
 */

import React, { useState } from 'react';
import {
    Image,
    KeyboardAvoidingView,
    SafeAreaView,
    ScrollView,
    StatusBar,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { ApiClient } from '../../config/ApiClient';
import { COLORS } from '../../config/colors';
import { validateEmail } from '../../config/validator';
import { AppButton } from '../components/AppButton';
import { AppTextInput } from '../components/AppTextInput';
import { Loader } from '../components/Loader';


export const forgotPassword = (props) => {

    const [isLoader, setLoader] = useState(false)

    const [email, setEmail] = useState('')

    const [emailError, setEmailError] = useState('')

    const clearAllMessages = () => {
        setEmailError('')
    }
    const validateData = () => {
        clearAllMessages()

        if (email == '') {
            setEmailError('Please enter email.')
        }
        else if (!validateEmail(email)) {
            setEmailError('Please enter valid email.')
        }

        if (email != '' && validateEmail(email)) {
            forgotPasswordRequest()
        }
    }

    onSubmitPressed = () => {
        validateData()
    }

    const forgotPasswordRequest = () => {
        ApiClient.fetchPostWithFormData('forgetpassword', { email: email }, true, setLoader, (data) => {
            console.log(data)
            if (data.status + '' == 'true') {
                setEmail('')
                alert(data.message)
            }
            else {
                alert(data.message)
            }
        }, (error) => {
            alert(error)
        })
    }

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: COLORS.appGray
        }}>
            <StatusBar barStyle='light-content' />
            <KeyboardAvoidingView
                style={{
                    flex: 1
                }}
                behavior='padding'
                enabled={Platform.OS == 'ios'}
                keyboardVerticalOffset={40} >
                <ScrollView style={{
                    flex: 1
                }}>
                    <View style={{
                        flex: 1,
                        alignItems: 'center'
                    }}>
                        <Image style={{
                            height: 100,
                            width: '60%',
                            marginTop: 30,
                            resizeMode: 'contain'
                        }}
                            source={require('../../assets/icons/twixy-icon.png')} />

                        <AppTextInput style={{
                            marginTop: 30,
                            width: '90%',
                        }}
                            errorMessage={emailError}
                            onChangeText={setEmail}
                            value={email}
                            placeholder='Email'
                            keyboardType='email-address' />

                        <AppButton style={{
                            marginTop: 30,
                            width: '90%'
                        }}
                            title='Submit'
                            onPress={onSubmitPressed} />

                        {/* <View style={{
                            marginTop: 20,
                            width: '90%',
                            height: 40,
                            alignItems: 'center'
                        }}>
                            <Text style={{
                                color: 'white',
                                fontSize: 16,
                            }}>Don't have an account? {<Text style={{
                                color: COLORS.appTheme,
                                fontWeight: '500'
                            }} onPress={() => {
                                Navigation.pop(props.componentId)
                            }}>Register</Text>}</Text>
                        </View> */}

                    </View>
                </ScrollView>
            </KeyboardAvoidingView>

            <Loader visible={isLoader} />
        </SafeAreaView>
    );
};
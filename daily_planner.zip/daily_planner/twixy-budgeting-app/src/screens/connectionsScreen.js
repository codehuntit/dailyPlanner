/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useState } from 'react';
import {
    Dimensions,
    FlatList,
    Image,
    KeyboardAvoidingView,
    Platform,
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TouchableOpacity,
    useColorScheme,
    View,
} from 'react-native';
import { FloatingAction } from 'react-native-floating-action';
import { Navigation } from 'react-native-navigation';
import { COLORS } from '../../config/colors';
//  import { COLORS } from '../config/colors';
const CELL_WIDTH = Dimensions.get('screen').width / 3

const connectionActions = [
    {
        text: "Add Connection",
        color: COLORS.appTheme,
        icon: require("../../assets/icons/coin.png"),
        name: "bt_addconnection",
        position: 1
    }
];

export const connections = (props) => {

    const [tips, setTips] = useState([{
        id: '1',
        title: 'Connection 1',
        //  icon: require('../assets/icons/tips/morning.png')
    }, {
        id: '2',
        title: 'Connection 2',
        //  icon: require('../assets/icons/tips/afternoon.jpeg')
    }, {
        id: '3',
        title: 'Connection 3',
        //  icon: require('../assets/icons/tips/journal.jpeg')
    }, {
        id: '4',
        title: 'Connection 4',
        //  icon: require('../assets/icons/tips/sleep-diary.jpeg')
    }, {
        id: '5',
        title: 'Connection 5',
        //  icon: require('../assets/icons/tips/sleeping.jpeg')
    }])

    const TipCell = ({ item, index }) => {
        return <TouchableOpacity style={{
            height: 80,
            alignItems: 'center',
            flexDirection: 'row'
        }}>
            <View style={{
                height: 50,
                width: 50,
                borderRadius: 25,
                marginLeft: 10,
                overflow: item.image_url != null ? 'hidden' : 'visible'
                // backgroundColor: "#999",
            }}>
                <Image
                    style={{
                        height: 50,
                        width: 50,
                        // backgroundColor: "#999",
                    }}
                    source={item.image_url != null && item.image_url.includes('http') ? { uri: item.image_url } : require('../../assets/icons/photos.png')}
                />
            </View>
            <Text style={{
                fontSize: 17,
                fontWeight: '500',
                marginHorizontal: 10,
                color: 'white'
            }}>{item.title}</Text>
            <View style={{
                height: 1,
                backgroundColor: '#bbb',
                position: 'absolute',
                width: '100%',
                bottom: 0
            }} />
        </TouchableOpacity>
    }

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: '#1E2F3C'
        }}>
            {/* <StatusBar barStyle={'dark-content'} /> */}
            {/* <View style = {{
                height: 44,
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                <Text style = {{
                    color: 'white',
                    fontSize: 17,
                    fontWeight: '500'
                }}>Connections</Text>
            </View> */}
            <View
                style={{
                    flex: 1,
                    //    backgroundColor: 'white'
                }}>
                <FlatList
                    data={tips}
                    renderItem={TipCell} />
            </View>

            <FloatingAction
                color={COLORS.appTheme}
                actions={connectionActions}
                onPressItem={name => {
                    if (name == 'bt_addconnection') {
                        Navigation.push(props.componentId, {
                            component: {
                                name: 'com.twixy.addconnection',
                                options: {
                                    topBar: {
                                        background: {
                                            color: COLORS.appDarkGray
                                        },
                                        title: {
                                            color: 'white',
                                            fontSize: 20,
                                            text: 'Add Connection'
                                        },
                                        backButton: {
                                            color: 'white'
                                        }
                                    }
                                }
                            }
                        })
                    }
                }}
            />

        </SafeAreaView>
    );
};

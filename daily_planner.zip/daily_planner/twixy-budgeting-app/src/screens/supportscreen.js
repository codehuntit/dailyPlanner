import React, { useState, useEffect } from "react";
import {
    Text,
    View,
    SafeAreaView,
    StatusBar,
    Dimensions,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Image,
    ScrollView,
    KeyboardAvoidingView,
    FlatList,
} from "react-native";
import { BarChart, LineChart } from "react-native-chart-kit";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { COLORS } from "../../config/colors";
import { NoDataView } from "../components/NoDataView";


export const supportscreen = (props) => {

    const navigationButtonPressed = ({ buttonId }) => {
        if (buttonId == 'sideMenu') {
            Navigation.mergeOptions(props.componentId, {
                sideMenu: {
                    left: {
                        visible: true
                    }
                }
            });
        }
    }

    return (
        <SafeAreaView
            style={{
                flex: 1,
                backgroundColor: COLORS.appGray,
            }}
        >
            <StatusBar barStyle='light-content' />
            <View
                style={{
                    flex: 1,
                    alignItems: 'center'
                }}
            >
               
            </View>

        </SafeAreaView>
    );
};


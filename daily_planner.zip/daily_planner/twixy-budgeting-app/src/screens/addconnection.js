import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  FlatList,
} from "react-native";
// import LinearGradient from 'react-native-linear-gradient';
import { Navigation } from "react-native-navigation";
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import ActionSheet from "react-native-actionsheet";
import { COLORS } from "../../config/colors";

export const addconnection = (props) => {
  const [accounts, setAccounts] = useState([]);
  const [selectedImage, setSecectedImage] = useState(null);

  const [connectionName, setName] = useState('')

  const [nameError, setNameError] = useState('')

  const clearAllMessages = () => {
    setNameError('')
  }
  const validateData = () => {
    clearAllMessages()
    if (connectionName == '') {
      setNameError('Please enter connection name.')
    }

    if (connectionName != '') {

    }
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: COLORS.appGray,
      }}
    >
      <View
        style={{
          flex: 1,
          alignItems: "center",
        }}
      >
        <TouchableOpacity
          style={{
            height: 80,
            width: 80,
            // backgroundColor: "#999",
            marginTop: 30,
            justifyContent: 'center',
            alignItems: 'center'
          }}
          onPress={() => {
            this.ActionSheet.show()
          }} >
          <Image style={{
            height: 80,
            width: 80,
            borderRadius: selectedImage != null ? 40 : 0,
            resizeMode: selectedImage != null ? 'cover' : 'contain'
          }}
            source={selectedImage != null ? selectedImage : require('../../assets/icons/photos.png')} />
        </TouchableOpacity>

        <View
          style={{
            // height: 50,
            width: "80%",
          }}
        >
          <TextInput
            style={{
              textAlign: 'center',
              marginTop: 20,
              fontSize: 17,
              color: 'white',
              padding: 0,
              height: 40,
              width: '100%'
            }}
            value={connectionName}
            onChangeText = {setName}
            placeholderTextColor='#999'
            placeholder="Connection Name"
          />
          <View style={{
            height: 1,
            backgroundColor: '#ffffff33'
          }} />
          {nameError != null && nameError != '' &&
            <Text style={{
              color: 'white',
              marginTop: 5,
              // marginBottom: 5
            }}>* {nameError}</Text>}
        </View>

        <TouchableOpacity style={{
          height: 40,
          backgroundColor: '#A74834',
          width: '80%',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: 20,
          marginTop: 40
        }}
        onPress = {validateData} >
          <Text style={{
            color: 'white',
            fontSize: 16,
            fontWeight: '500'
          }}>Submit</Text>
        </TouchableOpacity>
      </View>


      <ActionSheet
        ref={o => this.ActionSheet = o}
        title={'Choose image'}
        options={['Camera', 'Gallery', 'Cancel']}
        cancelButtonIndex={2}
        onPress={(index) => {
          if (index == 0) {
            launchCamera({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
          else if (index == 1) {
            launchImageLibrary({
              mediaType: 'photo',
              quality: 0.2,
              maxHeight: 720,
              maxWidth: 720
            }, (response) => {
              console.log(response)
              setSecectedImage(response)
            });
          }
        }}
      />
    </SafeAreaView>
  );
};

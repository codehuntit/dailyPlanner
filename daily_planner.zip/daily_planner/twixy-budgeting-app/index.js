/**
 * @format
 */

import { Navigation } from "react-native-navigation";
import { COLORS } from "./config/colors";
import { accounts } from "./src/screens/accounts";
import { addaccount } from "./src/screens/addaccount";
import { addbudget } from "./src/screens/addbudget";
import { addcategory } from "./src/screens/addcategory";
import { addtransaction } from "./src/screens/addtransaction";
import { budget } from "./src/screens/budget";
import { chooseCategories } from "./src/screens/chooseCategories";
import { dashboard } from "./src/screens/dashboard";
import { editprofile } from "./src/screens/editprofile";
import { forgotPassword } from "./src/screens/forgotPassword";
import { login } from "./src/screens/login";
import { profile } from "./src/screens/profile";
import { sidemenu } from "./src/screens/sidemenu";
import { signup } from "./src/screens/signup";
import { transactions } from "./src/screens/transactions";
import { changePassword } from "./src/screens/changePassword";
import { report } from "./src/screens/report";
import { about } from "./src/screens/about";
import { accountDetail } from "./src/screens/accountDetail";
import { settings } from "./src/screens/settingsScreen";
import { assets } from "./src/screens/assetsScreen";
import { connections } from "./src/screens/connectionsScreen";
import { addAsset } from "./src/screens/addAsset";
import { addconnection } from "./src/screens/addconnection";
import { supportscreen } from "./src/screens/supportscreen";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Constants } from "./config/Constants";
import { Dimensions } from "react-native";
import { GlobalData } from "./config/GlobalData";
import { chooseAccount } from "./src/screens/chooseAccount";
import { CategoriesList } from "./src/screens/CategoriesList";

Navigation.registerComponent('com.twixy.signup', () => signup);
Navigation.registerComponent('com.twixy.login', () => login);
Navigation.registerComponent('com.twixy.forgotPassword', () => forgotPassword);
Navigation.registerComponent('com.twixy.sidemenu', () => sidemenu);
Navigation.registerComponent('com.twixy.dashboard', () => dashboard);
Navigation.registerComponent('com.twixy.profile', () => profile);
Navigation.registerComponent('com.twixy.editprofile', () => editprofile);
Navigation.registerComponent('com.twixy.transactions', () => transactions);
Navigation.registerComponent('com.twixy.budget', () => budget);
Navigation.registerComponent('com.twixy.addcategory', () => addcategory);
Navigation.registerComponent('com.twixy.addbudget', () => addbudget);
Navigation.registerComponent('com.twixy.addaccount', () => addaccount);
Navigation.registerComponent('com.twixy.chooseCategories', () => chooseCategories);
Navigation.registerComponent('com.twixy.accounts', () => accounts);
Navigation.registerComponent('com.twixy.addtransaction', () => addtransaction);
Navigation.registerComponent('com.twixy.changePassword', () => changePassword);
Navigation.registerComponent('com.twixy.report', () => report);
Navigation.registerComponent('com.twixy.about', () => about);
Navigation.registerComponent('com.twixy.accountDetail', () => accountDetail);
Navigation.registerComponent('com.twixy.settings', () => settings);
Navigation.registerComponent('com.twixy.assets', () => assets);
Navigation.registerComponent('com.twixy.connections', () => connections);
Navigation.registerComponent('com.twixy.addasset', () => addAsset);
Navigation.registerComponent('com.twixy.addconnection', () => addconnection);
Navigation.registerComponent('com.twixy.supportscreen', () => supportscreen);
Navigation.registerComponent('com.twixy.chooseAccount', () => chooseAccount);
Navigation.registerComponent('com.twixy.CategoriesList', () => CategoriesList);

Navigation.events().registerAppLaunchedListener(async () => {
    const user_id = await AsyncStorage.getItem(Constants.USER_ID_KEY)
    GlobalData.UserId = user_id
    if (user_id != null && user_id != '') {
        Navigation.setRoot({
            root: {
                sideMenu: {
                    center: {
                        stack: {
                            id: 'STACK_ROOT_ID',
                            children: [
                                {
                                    component: {
                                        name: 'com.twixy.dashboard',
                                        options: {
                                            topBar: {
                                                leftButtonColor: 'white',
                                                background: {
                                                    color: COLORS.appDarkGray
                                                },
                                                title: {
                                                    text: 'Dashboard',
                                                    color: 'white'
                                                },
                                                leftButtons: {
                                                    id: 'sideMenu',
                                                    icon: Platform.OS == 'ios' ? {
                                                        scale: 10,
                                                        uri: 'menu'
                                                    } : require('./assets/icons/menu.png')
                                                }
                                            }
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    left: {
                        component: {
                            name: 'com.twixy.sidemenu',
                        }
                    },
                    options: {
                        sideMenu: {
                            left: {
                                width: Dimensions.get('screen').width / 1.3
                            }
                        }
                    }
                }
            }
        })
    }
    else {
        Navigation.setRoot({
            root: {
                stack: {
                    children: [
                        {
                            component: {
                                name: 'com.twixy.signup',
                                options: {
                                    topBar: {
                                        title: {
                                            text: 'Sign up'
                                        }
                                    },
                                    // statusBar: {
                                    //     backgroundColor: 'green'
                                    // }
                                }
                            }
                        }
                    ],
                    options: {
                        topBar: {
                            background: {
                                color: COLORS.appDarkGray
                            },
                            title: {
                                color: 'white',
                                fontSize: 20
                            },
                            backButton: {
                                color: COLORS.appTheme
                            }
                        }
                    }
                }
            }
        });
    }
});
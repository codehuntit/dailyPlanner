package com.twixybudgeting;

import com.reactnativenavigation.NavigationActivity;

public class MainActivity extends NavigationActivity {

  
}

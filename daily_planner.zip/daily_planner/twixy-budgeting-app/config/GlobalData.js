export var GlobalData = {
    UserId: ''
}
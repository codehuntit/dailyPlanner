export const ApiClient = {
    fetchPost(method, params, isLoader, setLoader, completion, completionWithError) {
        if (isLoader) {
            setLoader(true)
        }
        fetch('http://18.194.109.103/public/api/' + method, {
            body: JSON.stringify(params),
            method: 'POST'
        })
            .then(response => response.json())
            .then((responseJson) => {
                if (isLoader) {
                    setLoader(false)
                }
                if (responseJson.status + '' == 'true') {
                    completion(responseJson)
                }
                else {
                    alert(responseJson.message + '')
                }
            })
            .catch(error => {
                if (isLoader) {
                    setLoader(false)
                }
                completionWithError(error)
                console.log(error)
            })
    },

    fetchGet(method, isLoader, setLoader, completion, completionWithError) {
        if (isLoader) {
            setLoader(true)
        }
        fetch('https://jsonplaceholder.typicode.com/' + method)
            .then(response => response.json())
            .then((responseJson) => {
                if (isLoader) {
                    setLoader(false)
                }
                if (responseJson.status + '' == 'true') {
                    completion(responseJson)
                }
                else {
                    alert(responseJson.message + '')
                }
            })
            .catch(error => {
                if (isLoader) {
                    setLoader(false)
                }
                completionWithError(error)
                console.log(error)
            })
    },
    fetchPostWithFormData(method, params, isLoader, setLoader, completion, completionWithError) {
        if (isLoader) {
            setLoader(true)
        }
        var form_data = new FormData();

        for (var key in params) {
            form_data.append(key, params[key]);
        }
        fetch('http://18.194.109.103/public/api/' + method, {
            body: form_data,
            method: 'POST'
        })
            .then(response => response.json())
            .then((responseJson) => {
                console.log('===> ' + JSON.stringify(responseJson))
                if (isLoader) {
                    setLoader(false)
                }
                // if (responseJson.status + '' == 'true') {
                    completion(responseJson)
                // }
                // else {
                    // alert(responseJson.message + '')
                // }
            })
            .catch(error => {
                if (isLoader) {
                    setLoader(false)
                }
                completionWithError(error)
                console.log(error)
            })
    }
}


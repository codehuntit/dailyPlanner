export const Constants = {
    USER_ID_KEY: 'user_id'
}
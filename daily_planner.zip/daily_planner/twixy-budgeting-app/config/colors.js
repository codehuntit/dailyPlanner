export const COLORS = {
    appDarkGray: '#1A242D',
    appGray: '#1F303D',
    appTheme: '#A74834',
}